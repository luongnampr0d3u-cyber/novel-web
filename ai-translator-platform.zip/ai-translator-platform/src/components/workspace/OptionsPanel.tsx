"use client";
import { useState } from "react";
import { ArrowLeftRight, Settings2, Loader2, Play, Plus, X } from "lucide-react";

export interface WorkspaceOptionsState {
  sourceLang: string;
  targetLang: string;
  style: "LITERAL" | "NATURAL" | "NOVEL" | "ACADEMIC" | "SUBTITLE";
  pronounPreset: string;
  customPronouns: Record<string, string>;
  glossaryId: string;
  provider: "openai" | "claude" | "deepl" | "google";
  model: string;
  temperature: number;
  keepProperNouns: boolean;
  keepNumbers: boolean;
  ignoreBraces: boolean;
  preserveFormat: boolean;
  grammarCheck: boolean;
}

interface OptionsPanelProps {
  options: WorkspaceOptionsState;
  setOptions: React.Dispatch<React.SetStateAction<WorkspaceOptionsState>>;
  glossaries: Array<{ id: string; name: string; isPublic: boolean }>;
  isTranslating: boolean;
  disabled: boolean;
  onTranslate: () => void;
}

export function OptionsPanel({ options, setOptions, glossaries, isTranslating, disabled, onTranslate }: OptionsPanelProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [newSrc, setNewSrc] = useState("");
  const [newTgt, setNewTgt] = useState("");

  function addCustomPronoun() {
    if (!newSrc.trim() || !newTgt.trim()) return;
    setOptions((p) => ({ ...p, customPronouns: { ...p.customPronouns, [newSrc.trim()]: newTgt.trim() } }));
    setNewSrc("");
    setNewTgt("");
  }

  return (
    <div className="flex h-full flex-col justify-between rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="space-y-4">
        <h2 className="text-sm font-semibold">Tùy chọn dịch</h2>

        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2">
          <select value={options.sourceLang} onChange={(e) => setOptions((p) => ({ ...p, sourceLang: e.target.value }))} className="w-full rounded-lg border border-slate-300 bg-transparent px-2 py-2 text-xs dark:border-slate-700">
            <option value="auto">Tự động</option>
            <option value="zh-CN">Trung (Giản thể)</option>
            <option value="zh-TW">Trung (Phồn thể)</option>
            <option value="en">Tiếng Anh</option>
            <option value="ja">Tiếng Nhật</option>
            <option value="ko">Tiếng Hàn</option>
            <option value="vi">Tiếng Việt</option>
          </select>
          <button type="button" disabled={options.sourceLang === "auto"} onClick={() => setOptions((p) => ({ ...p, sourceLang: p.targetLang, targetLang: p.sourceLang }))} className="rounded-lg border border-slate-200 p-2 text-slate-500 disabled:opacity-40 dark:border-slate-700"><ArrowLeftRight className="h-3.5 w-3.5" /></button>
          <select value={options.targetLang} onChange={(e) => setOptions((p) => ({ ...p, targetLang: e.target.value }))} className="w-full rounded-lg border border-slate-300 bg-transparent px-2 py-2 text-xs dark:border-slate-700">
            <option value="vi">Tiếng Việt</option>
            <option value="en">Tiếng Anh</option>
            <option value="zh-CN">Trung (Giản thể)</option>
          </select>
        </div>

        <div>
          <label className="mb-1 block text-xs font-medium text-slate-500">Phong cách dịch</label>
          <select value={options.style} onChange={(e) => setOptions((p) => ({ ...p, style: e.target.value as WorkspaceOptionsState["style"] }))} className="w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 text-xs dark:border-slate-700">
            <option value="NATURAL">Tự nhiên (Natural)</option>
            <option value="NOVEL">Truyện / Tiểu thuyết</option>
            <option value="LITERAL">Trung thực (Sát nghĩa)</option>
            <option value="ACADEMIC">Tài liệu / Học thuật</option>
            <option value="SUBTITLE">Phụ đề phim</option>
          </select>
        </div>

        <div>
          <label className="mb-1 block text-xs font-medium text-slate-500">Xưng hô nhân vật</label>
          <select value={options.pronounPreset} onChange={(e) => setOptions((p) => ({ ...p, pronounPreset: e.target.value }))} className="w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 text-xs dark:border-slate-700">
            <option value="auto">Tự động</option>
            <option value="huynh-de">Huynh - Đệ</option>
            <option value="ty-muoi">Tỷ - Muội</option>
            <option value="nguoi-ta">Ta - Ngươi</option>
            <option value="anh-em">Anh - Em</option>
            <option value="custom">Tùy chỉnh</option>
          </select>
          {options.pronounPreset === "custom" && (
            <div className="mt-2 space-y-2 rounded-lg border border-slate-200 p-2 dark:border-slate-800">
              <div className="flex gap-1">
                <input value={newSrc} onChange={(e) => setNewSrc(e.target.value)} placeholder="他" className="w-1/2 rounded border border-slate-300 bg-transparent px-2 py-1 text-xs dark:border-slate-700" />
                <input value={newTgt} onChange={(e) => setNewTgt(e.target.value)} placeholder="hắn" className="w-1/2 rounded border border-slate-300 bg-transparent px-2 py-1 text-xs dark:border-slate-700" />
                <button type="button" onClick={addCustomPronoun} className="rounded bg-blue-600 p-1 text-white"><Plus className="h-3.5 w-3.5" /></button>
              </div>
              <div className="flex flex-wrap gap-1">
                {Object.entries(options.customPronouns).map(([k, v]) => (
                  <span key={k} className="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-[11px] dark:bg-slate-800">
                    {k}→{v}
                    <button type="button" onClick={() => setOptions((p) => { const n = { ...p.customPronouns }; delete n[k]; return { ...p, customPronouns: n }; })}><X className="h-3 w-3" /></button>
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div>
          <label className="mb-1 block text-xs font-medium text-slate-500">Glossary</label>
          <select value={options.glossaryId} onChange={(e) => setOptions((p) => ({ ...p, glossaryId: e.target.value }))} className="w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 text-xs dark:border-slate-700">
            <option value="">Không áp dụng</option>
            {glossaries.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        </div>

        <div>
          <button type="button" onClick={() => setShowAdvanced(!showAdvanced)} className="flex w-full items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium dark:border-slate-800">
            <span className="flex items-center gap-1.5"><Settings2 className="h-3.5 w-3.5" /> Nâng cao</span>
            <span>{showAdvanced ? "Ẩn" : "Mở"}</span>
          </button>
          {showAdvanced && (
            <div className="mt-2 space-y-2 rounded-lg border border-slate-200 p-3 text-xs dark:border-slate-800">
              <select value={options.provider} onChange={(e) => setOptions((p) => ({ ...p, provider: e.target.value as WorkspaceOptionsState["provider"] }))} className="w-full rounded border border-slate-300 bg-transparent px-2 py-1 text-xs dark:border-slate-700">
                <option value="openai">OpenAI (GPT-4o)</option>
                <option value="claude">Claude 3.5</option>
                <option value="deepl">DeepL</option>
                <option value="google">Google Translate</option>
              </select>
              <label className="flex items-center gap-2"><input type="checkbox" checked={options.preserveFormat} onChange={(e) => setOptions((p) => ({ ...p, preserveFormat: e.target.checked }))} /> Giữ nguyên format</label>
              <label className="flex items-center gap-2"><input type="checkbox" checked={options.keepProperNouns} onChange={(e) => setOptions((p) => ({ ...p, keepProperNouns: e.target.checked }))} /> Giữ tên riêng</label>
              <label className="flex items-center gap-2"><input type="checkbox" checked={options.ignoreBraces} onChange={(e) => setOptions((p) => ({ ...p, ignoreBraces: e.target.checked }))} /> Bỏ qua {"{{...}}"}</label>
              <label className="flex items-center gap-2"><input type="checkbox" checked={options.grammarCheck} onChange={(e) => setOptions((p) => ({ ...p, grammarCheck: e.target.checked }))} /> Kiểm tra ngữ pháp</label>
            </div>
          )}
        </div>
      </div>

      <button type="button" disabled={disabled || isTranslating} onClick={onTranslate} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50">
        {isTranslating ? <><Loader2 className="h-4 w-4 animate-spin" /> Đang dịch...</> : <><Play className="h-4 w-4" /> Bắt đầu dịch</>}
      </button>
    </div>
  );
}
