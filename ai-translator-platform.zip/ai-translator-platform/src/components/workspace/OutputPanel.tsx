"use client";
import { useState } from "react";
import { Copy, Check, Download, Share2, Columns2, AlignLeft, Type } from "lucide-react";

interface OutputPanelProps {
  jobId: string | null;
  sourceText: string;
  translatedText: string;
  progress: number;
  isTranslating: boolean;
  providerInfo: string | null;
}

export function OutputPanel({ jobId, sourceText, translatedText, progress, isTranslating, providerInfo }: OutputPanelProps) {
  const [bilingualMode, setBilingualMode] = useState(false);
  const [serifFont, setSerifFont] = useState(true);
  const [copiedAll, setCopiedAll] = useState(false);
  const [shareUrl, setShareUrl] = useState<string | null>(null);

  const srcParas = sourceText.split(/\n{2,}/).filter((p) => p.trim());
  const tgtParas = translatedText.split(/\n{2,}/).filter((p) => p.trim());

  async function handleShare() {
    if (!jobId) return;
    const res = await fetch(`/api/history/${jobId}/share`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isPublic: true }),
    });
    const data = await res.json();
    if (res.ok && data.shareUrl) {
      setShareUrl(data.shareUrl);
      navigator.clipboard.writeText(data.shareUrl).catch(() => {});
    }
  }

  return (
    <div className="flex h-full flex-col rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 p-3 dark:border-slate-800">
        <div className="flex items-center gap-1">
          <button type="button" onClick={() => setBilingualMode(false)} className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium ${!bilingualMode ? "bg-blue-600 text-white" : "text-slate-600 dark:text-slate-300"}`}><AlignLeft className="h-3.5 w-3.5" /> Bản dịch</button>
          <button type="button" onClick={() => setBilingualMode(true)} className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium ${bilingualMode ? "bg-blue-600 text-white" : "text-slate-600 dark:text-slate-300"}`}><Columns2 className="h-3.5 w-3.5" /> Song ngữ</button>
          <button type="button" onClick={() => setSerifFont(!serifFont)} className="rounded-lg p-1.5 text-slate-500"><Type className="h-4 w-4" /></button>
        </div>

        <div className="flex items-center gap-1.5">
          <button type="button" disabled={!translatedText} onClick={() => { navigator.clipboard.writeText(translatedText); setCopiedAll(true); setTimeout(() => setCopiedAll(false), 1500); }} className="flex items-center gap-1 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-medium disabled:opacity-40 dark:border-slate-700">
            {copiedAll ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Copy className="h-3.5 w-3.5" />} Copy
          </button>
          {jobId && translatedText && (
            <>
              <button type="button" onClick={handleShare} className="flex items-center gap-1 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-medium dark:border-slate-700"><Share2 className="h-3.5 w-3.5" /> Chia sẻ</button>
              <div className="relative">
                <select defaultValue="" onChange={(e) => { if (!e.target.value) return; window.location.href = `/api/export/${jobId}?format=${e.target.value}&bilingual=${bilingualMode}`; e.target.value = ""; }} className="appearance-none rounded-lg bg-blue-600 py-1.5 pl-3 pr-7 text-xs font-medium text-white outline-none">
                  <option value="" disabled>Tải xuống...</option>
                  <option value="docx">DOCX</option>
                  <option value="pdf">PDF</option>
                  <option value="epub">EPUB</option>
                  <option value="txt">TXT</option>
                  <option value="md">MD</option>
                  <option value="html">HTML</option>
                  <option value="srt">SRT</option>
                </select>
                <Download className="pointer-events-none absolute right-2 top-2 h-3.5 w-3.5 text-white" />
              </div>
            </>
          )}
        </div>
      </div>

      {isTranslating && (
        <div className="border-b border-slate-200 px-4 py-2 dark:border-slate-800">
          <div className="mb-1 flex justify-between text-xs text-slate-500"><span>Đang dịch...</span><span>{progress}%</span></div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800"><div className="h-full bg-blue-600 transition-all" style={{ width: `${Math.max(progress, 8)}%` }} /></div>
        </div>
      )}

      {shareUrl && <div className="mx-3 mt-2 rounded-lg bg-green-50 px-3 py-2 text-xs text-green-700 dark:bg-green-950/40 dark:text-green-300">Link chia sẻ: {shareUrl}</div>}

      <div className={`min-h-[340px] flex-1 overflow-y-auto p-4 ${serifFont ? "font-serif text-[15px] leading-relaxed" : "font-sans text-sm leading-relaxed"}`}>
        {!translatedText ? (
          <div className="flex h-full min-h-[280px] items-center justify-center text-sm text-slate-400">Bản dịch sẽ hiển thị tại đây.</div>
        ) : bilingualMode ? (
          <div className="space-y-4">
            {Array.from({ length: Math.max(srcParas.length, tgtParas.length) }).map((_, idx) => (
              <div key={idx} className="grid grid-cols-1 gap-3 rounded-xl border border-slate-100 bg-slate-50/70 p-3 dark:border-slate-800 dark:bg-slate-950/40 sm:grid-cols-2">
                <div className="whitespace-pre-wrap text-slate-500">{srcParas[idx] ?? ""}</div>
                <div className="whitespace-pre-wrap">{tgtParas[idx] ?? ""}</div>
              </div>
            ))}
          </div>
        ) : (
          <div className="whitespace-pre-wrap">{translatedText}</div>
        )}
      </div>

      <div className="flex items-center justify-between border-t border-slate-200 px-4 py-2 text-xs text-slate-500 dark:border-slate-800">
        <span>{translatedText.length.toLocaleString()} ký tự</span>
        <span>{providerInfo || "Sẵn sàng"}</span>
      </div>
    </div>
  );
}
