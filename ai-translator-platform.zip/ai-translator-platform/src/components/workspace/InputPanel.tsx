"use client";
import { useState, useRef } from "react";
import { FileText, Upload, Globe, ScanText, ClipboardPaste, Trash2, Sparkles, Loader2 } from "lucide-react";

export type InputTab = "TEXT" | "FILE" | "URL" | "OCR";

interface InputPanelProps {
  inputType: InputTab;
  setInputType: (tab: InputTab) => void;
  title: string;
  setTitle: (v: string) => void;
  sourceText: string;
  setSourceText: (v: string) => void;
  sourceLang: string;
}

const SAMPLE_ZH_NOVEL = `萧炎深吸了一口气，缓缓闭上双眼。丹田之内，那股微弱的斗气正沿着经脉缓缓流转。
“三十年河东，三十年河西，莫欺少年穷！”他低声喃喃，眼中闪过一抹坚毅的光芒。`;

export function InputPanel({ inputType, setInputType, title, setTitle, sourceText, setSourceText, sourceLang }: InputPanelProps) {
  const [urlInput, setUrlInput] = useState("");
  const [loadingInput, setLoadingInput] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const ocrRef = useRef<HTMLInputElement>(null);

  const charCount = sourceText.length;
  const wordCount = sourceText.trim() ? sourceText.trim().split(/\s+/).length : 0;
  const estTokens = Math.ceil(charCount / 3);

  async function handleFileUpload(file: File) {
    setErrorMsg(null);
    setStatusMsg(`Đang đọc file "${file.name}"...`);
    setLoadingInput(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Không thể đọc file.");
      setTitle(data.title || file.name);
      setSourceText(data.text || "");
      setStatusMsg(`Đã trích xuất ${data.charCount?.toLocaleString()} ký tự từ ${file.name}.`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Lỗi đọc file.");
      setStatusMsg(null);
    } finally {
      setLoadingInput(false);
    }
  }

  async function handleCrawlUrl() {
    if (!urlInput.trim()) return;
    setErrorMsg(null);
    setStatusMsg("Đang tải nội dung từ URL...");
    setLoadingInput(true);
    try {
      const res = await fetch("/api/crawl", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: urlInput.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Không thể crawl URL.");
      setTitle(data.title || "Bài viết từ Web");
      setSourceText(data.text || "");
      setStatusMsg(`Đã lấy ${data.charCount?.toLocaleString()} ký tự (${data.siteType}).`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Lỗi tải URL.");
      setStatusMsg(null);
    } finally {
      setLoadingInput(false);
    }
  }

  async function handleOcrUpload(file: File) {
    setErrorMsg(null);
    setStatusMsg("Đang nhận diện chữ từ ảnh bằng Tesseract OCR...");
    setLoadingInput(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("lang", sourceLang);
      const res = await fetch("/api/ocr", { method: "POST", body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "OCR thất bại.");
      setTitle(file.name.replace(/\.[^/.]+$/, ""));
      setSourceText(data.text || "");
      setStatusMsg(`OCR hoàn tất (độ tin cậy ${data.confidence}%).`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Lỗi OCR.");
      setStatusMsg(null);
    } finally {
      setLoadingInput(false);
    }
  }

  const tabs: Array<{ id: InputTab; label: string; icon: typeof FileText }> = [
    { id: "TEXT", label: "Văn bản", icon: FileText },
    { id: "FILE", label: "Tải File", icon: Upload },
    { id: "URL", label: "Từ URL", icon: Globe },
    { id: "OCR", label: "Ảnh (OCR)", icon: ScanText },
  ];

  return (
    <div className="flex h-full flex-col rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 p-3 dark:border-slate-800">
        <div className="flex items-center gap-1">
          {tabs.map((t) => {
            const Icon = t.icon;
            return (
              <button key={t.id} type="button" onClick={() => { setInputType(t.id); setErrorMsg(null); }} className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition ${inputType === t.id ? "bg-blue-600 text-white" : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"}`}>
                <Icon className="h-3.5 w-3.5" /> {t.label}
              </button>
            );
          })}
        </div>
        <div className="flex items-center gap-1">
          <button type="button" onClick={() => navigator.clipboard.readText().then((t) => t && setSourceText(t)).catch(() => {})} className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800" title="Dán"><ClipboardPaste className="h-4 w-4" /></button>
          <button type="button" onClick={() => { setTitle("Đấu Phá Thương Khung (Mẫu)"); setSourceText(SAMPLE_ZH_NOVEL); }} className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800" title="Lấy mẫu"><Sparkles className="h-4 w-4" /></button>
          <button type="button" onClick={() => { setSourceText(""); setTitle(""); setStatusMsg(null); setErrorMsg(null); }} className="rounded-md p-1.5 text-slate-500 hover:bg-red-50 hover:text-red-600" title="Xóa"><Trash2 className="h-4 w-4" /></button>
        </div>
      </div>

      {inputType === "FILE" && (
        <div onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files?.[0]; if (f) handleFileUpload(f); }} className="m-3 flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 p-5 text-center dark:border-slate-700 dark:bg-slate-950/50">
          <Upload className="mb-2 h-6 w-6 text-blue-600" />
          <p className="text-sm font-medium">Kéo thả file vào đây hoặc chọn từ máy</p>
          <p className="mt-1 text-xs text-slate-500">.txt, .docx, .pdf, .epub, .md, .html, .srt, .ass, .vtt, .xlsx, .csv</p>
          <input ref={fileRef} type="file" className="hidden" accept=".txt,.docx,.pdf,.epub,.md,.html,.srt,.ass,.vtt,.xlsx,.csv" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFileUpload(f); }} />
          <button type="button" disabled={loadingInput} onClick={() => fileRef.current?.click()} className="mt-3 rounded-lg bg-blue-600 px-4 py-1.5 text-xs font-medium text-white hover:bg-blue-700 disabled:opacity-50">Chọn File</button>
        </div>
      )}

      {inputType === "URL" && (
        <div className="flex gap-2 border-b border-slate-200 p-3 dark:border-slate-800">
          <input type="url" value={urlInput} onChange={(e) => setUrlInput(e.target.value)} placeholder="Dán link truyện (jjwxc, qidian...), blog hoặc Wikipedia..." className="flex-1 rounded-lg border border-slate-300 bg-transparent px-3 py-2 text-xs outline-none focus:border-blue-600 dark:border-slate-700" />
          <button type="button" disabled={loadingInput || !urlInput.trim()} onClick={handleCrawlUrl} className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-medium text-white hover:bg-blue-700 disabled:opacity-50">
            {loadingInput && <Loader2 className="h-3.5 w-3.5 animate-spin" />} Lấy nội dung
          </button>
        </div>
      )}

      {inputType === "OCR" && (
        <div className="m-3 flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 p-5 text-center dark:border-slate-700 dark:bg-slate-950/50">
          <ScanText className="mb-2 h-6 w-6 text-blue-600" />
          <p className="text-sm font-medium">Tải ảnh trang truyện / tài liệu scan</p>
          <input ref={ocrRef} type="file" className="hidden" accept="image/png,image/jpeg,image/webp,image/bmp" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleOcrUpload(f); }} />
          <button type="button" disabled={loadingInput} onClick={() => ocrRef.current?.click()} className="mt-3 rounded-lg bg-blue-600 px-4 py-1.5 text-xs font-medium text-white hover:bg-blue-700 disabled:opacity-50">{loadingInput ? "Đang quét OCR..." : "Chọn ảnh"}</button>
        </div>
      )}

      {statusMsg && <div className="mx-3 mt-2 rounded-lg bg-blue-50 px-3 py-2 text-xs text-blue-700 dark:bg-blue-950/40 dark:text-blue-300">{statusMsg}</div>}
      {errorMsg && <div className="mx-3 mt-2 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600 dark:bg-red-950/40 dark:text-red-400">{errorMsg}</div>}

      <div className="flex flex-1 flex-col p-3">
        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Tiêu đề tài liệu / tên chương (tùy chọn)..." className="mb-2 w-full rounded-lg border border-slate-200 bg-transparent px-3 py-1.5 text-xs font-medium outline-none focus:border-blue-600 dark:border-slate-800" />
        <textarea value={sourceText} onChange={(e) => setSourceText(e.target.value)} placeholder="Nhập, dán văn bản hoặc xem trước nội dung đã trích xuất tại đây..." className="min-h-[300px] w-full flex-1 resize-none rounded-lg bg-transparent p-2 text-sm leading-relaxed outline-none" />
      </div>

      <div className="flex items-center justify-between border-t border-slate-200 px-4 py-2 text-xs text-slate-500 dark:border-slate-800">
        <span>{charCount.toLocaleString()} ký tự • {wordCount.toLocaleString()} từ</span>
        <span>~{estTokens.toLocaleString()} tokens</span>
      </div>
    </div>
  );
}
