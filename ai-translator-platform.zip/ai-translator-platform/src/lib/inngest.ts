import { Inngest } from "inngest";

export const inngest = new Inngest({
  id: "ai-translator-platform",
});
