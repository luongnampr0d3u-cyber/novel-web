import { db } from "@/lib/db";

export async function checkAndConsumeQuota(userId: string, charCount: number): Promise<void> {
  const [user, config] = await Promise.all([
    db.user.findUnique({ where: { id: userId } }),
    db.systemConfig.findUnique({ where: { id: "default" } }),
  ]);

  if (!user) throw new Error("Không tìm thấy người dùng.");
  if (user.isBanned) throw new Error("Tài khoản đã bị khóa.");

  const freeLimit = config?.freeDailyChars ?? 5000;
  const proLimit = config?.proMonthlyChars ?? 500000;

  const now = new Date();
  const resetAt = new Date(user.quotaResetAt);
  const isNewDay = now.toDateString() !== resetAt.toDateString();
  const isNewMonth =
    now.getMonth() !== resetAt.getMonth() || now.getFullYear() !== resetAt.getFullYear();

  const currentDaily = isNewDay ? 0 : user.dailyCharUsed;
  const currentMonthly = isNewMonth ? 0 : user.monthlyCharUsed;

  if (user.plan === "FREE" && currentDaily + charCount > freeLimit) {
    throw new Error(`Bạn đã vượt giới hạn ${freeLimit.toLocaleString()} ký tự/ngày của gói Free.`);
  }

  if (user.plan === "PRO" && currentMonthly + charCount > proLimit) {
    throw new Error(`Bạn đã vượt giới hạn ${proLimit.toLocaleString()} ký tự/tháng của gói Pro.`);
  }

  await db.user.update({
    where: { id: userId },
    data: {
      dailyCharUsed: currentDaily + charCount,
      monthlyCharUsed: currentMonthly + charCount,
      quotaResetAt: isNewDay || isNewMonth ? now : user.quotaResetAt,
    },
  });
}
