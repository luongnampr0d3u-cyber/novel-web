import { inngest } from "@/lib/inngest";
import { db } from "@/lib/db";
import { translateSingleChunk } from "@/services/translator";
import { extractTailContext } from "@/services/translator/chunker";
import { ProviderName, TranslationAdvancedOptions } from "@/services/translator/types";

export const processTranslationJob = inngest.createFunction(
  {
    id: "process-translation-job",
    concurrency: { limit: 5 },
    retries: 2,
  },
  { event: "translation/job.created" },
  async ({ event, step }) => {
    const { jobId } = event.data as { jobId: string };

    const job = await step.run("load-job", async () => {
      const found = await db.translationJob.findUnique({
        where: { id: jobId },
        include: {
          chunks: { orderBy: { index: "asc" } },
          glossary: { include: { terms: true } },
        },
      });
      if (!found) throw new Error(`Job ${jobId} not found`);

      await db.translationJob.update({
        where: { id: jobId },
        data: { status: "TRANSLATING" },
      });

      return found;
    });

    let previousContext = "";
    let totalTokens = 0;
    const translatedParts: string[] = [];

    for (let i = 0; i < job.chunks.length; i++) {
      const chunk = job.chunks[i];

      const chunkResult = await step.run(`translate-chunk-${chunk.index}`, async () => {
        const res = await translateSingleChunk({
          text: chunk.sourceContent,
          sourceLang: job.sourceLang,
          targetLang: job.targetLang,
          style: job.style,
          pronounPreset: job.pronounPreset,
          customPronouns: (job.customPronouns as Record<string, string>) ?? undefined,
          glossaryTerms: job.glossary?.terms ?? [],
          previousContext: previousContext || undefined,
          options: (job.options as TranslationAdvancedOptions) ?? undefined,
          preferredProvider: job.providerUsed as ProviderName,
        });

        await db.translationChunk.update({
          where: { id: chunk.id },
          data: {
            targetContent: res.translatedText,
            status: "COMPLETED",
            tokenUsed: res.tokenUsed,
          },
        });

        const completedCount = i + 1;
        const progress = Math.round((completedCount / job.chunks.length) * 100);

        await db.translationJob.update({
          where: { id: jobId },
          data: {
            completedChunks: completedCount,
            progress,
            tokenUsed: { increment: res.tokenUsed },
          },
        });

        return res;
      });

      previousContext = extractTailContext(chunkResult.translatedText);
      totalTokens += chunkResult.tokenUsed;
      translatedParts.push(chunkResult.translatedText);
    }

    await step.run("finalize-job", async () => {
      await db.translationJob.update({
        where: { id: jobId },
        data: {
          status: "COMPLETED",
          progress: 100,
          translatedText: translatedParts.join("\n\n"),
          tokenUsed: totalTokens,
        },
      });
    });

    return { jobId, status: "COMPLETED", totalTokens };
  }
);
