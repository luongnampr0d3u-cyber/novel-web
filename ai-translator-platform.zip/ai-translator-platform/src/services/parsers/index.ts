import * as cheerio from "cheerio";
import { parseDocx } from "./docx";
import { parsePdf } from "./pdf";
import { parseEpub } from "./epub";
import { parseSubtitle } from "./subtitle";
import { parseSpreadsheet } from "./spreadsheet";
import { ParsedFileResult } from "./types";

export const SUPPORTED_EXTENSIONS = [
  "txt", "md", "html", "docx", "pdf", "epub", "srt", "ass", "vtt", "xlsx", "csv",
] as const;

export async function parseUploadedFile(buffer: Buffer, fileName: string): Promise<ParsedFileResult> {
  const ext = fileName.split(".").pop()?.toLowerCase() ?? "";

  switch (ext) {
    case "txt":
    case "md": {
      const text = buffer.toString("utf-8").replace(/^\uFEFF/, "").replace(/\r\n/g, "\n").trim();
      return { title: fileName.replace(/\.(txt|md)$/i, ""), format: ext, text, charCount: text.length };
    }
    case "html": {
      const rawHtml = buffer.toString("utf-8");
      const $ = cheerio.load(rawHtml);
      $("script, style, noscript").remove();
      const title = $("title").text().trim() || fileName.replace(/\.html$/i, "");
      $("br").replaceWith("\n");
      $("p, div, h1, h2, h3, h4, li").each((_, el) => { $(el).append("\n\n"); });
      const text = $("body").text().replace(/\n{3,}/g, "\n\n").trim();
      return { title, format: "html", text, charCount: text.length };
    }
    case "docx": return parseDocx(buffer, fileName);
    case "pdf": return parsePdf(buffer, fileName);
    case "epub": return parseEpub(buffer, fileName);
    case "srt":
    case "ass":
    case "vtt": return parseSubtitle(buffer, fileName, ext);
    case "xlsx":
    case "csv": return parseSpreadsheet(buffer, fileName, ext);
    default:
      throw new Error(`Định dạng ".${ext}" chưa được hỗ trợ.`);
  }
}
