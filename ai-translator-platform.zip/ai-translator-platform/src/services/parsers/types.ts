export interface ParsedChapter {
  title: string;
  content: string;
}

export interface ParsedFileResult {
  title: string;
  format: string;
  text: string;
  charCount: number;
  chapters?: ParsedChapter[];
  metadata?: Record<string, unknown>;
}
