import pdfParse from "pdf-parse";
import { ParsedFileResult } from "./types";

export async function parsePdf(buffer: Buffer, fileName: string): Promise<ParsedFileResult> {
  const data = await pdfParse(buffer);
  const text = data.text.replace(/\r\n/g, "\n").trim();
  return {
    title: data.info?.Title || fileName.replace(/\.pdf$/i, ""),
    format: "pdf",
    text,
    charCount: text.length,
    metadata: { numPages: data.numpages, author: data.info?.Author ?? null },
  };
}
