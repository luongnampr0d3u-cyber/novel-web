import { createWorker } from "tesseract.js";

const OCR_LANG_MAP: Record<string, string> = {
  "zh-CN": "chi_sim",
  "zh-TW": "chi_tra",
  en: "eng",
  vi: "vie",
  ja: "jpn",
  ko: "kor",
  auto: "chi_sim+eng",
};

export interface OcrResult {
  text: string;
  confidence: number;
  charCount: number;
}

export async function extractTextFromImage(imageBuffer: Buffer, lang = "auto"): Promise<OcrResult> {
  const tesseractLang = OCR_LANG_MAP[lang] ?? "chi_sim+eng";
  const worker = await createWorker(tesseractLang);

  try {
    const { data } = await worker.recognize(imageBuffer);
    const text = data.text.replace(/\r\n/g, "\n").trim();
    return { text, confidence: Math.round(data.confidence), charCount: text.length };
  } finally {
    await worker.terminate();
  }
}
