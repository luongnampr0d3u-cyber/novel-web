import { ParsedFileResult } from "./types";

export function parseSubtitle(
  buffer: Buffer,
  fileName: string,
  ext: "srt" | "ass" | "vtt"
): ParsedFileResult {
  const raw = buffer.toString("utf-8").replace(/^\uFEFF/, "").replace(/\r\n/g, "\n").trim();
  return {
    title: fileName.replace(/\.(srt|ass|vtt)$/i, ""),
    format: ext,
    text: raw,
    charCount: raw.length,
    metadata: { subtitleFormat: ext },
  };
}
