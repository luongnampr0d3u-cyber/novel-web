import fs from "fs/promises";
import os from "os";
import path from "path";
import crypto from "crypto";
import EPub from "epub2";
import * as cheerio from "cheerio";
import { ParsedChapter, ParsedFileResult } from "./types";

export async function parseEpub(buffer: Buffer, fileName: string): Promise<ParsedFileResult> {
  const tempPath = path.join(os.tmpdir(), `upload_${crypto.randomUUID()}.epub`);
  await fs.writeFile(tempPath, buffer);

  try {
    const epub = await EPub.createAsync(tempPath);
    const chapters: ParsedChapter[] = [];

    for (const item of epub.flow) {
      if (!item.id) continue;
      try {
        const html = await epub.getChapterAsync(item.id);
        const $ = cheerio.load(html);
        $("br").replaceWith("\n");
        $("p, div, h1, h2, h3, h4, li").each((_, el) => {
          $(el).append("\n\n");
        });
        const cleanText = $.text()
          .replace(/\r\n/g, "\n")
          .replace(/\n{3,}/g, "\n\n")
          .trim();

        if (cleanText.length > 0) {
          chapters.push({
            title: item.title || `Chương ${chapters.length + 1}`,
            content: cleanText,
          });
        }
      } catch {
        // skip non-text items
      }
    }

    const fullText = chapters.map((ch) => `### ${ch.title}\n\n${ch.content}`).join("\n\n---\n\n");
    return {
      title: epub.metadata?.title || fileName.replace(/\.epub$/i, ""),
      format: "epub",
      text: fullText,
      charCount: fullText.length,
      chapters,
      metadata: { author: epub.metadata?.creator ?? null, totalChapters: chapters.length },
    };
  } finally {
    await fs.unlink(tempPath).catch(() => {});
  }
}
