import * as XLSX from "xlsx";
import { ParsedFileResult } from "./types";

export function parseSpreadsheet(
  buffer: Buffer,
  fileName: string,
  ext: "xlsx" | "csv"
): ParsedFileResult {
  const workbook = XLSX.read(buffer, { type: "buffer" });
  const sheetTexts: string[] = [];

  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    const csv = XLSX.utils.sheet_to_csv(sheet, { blankrows: false }).trim();
    if (csv) sheetTexts.push(`### Sheet: ${sheetName}\n${csv}`);
  }

  const text = sheetTexts.join("\n\n");
  return {
    title: fileName.replace(/\.(xlsx|csv)$/i, ""),
    format: ext,
    text,
    charCount: text.length,
    metadata: { sheets: workbook.SheetNames },
  };
}
