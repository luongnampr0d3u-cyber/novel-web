import mammoth from "mammoth";
import { ParsedFileResult } from "./types";

export async function parseDocx(buffer: Buffer, fileName: string): Promise<ParsedFileResult> {
  const result = await mammoth.extractRawText({ buffer });
  const text = result.value.replace(/\r\n/g, "\n").trim();
  return {
    title: fileName.replace(/\.docx$/i, ""),
    format: "docx",
    text,
    charCount: text.length,
    metadata: { warnings: result.messages.map((m) => m.message) },
  };
}
