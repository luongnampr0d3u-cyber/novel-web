import * as cheerio from "cheerio";
import iconv from "iconv-lite";

export interface CrawlResult {
  url: string;
  title: string;
  text: string;
  charCount: number;
  siteType: string;
}

const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15",
];

function isBlockedHost(hostname: string): boolean {
  const lower = hostname.toLowerCase();
  return (
    lower === "localhost" ||
    lower === "127.0.0.1" ||
    lower === "0.0.0.0" ||
    lower.startsWith("192.168.") ||
    lower.startsWith("10.") ||
    lower.endsWith(".local")
  );
}

export async function crawlWebContent(rawUrl: string): Promise<CrawlResult> {
  const parsedUrl = new URL(rawUrl);
  if (!["http:", "https:"].includes(parsedUrl.protocol)) {
    throw new Error("Chỉ hỗ trợ đường dẫn HTTP hoặc HTTPS.");
  }
  if (isBlockedHost(parsedUrl.hostname)) {
    throw new Error("Không được phép truy cập địa chỉ mạng nội bộ.");
  }

  const ua = USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  let buffer: Buffer;
  let contentType = "";

  try {
    const res = await fetch(rawUrl, {
      headers: {
        "User-Agent": ua,
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,vi;q=0.7",
      },
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`Trang web trả về mã lỗi HTTP ${res.status}.`);
    contentType = res.headers.get("content-type") ?? "";
    buffer = Buffer.from(await res.arrayBuffer());
  } finally {
    clearTimeout(timeout);
  }

  const isGbk = /gbk|gb2312|gb18030/i.test(contentType) || parsedUrl.hostname.includes("jjwxc.net");
  const html = isGbk ? iconv.decode(buffer, "gb18030") : buffer.toString("utf-8");

  const $ = cheerio.load(html);
  $("script, style, nav, footer, header, aside, iframe, .ads, .advertisement").remove();

  const host = parsedUrl.hostname.toLowerCase();
  let title = $("h1").first().text().trim() || $("title").text().trim() || "Bài viết từ Web";
  let contentNode = $("article").first();
  let siteType = "generic";

  if (host.includes("jjwxc.net")) {
    siteType = "jjwxc";
    title = $("h2").first().text().trim() || title;
    contentNode = $(".novelbody .noveltext").first();
  } else if (host.includes("qidian.com")) {
    siteType = "qidian";
    title = $(".j_chapterName, h1").first().text().trim() || title;
    contentNode = $(".read-content, main").first();
  } else if (host.includes("wikipedia.org")) {
    siteType = "wikipedia";
    title = $("#firstHeading").text().trim() || title;
    contentNode = $("#mw-content-text .mw-parser-output").first();
  }

  if (!contentNode || contentNode.length === 0) contentNode = $("main").first();
  if (!contentNode || contentNode.length === 0) contentNode = $("body");

  contentNode.find("br").replaceWith("\n");
  contentNode.find("p, div, h2, h3, li").each((_, el) => { $(el).append("\n\n"); });

  const text = contentNode
    .text()
    .replace(/\r\n/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  if (!text) throw new Error("Không trích xuất được nội dung văn bản từ đường dẫn này.");

  return { url: rawUrl, title, text, charCount: text.length, siteType };
}
