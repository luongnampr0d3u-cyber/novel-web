import { TranslationStyle } from "@prisma/client";
import { GlossaryItem, TranslationRequest } from "./types";

const LANG_LABELS: Record<string, string> = {
  auto: "tự động nhận diện ngôn ngữ nguồn",
  "zh-CN": "Tiếng Trung (Giản thể)",
  "zh-TW": "Tiếng Trung (Phồn thể)",
  zh: "Tiếng Trung",
  en: "Tiếng Anh",
  vi: "Tiếng Việt",
  ja: "Tiếng Nhật",
  ko: "Tiếng Hàn",
};

const STYLE_INSTRUCTIONS: Record<TranslationStyle, string> = {
  LITERAL: "Dịch trung thực, sát nghĩa từng câu chữ, giữ nguyên cấu trúc ý của bản gốc, không thêm bớt.",
  NATURAL: "Dịch tự nhiên, trôi chảy như người bản xứ viết, ưu tiên sự dễ hiểu và mạch lạc.",
  NOVEL: "Dịch theo văn phong truyện/tiểu thuyết chuyên nghiệp. Giữ nguyên cảm xúc, nhịp điệu, sắc thái nhân vật (cổ trang dùng từ Hán Việt tinh tế, hiện đại dùng ngôn ngữ đời thường tự nhiên). Tuyệt đối không dịch word-by-word kiểu convert.",
  ACADEMIC: "Dịch theo văn phong tài liệu/học thuật chuẩn mực, chính xác thuật ngữ chuyên ngành, khách quan, trang trọng.",
  SUBTITLE: "Dịch phụ đề phim: ngắn gọn, súc tích, dễ đọc nhanh trong 1-2 giây, giữ nguyên hoàn toàn các mốc thời gian (timestamp) và số thứ tự nếu có.",
};

const PRONOUN_INSTRUCTIONS: Record<string, string> = {
  auto: "Tự động chọn xưng hô phù hợp với ngữ cảnh và mối quan hệ nhân vật.",
  "huynh-de": "Ưu tiên xưng hô cổ trang nam: huynh - đệ, tại hạ - các hạ, ta - ngươi.",
  "ty-muoi": "Ưu tiên xưng hô cổ trang nữ: tỷ - muội, muội - tỷ, thiếp - chàng.",
  "nguoi-ta": "Ưu tiên xưng hô tiên hiệp/huyền huyễn: ta - ngươi, bản tọa, lão phu, tiểu tử.",
  "anh-em": "Ưu tiên xưng hô hiện đại thân mật: anh - em, tôi - cậu, mình - bạn.",
};

export function filterMatchingGlossary(text: string, glossaryTerms: GlossaryItem[] = []): GlossaryItem[] {
  if (!glossaryTerms.length) return [];
  const lowerText = text.toLowerCase();
  return glossaryTerms.filter((item) => lowerText.includes(item.sourceTerm.toLowerCase()));
}

export function buildTranslationPrompts(req: TranslationRequest): {
  systemPrompt: string;
  userPrompt: string;
} {
  const sourceLabel = LANG_LABELS[req.sourceLang] ?? req.sourceLang;
  const targetLabel = LANG_LABELS[req.targetLang] ?? req.targetLang;
  const styleRule = STYLE_INSTRUCTIONS[req.style] ?? STYLE_INSTRUCTIONS.NATURAL;

  const rules: string[] = [
    `Bạn là biên dịch viên chuyên nghiệp. Nhiệm vụ: dịch văn bản từ ${sourceLabel} sang ${targetLabel}.`,
    `Phong cách dịch: ${styleRule}`,
    `CHỈ trả về nội dung bản dịch thuần túy. KHÔNG thêm lời giải thích, ghi chú hay dấu ngoặc kép thừa.`,
  ];

  if (req.pronounPreset && PRONOUN_INSTRUCTIONS[req.pronounPreset]) {
    rules.push(`Quy tắc xưng hô: ${PRONOUN_INSTRUCTIONS[req.pronounPreset]}`);
  }

  if (req.customPronouns && Object.keys(req.customPronouns).length > 0) {
    const mapLines = Object.entries(req.customPronouns)
      .map(([k, v]) => `"${k}" -> "${v}"`)
      .join(", ");
    rules.push(`Bắt buộc ánh xạ xưng hô/nhân vật sau: ${mapLines}.`);
  }

  const opts = req.options ?? {};
  if (opts.preserveFormat !== false) {
    rules.push("Giữ nguyên định dạng gốc: số lần xuống dòng, thẻ HTML, cú pháp Markdown.");
  }
  if (opts.keepProperNouns) {
    rules.push("Giữ nguyên tên riêng (tên người, thương hiệu, tổ chức) theo nguyên bản, không dịch nghĩa.");
  }
  if (opts.keepNumbers) {
    rules.push("Giữ nguyên chính xác mọi con số, ngày tháng và đơn vị đo lường.");
  }
  if (opts.ignoreBraces) {
    rules.push("Giữ nguyên tuyệt đối mọi mã dạng __KEEP_BLOCK_0__, __KEEP_INLINE_0__, __KEEP_VAR_0__ không được thay đổi hay dịch.");
  }
  if (opts.grammarCheck) {
    rules.push("Rà soát lại ngữ pháp, chính tả và độ mượt của bản dịch trước khi xuất kết quả.");
  }

  const matchedTerms = filterMatchingGlossary(req.text, req.glossaryTerms);
  if (matchedTerms.length > 0) {
    const glossaryLines = matchedTerms
      .map((t) => `- "${t.sourceTerm}" => "${t.targetTerm}"${t.note ? ` (${t.note})` : ""}`)
      .join("\n");
    rules.push(`BẢNG THUẬT NGỮ BẮT BUỘC (phải dùng đúng từ đích đã chỉ định):\n${glossaryLines}`);
  }

  const systemPrompt = rules.join("\n\n");

  let userPrompt = "";
  if (req.previousContext) {
    userPrompt += `[NGỮ CẢNH ĐOẠN TRƯỚC - CHỈ ĐỂ THAM KHẢO MẠCH VĂN, KHÔNG DỊCH LẠI]:\n${req.previousContext}\n\n---\n\n`;
  }
  userPrompt += `[NỘI DUNG CẦN DỊCH]:\n${req.text}`;

  return { systemPrompt, userPrompt };
}
