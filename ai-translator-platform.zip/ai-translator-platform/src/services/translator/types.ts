import { TranslationStyle } from "@prisma/client";

export type ProviderName = "openai" | "claude" | "deepl" | "google";

export interface GlossaryItem {
  sourceTerm: string;
  targetTerm: string;
  note?: string | null;
}

export interface TranslationAdvancedOptions {
  keepProperNouns?: boolean;
  keepNumbers?: boolean;
  ignoreBraces?: boolean;
  preserveFormat?: boolean;
  grammarCheck?: boolean;
  temperature?: number;
  model?: string;
}

export interface TranslationRequest {
  text: string;
  sourceLang: string;
  targetLang: string;
  style: TranslationStyle;
  pronounPreset?: string | null;
  customPronouns?: Record<string, string> | null;
  glossaryTerms?: GlossaryItem[];
  previousContext?: string;
  options?: TranslationAdvancedOptions;
  preferredProvider?: ProviderName;
}

export interface ProviderResponse {
  translatedText: string;
  provider: ProviderName;
  model: string;
  tokenUsed: number;
}

export interface TranslationProvider {
  name: ProviderName;
  translate(
    req: TranslationRequest,
    systemPrompt: string,
    userPrompt: string,
    apiKey: string
  ): Promise<ProviderResponse>;
}
