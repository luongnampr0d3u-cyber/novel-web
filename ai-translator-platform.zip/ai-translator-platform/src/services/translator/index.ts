import { db } from "@/lib/db";
import { redis } from "@/lib/redis";
import { decryptSecret, hashSha256 } from "@/lib/crypto";
import { protectSpecialBlocks, restoreSpecialBlocks } from "./chunker";
import { buildTranslationPrompts, filterMatchingGlossary } from "./prompt-builder";
import { OpenAIProvider } from "./providers/openai";
import { ClaudeProvider } from "./providers/claude";
import { DeepLProvider } from "./providers/deepl";
import { GoogleTranslateProvider } from "./providers/google";
import { ProviderName, ProviderResponse, TranslationProvider, TranslationRequest } from "./types";

const PROVIDERS: Record<ProviderName, TranslationProvider> = {
  openai: new OpenAIProvider(),
  claude: new ClaudeProvider(),
  deepl: new DeepLProvider(),
  google: new GoogleTranslateProvider(),
};

const ENV_KEY_MAP: Record<ProviderName, string | undefined> = {
  openai: process.env.OPENAI_API_KEY,
  claude: process.env.ANTHROPIC_API_KEY,
  deepl: process.env.DEEPL_API_KEY,
  google: process.env.GOOGLE_TRANSLATE_API_KEY,
};

async function getProviderConfig(): Promise<{
  defaultProvider: ProviderName;
  fallbackOrder: ProviderName[];
  keys: Partial<Record<ProviderName, string>>;
}> {
  const config = await db.systemConfig.findUnique({ where: { id: "default" } });
  const defaultProvider = (config?.defaultProvider as ProviderName) || "openai";
  const fallbackOrder = Array.isArray(config?.fallbackOrder)
    ? (config.fallbackOrder as ProviderName[])
    : (["openai", "claude", "deepl", "google"] as ProviderName[]);

  const keys: Partial<Record<ProviderName, string>> = {};
  const storedKeys = (config?.providerKeys as Record<string, string>) || {};

  for (const name of ["openai", "claude", "deepl", "google"] as ProviderName[]) {
    if (storedKeys[name]) {
      try {
        keys[name] = decryptSecret(storedKeys[name]);
      } catch {
        keys[name] = ENV_KEY_MAP[name];
      }
    } else if (ENV_KEY_MAP[name]) {
      keys[name] = ENV_KEY_MAP[name];
    }
  }

  return { defaultProvider, fallbackOrder, keys };
}

function buildCacheHash(req: TranslationRequest): string {
  const matchedGlossary = filterMatchingGlossary(req.text, req.glossaryTerms);
  const raw = JSON.stringify({
    text: req.text,
    sourceLang: req.sourceLang,
    targetLang: req.targetLang,
    style: req.style,
    pronounPreset: req.pronounPreset ?? null,
    customPronouns: req.customPronouns ?? null,
    glossary: matchedGlossary.map((g) => `${g.sourceTerm}=${g.targetTerm}`),
    options: req.options ?? {},
  });
  return hashSha256(raw);
}

export async function translateSingleChunk(
  req: TranslationRequest
): Promise<ProviderResponse & { fromCache: boolean }> {
  const cacheHash = buildCacheHash(req);

  if (redis) {
    const cachedRedis = await redis.get<string>(`tr_cache:${cacheHash}`);
    if (cachedRedis) {
      return {
        translatedText: cachedRedis,
        provider: req.preferredProvider ?? "openai",
        model: "cache",
        tokenUsed: 0,
        fromCache: true,
      };
    }
  }

  const cachedDb = await db.translationCache.findUnique({ where: { hash: cacheHash } });
  if (cachedDb) {
    if (redis) {
      await redis.set(`tr_cache:${cacheHash}`, cachedDb.translatedText, { ex: 86400 });
    }
    return {
      translatedText: cachedDb.translatedText,
      provider: cachedDb.providerUsed as ProviderName,
      model: "cache",
      tokenUsed: 0,
      fromCache: true,
    };
  }

  const { maskedText, placeholders } = protectSpecialBlocks(
    req.text,
    Boolean(req.options?.ignoreBraces)
  );
  const maskedReq: TranslationRequest = { ...req, text: maskedText };
  const { systemPrompt, userPrompt } = buildTranslationPrompts(maskedReq);

  const { defaultProvider, fallbackOrder, keys } = await getProviderConfig();
  const order = Array.from(
    new Set<ProviderName>([
      ...(req.preferredProvider ? [req.preferredProvider] : []),
      defaultProvider,
      ...fallbackOrder,
    ])
  );

  const errors: string[] = [];

  for (const providerName of order) {
    const apiKey = keys[providerName];
    if (!apiKey) continue;

    try {
      const provider = PROVIDERS[providerName];
      const result = await provider.translate(maskedReq, systemPrompt, userPrompt, apiKey);
      const restoredText = restoreSpecialBlocks(result.translatedText, placeholders);

      await db.translationCache.upsert({
        where: { hash: cacheHash },
        update: { translatedText: restoredText, providerUsed: result.provider },
        create: {
          hash: cacheHash,
          translatedText: restoredText,
          providerUsed: result.provider,
        },
      });

      if (redis) {
        await redis.set(`tr_cache:${cacheHash}`, restoredText, { ex: 86400 });
      }

      return { ...result, translatedText: restoredText, fromCache: false };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      console.error(`[TRANSLATOR_FALLBACK] ${providerName} failed:`, msg);
      errors.push(`${providerName}: ${msg}`);
    }
  }

  throw new Error(
    errors.length > 0
      ? `Tất cả AI Provider đều lỗi: ${errors.join(" | ")}`
      : "Chưa cấu hình API Key cho bất kỳ AI Provider nào."
  );
}
