export interface ProtectedTextResult {
  maskedText: string;
  placeholders: Map<string, string>;
}

export function protectSpecialBlocks(text: string, enabled: boolean): ProtectedTextResult {
  const placeholders = new Map<string, string>();
  if (!enabled) return { maskedText: text, placeholders };

  let index = 0;
  let maskedText = text;

  maskedText = maskedText.replace(/```[\s\S]*?```/g, (match) => {
    const token = `__KEEP_BLOCK_${index++}__`;
    placeholders.set(token, match);
    return token;
  });

  maskedText = maskedText.replace(/`[^`\n]+`/g, (match) => {
    const token = `__KEEP_INLINE_${index++}__`;
    placeholders.set(token, match);
    return token;
  });

  maskedText = maskedText.replace(/\{\{[\s\S]*?\}\}/g, (match) => {
    const token = `__KEEP_VAR_${index++}__`;
    placeholders.set(token, match);
    return token;
  });

  return { maskedText, placeholders };
}

export function restoreSpecialBlocks(
  translatedText: string,
  placeholders: Map<string, string>
): string {
  let result = translatedText;
  placeholders.forEach((original, token) => {
    result = result.split(token).join(original);
  });
  return result;
}

export function splitIntoChunks(text: string, maxChunkSize = 2500): string[] {
  const normalized = text.replace(/\r\n/g, "\n").trim();
  if (!normalized) return [];
  if (normalized.length <= maxChunkSize) return [normalized];

  const paragraphs = normalized.split(/\n{2,}/);
  const chunks: string[] = [];
  let currentChunk = "";

  for (const para of paragraphs) {
    if (para.length > maxChunkSize) {
      if (currentChunk) {
        chunks.push(currentChunk.trim());
        currentChunk = "";
      }
      const sentences = para.match(/[^.!?。！？\n]+[.!?。！？\n]*/g) ?? [para];
      let tempSentenceChunk = "";
      for (const sentence of sentences) {
        if ((tempSentenceChunk + sentence).length > maxChunkSize) {
          if (tempSentenceChunk) chunks.push(tempSentenceChunk.trim());
          tempSentenceChunk = sentence;
        } else {
          tempSentenceChunk += sentence;
        }
      }
      if (tempSentenceChunk.trim()) chunks.push(tempSentenceChunk.trim());
      continue;
    }

    if ((currentChunk ? currentChunk.length + 2 : 0) + para.length > maxChunkSize) {
      if (currentChunk) chunks.push(currentChunk.trim());
      currentChunk = para;
    } else {
      currentChunk = currentChunk ? `${currentChunk}\n\n${para}` : para;
    }
  }

  if (currentChunk.trim()) chunks.push(currentChunk.trim());
  return chunks;
}

export function extractTailContext(text: string, maxChars = 300): string {
  const trimmed = text.trim();
  if (trimmed.length <= maxChars) return trimmed;
  return trimmed.slice(-maxChars);
}
