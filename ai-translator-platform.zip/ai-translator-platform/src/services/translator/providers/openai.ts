import OpenAI from "openai";
import { ProviderResponse, TranslationProvider, TranslationRequest } from "../types";

export class OpenAIProvider implements TranslationProvider {
  name = "openai" as const;

  async translate(
    req: TranslationRequest,
    systemPrompt: string,
    userPrompt: string,
    apiKey: string
  ): Promise<ProviderResponse> {
    const client = new OpenAI({ apiKey });
    const model = req.options?.model || "gpt-4o";
    const temperature =
      typeof req.options?.temperature === "number" ? req.options.temperature : 0.3;

    const completion = await client.chat.completions.create({
      model,
      temperature,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
    });

    return {
      translatedText: completion.choices[0]?.message?.content?.trim() ?? "",
      provider: this.name,
      model,
      tokenUsed: completion.usage?.total_tokens ?? 0,
    };
  }
}
