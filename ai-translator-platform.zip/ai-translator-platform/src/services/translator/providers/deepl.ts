import { ProviderResponse, TranslationProvider, TranslationRequest } from "../types";

const DEEPL_LANG_MAP: Record<string, string> = {
  "zh-CN": "ZH-HANS",
  "zh-TW": "ZH-HANT",
  zh: "ZH",
  en: "EN",
  ja: "JA",
  ko: "KO",
  vi: "VI",
};

export class DeepLProvider implements TranslationProvider {
  name = "deepl" as const;

  async translate(
    req: TranslationRequest,
    _systemPrompt: string,
    _userPrompt: string,
    apiKey: string
  ): Promise<ProviderResponse> {
    const isFreeKey = apiKey.endsWith(":fx");
    const endpoint = isFreeKey
      ? "https://api-free.deepl.com/v2/translate"
      : "https://api.deepl.com/v2/translate";

    const payload: Record<string, unknown> = {
      text: [req.text],
      target_lang: DEEPL_LANG_MAP[req.targetLang] ?? req.targetLang.toUpperCase(),
    };

    if (req.sourceLang && req.sourceLang !== "auto") {
      payload.source_lang = DEEPL_LANG_MAP[req.sourceLang] ?? req.sourceLang.toUpperCase();
    }

    const res = await fetch(endpoint, {
      method: "POST",
      headers: {
        Authorization: `DeepL-Auth-Key ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      throw new Error(`DeepL API error (${res.status}): ${await res.text()}`);
    }

    const data = (await res.json()) as { translations: Array<{ text: string }> };

    return {
      translatedText: data.translations[0]?.text?.trim() ?? "",
      provider: this.name,
      model: "deepl-v2",
      tokenUsed: Math.ceil(req.text.length / 4),
    };
  }
}
