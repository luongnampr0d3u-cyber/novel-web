import { ProviderResponse, TranslationProvider, TranslationRequest } from "../types";

export class GoogleTranslateProvider implements TranslationProvider {
  name = "google" as const;

  async translate(
    req: TranslationRequest,
    _systemPrompt: string,
    _userPrompt: string,
    apiKey: string
  ): Promise<ProviderResponse> {
    const url = `https://translation.googleapis.com/language/translate/v2?key=${encodeURIComponent(apiKey)}`;
    const body: Record<string, string> = {
      q: req.text,
      target: req.targetLang.split("-")[0],
      format: "text",
    };

    if (req.sourceLang && req.sourceLang !== "auto") {
      body.source = req.sourceLang;
    }

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      throw new Error(`Google Translate API error (${res.status}): ${await res.text()}`);
    }

    const data = (await res.json()) as {
      data: { translations: Array<{ translatedText: string }> };
    };

    return {
      translatedText: data.data.translations[0]?.translatedText?.trim() ?? "",
      provider: this.name,
      model: "google-translate-v2",
      tokenUsed: Math.ceil(req.text.length / 4),
    };
  }
}
