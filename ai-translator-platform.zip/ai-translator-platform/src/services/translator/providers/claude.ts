import Anthropic from "@anthropic-ai/sdk";
import { ProviderResponse, TranslationProvider, TranslationRequest } from "../types";

export class ClaudeProvider implements TranslationProvider {
  name = "claude" as const;

  async translate(
    req: TranslationRequest,
    systemPrompt: string,
    userPrompt: string,
    apiKey: string
  ): Promise<ProviderResponse> {
    const client = new Anthropic({ apiKey });
    const model = req.options?.model?.startsWith("claude")
      ? req.options.model
      : "claude-3-5-sonnet-20241022";
    const temperature =
      typeof req.options?.temperature === "number" ? req.options.temperature : 0.3;

    const response = await client.messages.create({
      model,
      max_tokens: 4096,
      temperature,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }],
    });

    const firstBlock = response.content[0];
    const translatedText =
      firstBlock && firstBlock.type === "text" ? firstBlock.text.trim() : "";

    return {
      translatedText,
      provider: this.name,
      model,
      tokenUsed: (response.usage?.input_tokens ?? 0) + (response.usage?.output_tokens ?? 0),
    };
  }
}
