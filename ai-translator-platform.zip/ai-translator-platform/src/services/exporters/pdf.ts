import fs from "fs/promises";
import path from "path";
import { PDFDocument, PDFFont, StandardFonts, rgb } from "pdf-lib";
import fontkit from "@pdf-lib/fontkit";
import { buildSafeFileName, ExportedFile, ExportPayload } from "./types";

function wrapText(text: string, font: PDFFont, fontSize: number, maxWidth: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let currentLine = "";
  for (const word of words) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    if (font.widthOfTextAtSize(testLine, fontSize) > maxWidth && currentLine) {
      lines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }
  if (currentLine) lines.push(currentLine);
  return lines;
}

export async function exportPdfFile(payload: ExportPayload): Promise<ExportedFile> {
  const pdfDoc = await PDFDocument.create();
  pdfDoc.registerFontkit(fontkit);

  let font: PDFFont;
  let hasUnicodeFont = false;
  const fontPath = path.join(process.cwd(), "public", "fonts", "NotoSans-Regular.ttf");

  try {
    font = await pdfDoc.embedFont(await fs.readFile(fontPath));
    hasUnicodeFont = true;
  } catch {
    font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  }

  const pageWidth = 595.28;
  const pageHeight = 841.89;
  const margin = 50;
  const maxWidth = pageWidth - margin * 2;
  let page = pdfDoc.addPage([pageWidth, pageHeight]);
  let cursorY = pageHeight - margin;

  const sanitize = (str: string) =>
    hasUnicodeFont ? str : str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\x20-\x7E]/g, " ");

  const drawLines = (lines: string[], size: number, color = rgb(0.1, 0.1, 0.15)) => {
    for (const line of lines) {
      if (cursorY < margin + 18) {
        page = pdfDoc.addPage([pageWidth, pageHeight]);
        cursorY = pageHeight - margin;
      }
      page.drawText(line, { x: margin, y: cursorY, size, font, color });
      cursorY -= size * 1.55;
    }
  };

  drawLines(wrapText(sanitize(payload.title), font, 16, maxWidth), 16, rgb(0.05, 0.2, 0.45));
  cursorY -= 12;

  for (const para of payload.translatedText.split(/\n{2,}/)) {
    const clean = sanitize(para.trim().replace(/\n/g, " "));
    if (!clean) continue;
    drawLines(wrapText(clean, font, 11.5, maxWidth), 11.5);
    cursorY -= 8;
  }

  return {
    buffer: Buffer.from(await pdfDoc.save()),
    fileName: buildSafeFileName(payload.title, payload.targetLang, "pdf"),
    mimeType: "application/pdf",
  };
}
