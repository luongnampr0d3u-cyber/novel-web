import JSZip from "jszip";
import { exportTextFile, exportHtmlFile } from "./text";
import { exportDocxFile } from "./docx";
import { exportPdfFile } from "./pdf";
import { exportEpubFile } from "./epub";
import { ExportedFile, ExportFormat, ExportPayload } from "./types";

export const SUPPORTED_EXPORT_FORMATS: ExportFormat[] = [
  "txt", "md", "html", "docx", "pdf", "epub", "srt", "ass",
];

export async function exportTranslation(payload: ExportPayload, format: ExportFormat): Promise<ExportedFile> {
  switch (format) {
    case "txt":
    case "md":
    case "srt":
    case "ass": return exportTextFile(payload, format);
    case "html": return exportHtmlFile(payload);
    case "docx": return exportDocxFile(payload);
    case "pdf": return exportPdfFile(payload);
    case "epub": return exportEpubFile(payload);
    default: throw new Error(`Định dạng xuất "${format}" không được hỗ trợ.`);
  }
}

export async function exportBatchZip(
  items: Array<{ payload: ExportPayload; format: ExportFormat }>
): Promise<ExportedFile> {
  const zip = new JSZip();
  const usedNames = new Set<string>();

  for (const item of items) {
    const exported = await exportTranslation(item.payload, item.format);
    let finalName = exported.fileName;
    let counter = 1;
    while (usedNames.has(finalName)) {
      const dotIdx = exported.fileName.lastIndexOf(".");
      finalName = `${exported.fileName.slice(0, dotIdx)}_${counter++}${exported.fileName.slice(dotIdx)}`;
    }
    usedNames.add(finalName);
    zip.file(finalName, exported.buffer);
  }

  return {
    buffer: await zip.generateAsync({ type: "nodebuffer" }),
    fileName: `batch_export_${Date.now()}.zip`,
    mimeType: "application/zip",
  };
}
