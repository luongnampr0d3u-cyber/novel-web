import { buildSafeFileName, escapeHtml, ExportedFile, ExportPayload } from "./types";

function buildCombinedPlainText(payload: ExportPayload): string {
  if (!payload.bilingual) return payload.translatedText;
  const srcParas = payload.sourceText.split(/\n{2,}/);
  const tgtParas = payload.translatedText.split(/\n{2,}/);
  const maxLen = Math.max(srcParas.length, tgtParas.length);
  const blocks: string[] = [];
  for (let i = 0; i < maxLen; i++) {
    if (srcParas[i]) blocks.push(srcParas[i].trim());
    if (tgtParas[i]) blocks.push(tgtParas[i].trim());
    blocks.push("");
  }
  return blocks.join("\n").trim();
}

export function exportTextFile(
  payload: ExportPayload,
  format: "txt" | "md" | "srt" | "ass"
): ExportedFile {
  let content = "";
  if (format === "md") content = `# ${payload.title}\n\n${buildCombinedPlainText(payload)}`;
  else if (format === "srt" || format === "ass") content = payload.translatedText;
  else content = buildCombinedPlainText(payload);

  const mimeMap = {
    txt: "text/plain; charset=utf-8",
    md: "text/markdown; charset=utf-8",
    srt: "application/x-subrip; charset=utf-8",
    ass: "text/plain; charset=utf-8",
  };

  return {
    buffer: Buffer.from("\uFEFF" + content, "utf-8"),
    fileName: buildSafeFileName(payload.title, payload.targetLang, format),
    mimeType: mimeMap[format],
  };
}

export function exportHtmlFile(payload: ExportPayload): ExportedFile {
  const safeTitle = escapeHtml(payload.title);
  let bodyHtml = payload.translatedText
    .split(/\n{2,}/)
    .map((p) => `<p>${escapeHtml(p.trim()).replace(/\n/g, "<br/>")}</p>`)
    .join("\n    ");

  if (payload.bilingual) {
    const srcParas = payload.sourceText.split(/\n{2,}/);
    const tgtParas = payload.translatedText.split(/\n{2,}/);
    const maxLen = Math.max(srcParas.length, tgtParas.length);
    const rows: string[] = [];
    for (let i = 0; i < maxLen; i++) {
      rows.push(`<div class="pair"><div class="src">${escapeHtml((srcParas[i] ?? "").trim()).replace(/\n/g, "<br/>")}</div><div class="tgt">${escapeHtml((tgtParas[i] ?? "").trim()).replace(/\n/g, "<br/>")}</div></div>`);
    }
    bodyHtml = rows.join("\n");
  }

  const html = `<!DOCTYPE html><html lang="${escapeHtml(payload.targetLang)}"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/><title>${safeTitle}</title><style>body{font-family:Georgia,serif;max-width:820px;margin:40px auto;padding:0 20px;line-height:1.8;color:#1e293b;background:#f8fafc}h1{font-family:system-ui,sans-serif;border-bottom:1px solid #cbd5e1;padding-bottom:12px}.pair{display:grid;grid-template-columns:1fr 1fr;gap:20px;padding:14px 0;border-bottom:1px solid #e2e8f0}.src{color:#64748b}@media(max-width:640px){.pair{grid-template-columns:1fr}}</style></head><body><h1>${safeTitle}</h1>${bodyHtml}</body></html>`;

  return {
    buffer: Buffer.from(html, "utf-8"),
    fileName: buildSafeFileName(payload.title, payload.targetLang, "html"),
    mimeType: "text/html; charset=utf-8",
  };
}
