import { Document, HeadingLevel, Packer, Paragraph, TextRun } from "docx";
import { buildSafeFileName, ExportedFile, ExportPayload } from "./types";

export async function exportDocxFile(payload: ExportPayload): Promise<ExportedFile> {
  const children: Paragraph[] = [
    new Paragraph({ text: payload.title, heading: HeadingLevel.HEADING_1, spacing: { after: 300 } }),
  ];

  if (payload.bilingual) {
    const srcParas = payload.sourceText.split(/\n{2,}/);
    const tgtParas = payload.translatedText.split(/\n{2,}/);
    const maxLen = Math.max(srcParas.length, tgtParas.length);
    for (let i = 0; i < maxLen; i++) {
      if (srcParas[i]?.trim()) {
        children.push(new Paragraph({ spacing: { after: 80 }, children: [new TextRun({ text: srcParas[i].trim(), color: "64748B", italics: true, size: 22 })] }));
      }
      if (tgtParas[i]?.trim()) {
        children.push(new Paragraph({ spacing: { after: 240 }, children: [new TextRun({ text: tgtParas[i].trim(), size: 24 })] }));
      }
    }
  } else {
    for (const para of payload.translatedText.split(/\n{2,}/)) {
      const trimmed = para.trim();
      if (!trimmed) continue;
      if (trimmed.startsWith("### ")) {
        children.push(new Paragraph({ text: trimmed.replace(/^###\s+/, ""), heading: HeadingLevel.HEADING_2, spacing: { before: 240, after: 160 } }));
      } else {
        children.push(new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: trimmed, size: 24 })] }));
      }
    }
  }

  const doc = new Document({ sections: [{ children }] });
  const buffer = await Packer.toBuffer(doc);
  return {
    buffer: Buffer.from(buffer),
    fileName: buildSafeFileName(payload.title, payload.targetLang, "docx"),
    mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  };
}
