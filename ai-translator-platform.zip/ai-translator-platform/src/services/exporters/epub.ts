import epub from "epub-gen-memory";
import { buildSafeFileName, escapeHtml, ExportedFile, ExportPayload } from "./types";

export async function exportEpubFile(payload: ExportPayload): Promise<ExportedFile> {
  const chapters =
    payload.chapters && payload.chapters.length > 0
      ? payload.chapters.map((ch) => ({
          title: ch.title,
          content: ch.targetContent.split(/\n{2,}/).map((p) => `<p>${escapeHtml(p.trim()).replace(/\n/g, "<br/>")}</p>`).join("\n"),
        }))
      : [
          {
            title: payload.title,
            content: payload.translatedText.split(/\n{2,}/).map((p) => `<p>${escapeHtml(p.trim()).replace(/\n/g, "<br/>")}</p>`).join("\n"),
          },
        ];

  const buffer = await epub(
    {
      title: payload.title,
      author: "AI Translator Platform",
      lang: payload.targetLang.split("-")[0] || "vi",
      tocTitle: "Mục lục",
    },
    chapters
  );

  return {
    buffer: Buffer.from(buffer),
    fileName: buildSafeFileName(payload.title, payload.targetLang, "epub"),
    mimeType: "application/epub+zip",
  };
}
