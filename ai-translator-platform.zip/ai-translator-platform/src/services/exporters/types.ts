export type ExportFormat = "txt" | "md" | "html" | "docx" | "pdf" | "epub" | "srt" | "ass";

export interface ExportChapter {
  title: string;
  sourceContent?: string;
  targetContent: string;
}

export interface ExportPayload {
  title: string;
  targetLang: string;
  sourceText: string;
  translatedText: string;
  chapters?: ExportChapter[];
  bilingual?: boolean;
}

export interface ExportedFile {
  buffer: Buffer;
  fileName: string;
  mimeType: string;
}

export function buildSafeFileName(title: string, targetLang: string, format: ExportFormat): string {
  const cleanTitle = title
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .replace(/[^a-zA-Z0-9\s_-]/g, "")
    .trim()
    .replace(/\s+/g, "_")
    .slice(0, 60);

  const safeBase = cleanTitle || "BanDich";
  const langCode = targetLang.split("-")[0].toLowerCase() || "vi";
  return `${safeBase}_${langCode}.${format}`;
}

export function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
