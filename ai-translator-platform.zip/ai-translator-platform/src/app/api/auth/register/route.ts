import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "@/lib/db";

const registerSchema = z.object({
  name: z.string().min(2, "Tên phải có ít nhất 2 ký tự").max(60),
  email: z.string().email("Email không hợp lệ"),
  password: z.string().min(6, "Mật khẩu phải có ít nhất 6 ký tự").max(100),
});

export async function POST(req: Request) {
  try {
    const config = await db.systemConfig.findUnique({ where: { id: "default" } });
    if (config && !config.allowRegister) {
      return NextResponse.json({ error: "Hệ thống hiện đang tạm đóng đăng ký." }, { status: 403 });
    }
    const parsed = registerSchema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ." }, { status: 400 });
    }
    const email = parsed.data.email.toLowerCase().trim();
    if (await db.user.findUnique({ where: { email } })) {
      return NextResponse.json({ error: "Email này đã được đăng ký." }, { status: 409 });
    }
    const passwordHash = await bcrypt.hash(parsed.data.password, 12);
    const user = await db.user.create({
      data: { name: parsed.data.name.trim(), email, passwordHash },
      select: { id: true, name: true, email: true, role: true, plan: true },
    });
    return NextResponse.json({ user }, { status: 201 });
  } catch (error) {
    console.error("[REGISTER_ERROR]", error);
    return NextResponse.json({ error: "Có lỗi xảy ra khi đăng ký." }, { status: 500 });
  }
}
