import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

const termSchema = z.object({
  sourceTerm: z.string().min(1).max(120),
  targetTerm: z.string().min(1).max(120),
  note: z.string().max(200).optional(),
});

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
  const glossary = await db.glossary.findFirst({ where: { id: params.id, userId: session.user.id } });
  if (!glossary) return NextResponse.json({ error: "Không tìm thấy." }, { status: 404 });
  const parsed = termSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Dữ liệu không hợp lệ." }, { status: 400 });

  const term = await db.glossaryTerm.upsert({
    where: { glossaryId_sourceTerm: { glossaryId: glossary.id, sourceTerm: parsed.data.sourceTerm.trim() } },
    update: { targetTerm: parsed.data.targetTerm.trim(), note: parsed.data.note?.trim() || null },
    create: { glossaryId: glossary.id, sourceTerm: parsed.data.sourceTerm.trim(), targetTerm: parsed.data.targetTerm.trim(), note: parsed.data.note?.trim() || null },
  });
  return NextResponse.json({ term }, { status: 201 });
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
  const { termId } = (await req.json()) as { termId: string };
  const glossary = await db.glossary.findFirst({ where: { id: params.id, userId: session.user.id } });
  if (!glossary) return NextResponse.json({ error: "Không có quyền." }, { status: 403 });
  await db.glossaryTerm.delete({ where: { id: termId } });
  return NextResponse.json({ success: true });
}
