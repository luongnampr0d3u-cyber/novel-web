import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
  const deleted = await db.glossary.deleteMany({ where: { id: params.id, userId: session.user.id } });
  if (!deleted.count) return NextResponse.json({ error: "Không tìm thấy." }, { status: 404 });
  return NextResponse.json({ success: true });
}
