import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

const createGlossarySchema = z.object({
  name: z.string().min(2).max(100),
  description: z.string().max(300).optional(),
  sourceLang: z.string().default("zh"),
  targetLang: z.string().default("vi"),
});

export async function GET() {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  const glossaries = await db.glossary.findMany({
    where: userId ? { OR: [{ userId }, { isPublic: true }] } : { isPublic: true },
    orderBy: [{ isPublic: "asc" }, { createdAt: "desc" }],
    include: { terms: { orderBy: { sourceTerm: "asc" } } },
  });
  return NextResponse.json({ glossaries });
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
  const parsed = createGlossarySchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Dữ liệu không hợp lệ." }, { status: 400 });

  const glossary = await db.glossary.create({
    data: {
      userId: session.user.id,
      name: parsed.data.name.trim(),
      description: parsed.data.description?.trim() || null,
      sourceLang: parsed.data.sourceLang,
      targetLang: parsed.data.targetLang,
      isPublic: false,
    },
    include: { terms: true },
  });
  return NextResponse.json({ glossary }, { status: 201 });
}
