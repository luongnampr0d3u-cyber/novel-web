import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
  const [user, config] = await Promise.all([
    db.user.findUnique({
      where: { id: session.user.id },
      select: {
        id: true, name: true, email: true, role: true, plan: true,
        dailyCharUsed: true, monthlyCharUsed: true, createdAt: true,
        apiKeys: {
          orderBy: { createdAt: "desc" },
          select: { id: true, name: true, keyPrefix: true, lastUsedAt: true, isActive: true, createdAt: true },
        },
      },
    }),
    db.systemConfig.findUnique({
      where: { id: "default" },
      select: { freeDailyChars: true, proMonthlyChars: true, maxFileSizeMb: true },
    }),
  ]);
  if (!user) return NextResponse.json({ error: "Không tìm thấy." }, { status: 404 });
  return NextResponse.json({
    user,
    limits: {
      freeDailyChars: config?.freeDailyChars ?? 5000,
      proMonthlyChars: config?.proMonthlyChars ?? 500000,
      maxFileSizeMb: config?.maxFileSizeMb ?? 20,
    },
  });
}
