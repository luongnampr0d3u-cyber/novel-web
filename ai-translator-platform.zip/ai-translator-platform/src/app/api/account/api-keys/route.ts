import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { generateDeveloperApiKey } from "@/lib/crypto";

const createKeySchema = z.object({ name: z.string().min(2).max(60) });

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
  const parsed = createKeySchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Tên không hợp lệ." }, { status: 400 });
  const { rawKey, keyHash, keyPrefix } = generateDeveloperApiKey();
  const apiKey = await db.apiKey.create({
    data: { userId: session.user.id, name: parsed.data.name.trim(), keyHash, keyPrefix },
    select: { id: true, name: true, keyPrefix: true, isActive: true, createdAt: true },
  });
  return NextResponse.json({ apiKey, rawKey }, { status: 201 });
}

export async function DELETE(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
  const { keyId } = (await req.json()) as { keyId: string };
  await db.apiKey.deleteMany({ where: { id: keyId, userId: session.user.id } });
  return NextResponse.json({ success: true });
}
