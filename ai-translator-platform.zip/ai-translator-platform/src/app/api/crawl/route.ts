import { NextResponse } from "next/server";
import { z } from "zod";
import { crawlWebContent } from "@/services/parsers/crawler";

const crawlSchema = z.object({ url: z.string().url("URL không hợp lệ.") });

export async function POST(req: Request) {
  try {
    const parsed = crawlSchema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "URL không hợp lệ." }, { status: 400 });
    }
    return NextResponse.json(await crawlWebContent(parsed.data.url));
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Lỗi crawl URL." }, { status: 400 });
  }
}
