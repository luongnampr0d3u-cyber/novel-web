import { NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/admin";
import { db } from "@/lib/db";
import { encryptSecret } from "@/lib/crypto";

const configSchema = z.object({
  defaultProvider: z.enum(["openai", "claude", "deepl", "google"]).optional(),
  fallbackOrder: z.array(z.enum(["openai", "claude", "deepl", "google"])).optional(),
  providerKeys: z.object({
    openai: z.string().optional(),
    claude: z.string().optional(),
    deepl: z.string().optional(),
    google: z.string().optional(),
  }).optional(),
  maxFileSizeMb: z.number().int().min(1).max(100).optional(),
  freeDailyChars: z.number().int().min(500).max(1000000).optional(),
  proMonthlyChars: z.number().int().min(10000).max(50000000).optional(),
  allowRegister: z.boolean().optional(),
  maintenanceMode: z.boolean().optional(),
});

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const config = await db.systemConfig.findUnique({ where: { id: "default" } });
  const storedKeys = (config?.providerKeys as Record<string, string>) || {};
  return NextResponse.json({
    config: {
      defaultProvider: config?.defaultProvider ?? "openai",
      fallbackOrder: config?.fallbackOrder ?? ["openai", "claude", "deepl", "google"],
      configuredKeys: {
        openai: Boolean(storedKeys.openai || process.env.OPENAI_API_KEY),
        claude: Boolean(storedKeys.claude || process.env.ANTHROPIC_API_KEY),
        deepl: Boolean(storedKeys.deepl || process.env.DEEPL_API_KEY),
        google: Boolean(storedKeys.google || process.env.GOOGLE_TRANSLATE_API_KEY),
      },
      maxFileSizeMb: config?.maxFileSizeMb ?? 20,
      freeDailyChars: config?.freeDailyChars ?? 5000,
      proMonthlyChars: config?.proMonthlyChars ?? 500000,
      allowRegister: config?.allowRegister ?? true,
      maintenanceMode: config?.maintenanceMode ?? false,
    },
  });
}

export async function PATCH(req: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const parsed = configSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid config" }, { status: 400 });

  const existing = await db.systemConfig.findUnique({ where: { id: "default" } });
  const nextKeys: Record<string, string> = { ...((existing?.providerKeys as Record<string, string>) || {}) };
  if (parsed.data.providerKeys) {
    for (const [provider, rawKey] of Object.entries(parsed.data.providerKeys)) {
      if (rawKey && rawKey.trim()) nextKeys[provider] = encryptSecret(rawKey.trim());
    }
  }

  await db.systemConfig.upsert({
    where: { id: "default" },
    update: {
      ...(parsed.data.defaultProvider ? { defaultProvider: parsed.data.defaultProvider } : {}),
      ...(parsed.data.fallbackOrder ? { fallbackOrder: parsed.data.fallbackOrder } : {}),
      providerKeys: nextKeys,
      ...(typeof parsed.data.maxFileSizeMb === "number" ? { maxFileSizeMb: parsed.data.maxFileSizeMb } : {}),
      ...(typeof parsed.data.freeDailyChars === "number" ? { freeDailyChars: parsed.data.freeDailyChars } : {}),
      ...(typeof parsed.data.proMonthlyChars === "number" ? { proMonthlyChars: parsed.data.proMonthlyChars } : {}),
      ...(typeof parsed.data.allowRegister === "boolean" ? { allowRegister: parsed.data.allowRegister } : {}),
      ...(typeof parsed.data.maintenanceMode === "boolean" ? { maintenanceMode: parsed.data.maintenanceMode } : {}),
    },
    create: {
      id: "default",
      defaultProvider: parsed.data.defaultProvider ?? "openai",
      fallbackOrder: parsed.data.fallbackOrder ?? ["openai", "claude", "deepl", "google"],
      providerKeys: nextKeys,
      maxFileSizeMb: parsed.data.maxFileSizeMb ?? 20,
      freeDailyChars: parsed.data.freeDailyChars ?? 5000,
      proMonthlyChars: parsed.data.proMonthlyChars ?? 500000,
      allowRegister: parsed.data.allowRegister ?? true,
      maintenanceMode: parsed.data.maintenanceMode ?? false,
    },
  });
  return NextResponse.json({ success: true });
}
