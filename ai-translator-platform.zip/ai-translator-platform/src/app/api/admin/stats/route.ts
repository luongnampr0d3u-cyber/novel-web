import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin";
import { db } from "@/lib/db";

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const [totalUsers, proUsers, totalJobs, tokenAgg] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { plan: "PRO" } }),
    db.translationJob.count(),
    db.translationJob.aggregate({ _sum: { tokenUsed: true, charCount: true } }),
  ]);
  return NextResponse.json({
    stats: {
      totalUsers, proUsers, totalJobs,
      totalTokens: tokenAgg._sum.tokenUsed ?? 0,
      totalChars: tokenAgg._sum.charCount ?? 0,
    },
  });
}
