import { NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/admin";
import { db } from "@/lib/db";

const updateUserSchema = z.object({
  userId: z.string().min(1),
  role: z.enum(["USER", "ADMIN"]).optional(),
  plan: z.enum(["FREE", "PRO"]).optional(),
  isBanned: z.boolean().optional(),
  resetQuota: z.boolean().optional(),
});

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const users = await db.user.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    select: {
      id: true, name: true, email: true, role: true, plan: true,
      isBanned: true, dailyCharUsed: true, monthlyCharUsed: true,
      createdAt: true, _count: { select: { jobs: true } },
    },
  });
  return NextResponse.json({ users });
}

export async function PATCH(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const parsed = updateUserSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid data" }, { status: 400 });
  const { userId, role, plan, isBanned, resetQuota } = parsed.data;
  if (userId === admin.id && isBanned) {
    return NextResponse.json({ error: "Không thể tự khóa tài khoản của bạn." }, { status: 400 });
  }
  const updated = await db.user.update({
    where: { id: userId },
    data: {
      ...(role ? { role } : {}),
      ...(plan ? { plan } : {}),
      ...(typeof isBanned === "boolean" ? { isBanned } : {}),
      ...(resetQuota ? { dailyCharUsed: 0, monthlyCharUsed: 0, quotaResetAt: new Date() } : {}),
    },
  });
  return NextResponse.json({ user: updated });
}
