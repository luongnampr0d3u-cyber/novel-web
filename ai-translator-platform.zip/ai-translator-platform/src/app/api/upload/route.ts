import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { parseUploadedFile } from "@/services/parsers";

export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const file = formData.get("file");
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: "Vui lòng chọn file." }, { status: 400 });
    }
    const config = await db.systemConfig.findUnique({ where: { id: "default" } });
    const maxMb = config?.maxFileSizeMb ?? 20;
    if (file.size > maxMb * 1024 * 1024) {
      return NextResponse.json({ error: `Dung lượng file vượt quá ${maxMb}MB.` }, { status: 413 });
    }
    const buffer = Buffer.from(await file.arrayBuffer());
    const parsed = await parseUploadedFile(buffer, file.name);
    return NextResponse.json({ fileName: file.name, fileSize: file.size, ...parsed });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Lỗi đọc file." }, { status: 400 });
  }
}
