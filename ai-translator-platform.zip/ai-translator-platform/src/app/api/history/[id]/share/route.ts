import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import crypto from "crypto";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
  const { isPublic } = (await req.json()) as { isPublic: boolean };
  const job = await db.translationJob.findFirst({ where: { id: params.id, userId: session.user.id } });
  if (!job) return NextResponse.json({ error: "Không tìm thấy." }, { status: 404 });

  const shareSlug = job.shareSlug || crypto.randomBytes(6).toString("hex");
  const updated = await db.translationJob.update({
    where: { id: job.id },
    data: { isPublic, isSaved: true, expiresAt: null, shareSlug },
    select: { id: true, isPublic: true, shareSlug: true },
  });
  return NextResponse.json({ ...updated, shareUrl: `${process.env.NEXTAUTH_URL || ""}/share/${updated.shareSlug}` });
}
