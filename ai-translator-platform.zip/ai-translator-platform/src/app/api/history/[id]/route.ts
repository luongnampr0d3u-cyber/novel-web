import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
  const { isSaved } = (await req.json()) as { isSaved: boolean };
  const job = await db.translationJob.findFirst({ where: { id: params.id, userId: session.user.id } });
  if (!job) return NextResponse.json({ error: "Không tìm thấy." }, { status: 404 });

  const updated = await db.translationJob.update({
    where: { id: job.id },
    data: { isSaved, expiresAt: isSaved ? null : new Date(Date.now() + 24 * 60 * 60 * 1000) },
    select: { id: true, isSaved: true },
  });
  return NextResponse.json({ job: updated });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
  const deleted = await db.translationJob.deleteMany({ where: { id: params.id, userId: session.user.id } });
  if (!deleted.count) return NextResponse.json({ error: "Không tìm thấy." }, { status: 404 });
  return NextResponse.json({ success: true });
}
