import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim() || "";
  const onlySaved = searchParams.get("saved") === "true";

  const jobs = await db.translationJob.findMany({
    where: {
      userId: session.user.id,
      ...(onlySaved ? { isSaved: true } : {}),
      ...(q ? { title: { contains: q, mode: "insensitive" } } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: 50,
    select: {
      id: true, title: true, inputType: true, sourceLang: true, targetLang: true,
      style: true, status: true, progress: true, charCount: true, tokenUsed: true,
      providerUsed: true, isSaved: true, isPublic: true, shareSlug: true, createdAt: true,
    },
  });
  return NextResponse.json({ jobs });
}
