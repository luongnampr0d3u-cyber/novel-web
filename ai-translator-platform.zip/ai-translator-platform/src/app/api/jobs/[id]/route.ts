import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const job = await db.translationJob.findUnique({
      where: { id: params.id },
      include: {
        chunks: {
          orderBy: { index: "asc" },
          select: { id: true, index: true, chapterTitle: true, sourceContent: true, targetContent: true, status: true },
        },
      },
    });
    if (!job) return NextResponse.json({ error: "Không tìm thấy tiến trình." }, { status: 404 });
    return NextResponse.json({ job });
  } catch {
    return NextResponse.json({ error: "Lỗi máy chủ." }, { status: 500 });
  }
}
