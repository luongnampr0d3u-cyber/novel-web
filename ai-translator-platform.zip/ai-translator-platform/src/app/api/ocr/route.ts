import { NextResponse } from "next/server";
import { extractTextFromImage } from "@/services/parsers/ocr";

const ALLOWED_TYPES = ["image/png", "image/jpeg", "image/webp", "image/bmp"];

export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const file = formData.get("file");
    const lang = (formData.get("lang") as string) || "auto";
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: "Vui lòng tải ảnh lên." }, { status: 400 });
    }
    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json({ error: "Chỉ hỗ trợ ảnh PNG, JPG, WEBP, BMP." }, { status: 400 });
    }
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json({ error: "Ảnh tối đa 10MB." }, { status: 413 });
    }
    const buffer = Buffer.from(await file.arrayBuffer());
    return NextResponse.json(await extractTextFromImage(buffer, lang));
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Lỗi OCR." }, { status: 500 });
  }
}
