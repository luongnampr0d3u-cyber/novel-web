import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { exportBatchZip } from "@/services/exporters";
import { ExportFormat } from "@/services/exporters/types";

const batchSchema = z.object({
  jobIds: z.array(z.string()).min(1).max(20),
  format: z.enum(["txt", "md", "html", "docx", "pdf", "epub", "srt", "ass"]).default("docx"),
  bilingual: z.boolean().default(false),
});

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });
    const parsed = batchSchema.safeParse(await req.json());
    if (!parsed.success) return NextResponse.json({ error: "Danh sách không hợp lệ." }, { status: 400 });

    const jobs = await db.translationJob.findMany({
      where: { id: { in: parsed.data.jobIds }, userId: session.user.id, status: "COMPLETED" },
      include: { chunks: { orderBy: { index: "asc" } } },
    });
    if (!jobs.length) return NextResponse.json({ error: "Không có bản dịch hợp lệ." }, { status: 404 });

    const exportedZip = await exportBatchZip(
      jobs.map((job) => ({
        format: parsed.data.format as ExportFormat,
        payload: {
          title: job.title,
          targetLang: job.targetLang,
          sourceText: job.sourceText ?? "",
          translatedText: job.translatedText ?? "",
          bilingual: parsed.data.bilingual,
          chapters: job.chunks.length > 1
            ? job.chunks.map((c, idx) => ({ title: c.chapterTitle || `Phần ${idx + 1}`, sourceContent: c.sourceContent, targetContent: c.targetContent || "" }))
            : undefined,
        },
      }))
    );

    return new NextResponse(new Uint8Array(exportedZip.buffer), {
      status: 200,
      headers: {
        "Content-Type": exportedZip.mimeType,
        "Content-Disposition": `attachment; filename="${exportedZip.fileName}"`,
      },
    });
  } catch {
    return NextResponse.json({ error: "Lỗi xuất hàng loạt." }, { status: 500 });
  }
}
