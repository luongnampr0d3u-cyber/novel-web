import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { exportTranslation, SUPPORTED_EXPORT_FORMATS } from "@/services/exporters";
import { ExportFormat } from "@/services/exporters/types";

export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const { searchParams } = new URL(req.url);
    const format = (searchParams.get("format") || "txt").toLowerCase() as ExportFormat;
    const bilingual = searchParams.get("bilingual") === "true";
    if (!SUPPORTED_EXPORT_FORMATS.includes(format)) {
      return NextResponse.json({ error: "Định dạng không hợp lệ." }, { status: 400 });
    }
    const job = await db.translationJob.findUnique({
      where: { id: params.id },
      include: { chunks: { orderBy: { index: "asc" } } },
    });
    if (!job || !job.translatedText) {
      return NextResponse.json({ error: "Không tìm thấy bản dịch." }, { status: 404 });
    }
    const chapters = job.chunks.length > 1
      ? job.chunks.map((c, idx) => ({ title: c.chapterTitle || `Phần ${idx + 1}`, sourceContent: c.sourceContent, targetContent: c.targetContent || "" }))
      : undefined;
    const exported = await exportTranslation(
      { title: job.title, targetLang: job.targetLang, sourceText: job.sourceText ?? "", translatedText: job.translatedText, chapters, bilingual },
      format
    );
    return new NextResponse(new Uint8Array(exported.buffer), {
      status: 200,
      headers: {
        "Content-Type": exported.mimeType,
        "Content-Disposition": `attachment; filename="${exported.fileName}"`,
      },
    });
  } catch {
    return NextResponse.json({ error: "Lỗi xuất file." }, { status: 500 });
  }
}
