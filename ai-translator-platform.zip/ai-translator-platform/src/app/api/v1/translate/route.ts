import { NextResponse } from "next/server";
import { z } from "zod";
import { TranslationStyle } from "@prisma/client";
import { db } from "@/lib/db";
import { hashSha256 } from "@/lib/crypto";
import { publicApiRateLimit } from "@/lib/redis";
import { checkAndConsumeQuota } from "@/lib/quota";
import { translateSingleChunk } from "@/services/translator";

const publicSchema = z.object({
  text: z.string().min(1).max(10000),
  sourceLang: z.string().default("auto"),
  targetLang: z.string().default("vi"),
  style: z.nativeEnum(TranslationStyle).default(TranslationStyle.NATURAL),
  pronounPreset: z.string().optional(),
  customPronouns: z.record(z.string()).optional(),
});

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Thiếu Authorization: Bearer <API_KEY>" }, { status: 401 });
    }
    const keyHash = hashSha256(authHeader.slice(7).trim());
    const apiKey = await db.apiKey.findUnique({ where: { keyHash }, include: { user: true } });
    if (!apiKey || !apiKey.isActive || apiKey.user.isBanned) {
      return NextResponse.json({ error: "API Key không hợp lệ." }, { status: 401 });
    }
    if (publicApiRateLimit) {
      const { success } = await publicApiRateLimit.limit(apiKey.id);
      if (!success) return NextResponse.json({ error: "Vượt giới hạn 60 requests/phút." }, { status: 429 });
    }
    const parsed = publicSchema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Payload không hợp lệ." }, { status: 400 });
    }
    await checkAndConsumeQuota(apiKey.userId, parsed.data.text.length);
    const result = await translateSingleChunk(parsed.data);
    await db.apiKey.update({ where: { id: apiKey.id }, data: { lastUsedAt: new Date() } });
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Translation failed" }, { status: 500 });
  }
}
