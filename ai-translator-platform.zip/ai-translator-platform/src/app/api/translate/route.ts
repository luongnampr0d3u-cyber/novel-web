import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { TranslationStyle } from "@prisma/client";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { translateRateLimit } from "@/lib/redis";
import { checkAndConsumeQuota } from "@/lib/quota";
import { inngest } from "@/lib/inngest";
import { splitIntoChunks } from "@/services/translator/chunker";
import { translateSingleChunk } from "@/services/translator";
import { ProviderName } from "@/services/translator/types";

const translateBodySchema = z.object({
  title: z.string().max(200).optional(),
  text: z.string().min(1, "Vui lòng nhập nội dung cần dịch."),
  inputType: z.enum(["TEXT", "FILE", "URL", "OCR"]).default("TEXT"),
  sourceLang: z.string().default("auto"),
  targetLang: z.string().default("vi"),
  style: z.nativeEnum(TranslationStyle).default(TranslationStyle.NATURAL),
  pronounPreset: z.string().nullable().optional(),
  customPronouns: z.record(z.string()).nullable().optional(),
  glossaryId: z.string().nullable().optional(),
  provider: z.enum(["openai", "claude", "deepl", "google"]).optional(),
  options: z.object({
    keepProperNouns: z.boolean().optional(),
    keepNumbers: z.boolean().optional(),
    ignoreBraces: z.boolean().optional(),
    preserveFormat: z.boolean().optional(),
    grammarCheck: z.boolean().optional(),
    temperature: z.number().min(0).max(1.5).optional(),
    model: z.string().optional(),
  }).optional(),
});

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    const ip = req.headers.get("x-forwarded-for") ?? "anonymous";
    if (translateRateLimit) {
      const { success } = await translateRateLimit.limit(session?.user?.id ?? ip);
      if (!success) {
        return NextResponse.json({ error: "Thao tác quá nhanh. Vui lòng thử lại sau 1 phút." }, { status: 429 });
      }
    }

    const parsed = translateBodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ." }, { status: 400 });
    }

    const data = parsed.data;
    const charCount = data.text.length;

    if (session?.user?.id) {
      await checkAndConsumeQuota(session.user.id, charCount);
    } else if (charCount > 2000) {
      return NextResponse.json({ error: "Khách vãng lai chỉ được dịch tối đa 2.000 ký tự. Vui lòng đăng nhập." }, { status: 401 });
    }

    let glossaryTerms: Array<{ sourceTerm: string; targetTerm: string; note: string | null }> = [];
    if (data.glossaryId) {
      const glossary = await db.glossary.findUnique({ where: { id: data.glossaryId }, include: { terms: true } });
      if (glossary) glossaryTerms = glossary.terms;
    }

    const chunks = splitIntoChunks(data.text, 2500);
    const title = data.title?.trim() || data.text.slice(0, 60).replace(/\s+/g, " ");
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    if (chunks.length === 1) {
      const result = await translateSingleChunk({
        text: chunks[0],
        sourceLang: data.sourceLang,
        targetLang: data.targetLang,
        style: data.style,
        pronounPreset: data.pronounPreset,
        customPronouns: data.customPronouns,
        glossaryTerms,
        options: data.options,
        preferredProvider: data.provider as ProviderName | undefined,
      });

      const job = await db.translationJob.create({
        data: {
          userId: session?.user?.id ?? null,
          title,
          inputType: data.inputType,
          sourceLang: data.sourceLang,
          targetLang: data.targetLang,
          style: data.style,
          pronounPreset: data.pronounPreset ?? null,
          customPronouns: data.customPronouns ?? undefined,
          options: data.options ?? undefined,
          providerUsed: result.provider,
          modelUsed: result.model,
          sourceText: data.text,
          translatedText: result.translatedText,
          status: "COMPLETED",
          progress: 100,
          totalChunks: 1,
          completedChunks: 1,
          charCount,
          tokenUsed: result.tokenUsed,
          glossaryId: data.glossaryId ?? null,
          expiresAt,
        },
      });

      return NextResponse.json({
        mode: "sync",
        jobId: job.id,
        translatedText: result.translatedText,
        provider: result.provider,
        model: result.model,
        tokenUsed: result.tokenUsed,
        fromCache: result.fromCache,
      });
    }

    const job = await db.translationJob.create({
      data: {
        userId: session?.user?.id ?? null,
        title,
        inputType: data.inputType,
        sourceLang: data.sourceLang,
        targetLang: data.targetLang,
        style: data.style,
        pronounPreset: data.pronounPreset ?? null,
        customPronouns: data.customPronouns ?? undefined,
        options: data.options ?? undefined,
        providerUsed: data.provider ?? "openai",
        sourceText: data.text,
        status: "PENDING",
        progress: 0,
        totalChunks: chunks.length,
        completedChunks: 0,
        charCount,
        glossaryId: data.glossaryId ?? null,
        expiresAt,
        chunks: { create: chunks.map((content, index) => ({ index, sourceContent: content, status: "PENDING" })) },
      },
    });

    await inngest.send({ name: "translation/job.created", data: { jobId: job.id } });

    return NextResponse.json({ mode: "async", jobId: job.id, status: job.status, totalChunks: chunks.length }, { status: 202 });
  } catch (error) {
    console.error("[TRANSLATE_API_ERROR]", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Lỗi dịch thuật." }, { status: 500 });
  }
}
