"use client";
import { useEffect, useState } from "react";
import { Save } from "lucide-react";

export default function AdminPage() {
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [config, setConfig] = useState<any>(null);
  const [openaiKey, setOpenaiKey] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  async function loadAll() {
    const [s, u, c] = await Promise.all([
      fetch("/api/admin/stats"), fetch("/api/admin/users"), fetch("/api/admin/config"),
    ]);
    if (s.ok) setStats((await s.json()).stats);
    if (u.ok) setUsers((await u.json()).users ?? []);
    if (c.ok) setConfig((await c.json()).config);
  }

  useEffect(() => { loadAll(); }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      {stats && (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <div className="rounded-xl border bg-white p-4 dark:border-slate-800 dark:bg-slate-900"><p className="text-xs text-slate-500">Users</p><p className="text-2xl font-bold">{stats.totalUsers}</p></div>
          <div className="rounded-xl border bg-white p-4 dark:border-slate-800 dark:bg-slate-900"><p className="text-xs text-slate-500">PRO Users</p><p className="text-2xl font-bold">{stats.proUsers}</p></div>
          <div className="rounded-xl border bg-white p-4 dark:border-slate-800 dark:bg-slate-900"><p className="text-xs text-slate-500">Lượt dịch</p><p className="text-2xl font-bold">{stats.totalJobs}</p></div>
          <div className="rounded-xl border bg-white p-4 dark:border-slate-800 dark:bg-slate-900"><p className="text-xs text-slate-500">AI Tokens</p><p className="text-2xl font-bold">{stats.totalTokens.toLocaleString()}</p></div>
        </div>
      )}

      {config && (
        <form onSubmit={async (e) => { e.preventDefault(); const r = await fetch("/api/admin/config", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ defaultProvider: config.defaultProvider, providerKeys: openaiKey ? { openai: openaiKey } : undefined, freeDailyChars: Number(config.freeDailyChars), proMonthlyChars: Number(config.proMonthlyChars) }) }); setMsg(r.ok ? "Đã lưu cấu hình!" : "Lỗi lưu."); setOpenaiKey(""); loadAll(); }} className="space-y-3 rounded-2xl border bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-bold">Cấu hình AI & Hạn mức</h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <input type="password" value={openaiKey} onChange={(e) => setOpenaiKey(e.target.value)} placeholder="Cập nhật OpenAI API Key..." className="rounded-lg border px-3 py-2 text-xs dark:border-slate-700" />
            <input type="number" value={config.freeDailyChars} onChange={(e) => setConfig({ ...config, freeDailyChars: e.target.value })} className="rounded-lg border px-3 py-2 text-xs dark:border-slate-700" />
            <input type="number" value={config.proMonthlyChars} onChange={(e) => setConfig({ ...config, proMonthlyChars: e.target.value })} className="rounded-lg border px-3 py-2 text-xs dark:border-slate-700" />
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-blue-600">{msg}</span>
            <button type="submit" className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs text-white"><Save className="h-3.5 w-3.5" /> Lưu</button>
          </div>
        </form>
      )}

      <div className="overflow-x-auto rounded-2xl border bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        <h2 className="mb-3 font-bold">Danh sách người dùng</h2>
        <table className="w-full text-left text-xs">
          <thead><tr className="border-b dark:border-slate-800"><th className="py-2">Email</th><th className="py-2">Gói</th><th className="py-2 text-right">Thao tác</th></tr></thead>
          <tbody className="divide-y dark:divide-slate-800">
            {users.map((u) => (
              <tr key={u.id}>
                <td className="py-2">{u.email}</td>
                <td className="py-2">{u.plan}</td>
                <td className="py-2 text-right space-x-2">
                  <button type="button" onClick={async () => { await fetch("/api/admin/users", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId: u.id, plan: u.plan === "PRO" ? "FREE" : "PRO" }) }); loadAll(); }} className="text-blue-600 underline">Đổi gói</button>
                  <button type="button" onClick={async () => { await fetch("/api/admin/users", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId: u.id, isBanned: !u.isBanned }) }); loadAll(); }} className="text-red-600 underline">{u.isBanned ? "Mở khóa" : "Khóa"}</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
