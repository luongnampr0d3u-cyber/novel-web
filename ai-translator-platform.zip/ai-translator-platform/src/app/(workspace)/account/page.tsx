"use client";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import Link from "next/link";
import { Key, Plus, Trash2 } from "lucide-react";

export default function AccountPage() {
  const { status } = useSession();
  const [data, setData] = useState<any>(null);
  const [keyName, setKeyName] = useState("");
  const [newRawKey, setNewRawKey] = useState<string | null>(null);

  async function load() {
    const res = await fetch("/api/account");
    if (res.ok) setData(await res.json());
  }

  useEffect(() => { if (status === "authenticated") load(); }, [status]);

  if (status === "unauthenticated") return <div className="p-16 text-center"><Link href="/login" className="rounded-lg bg-blue-600 px-5 py-2 text-sm text-white">Đăng nhập</Link></div>;
  if (!data) return <div className="p-10 text-center text-sm text-slate-500">Đang tải...</div>;

  return (
    <div className="mx-auto max-w-4xl space-y-6 px-4 py-6">
      <h1 className="text-2xl font-bold">Tài khoản & Developer API</h1>
      <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <p className="font-bold">{data.user.name} ({data.user.email}) — Gói {data.user.plan}</p>
        <p className="mt-1 text-xs text-slate-500">Đã dùng hôm nay: {data.user.dailyCharUsed.toLocaleString()} ký tự</p>
      </div>
      <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <h2 className="mb-3 flex items-center gap-2 font-bold"><Key className="h-4 w-4 text-blue-600" /> Developer API Keys</h2>
        <form onSubmit={async (e) => { e.preventDefault(); const r = await fetch("/api/account/api-keys", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: keyName }) }); if (r.ok) { const j = await r.json(); setNewRawKey(j.rawKey); setKeyName(""); load(); } }} className="mb-4 flex gap-2">
          <input required value={keyName} onChange={(e) => setKeyName(e.target.value)} placeholder="Tên ứng dụng..." className="flex-1 rounded-lg border border-slate-300 bg-transparent px-3 py-2 text-xs dark:border-slate-700" />
          <button type="submit" className="flex items-center gap-1 rounded-lg bg-blue-600 px-4 py-2 text-xs text-white"><Plus className="h-3.5 w-3.5" /> Tạo Key</button>
        </form>
        {newRawKey && <div className="mb-4 rounded-lg bg-amber-50 p-3 font-mono text-xs text-amber-900">API Key mới (chỉ hiện 1 lần): {newRawKey}</div>}
        <div className="space-y-2">
          {data.user.apiKeys.map((k: any) => (
            <div key={k.id} className="flex justify-between rounded-lg border p-2.5 text-xs dark:border-slate-800">
              <span>{k.name} — <code className="text-slate-500">{k.keyPrefix}</code></span>
              <button type="button" onClick={async () => { await fetch("/api/account/api-keys", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ keyId: k.id }) }); load(); }}><Trash2 className="h-3.5 w-3.5 text-red-500" /></button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
