"use client";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import Link from "next/link";
import { Bookmark, Download, Trash2, Archive, Loader2 } from "lucide-react";

interface HistoryJob {
  id: string; title: string; sourceLang: string; targetLang: string;
  status: string; charCount: number; providerUsed: string; isSaved: boolean; createdAt: string;
}

export default function HistoryPage() {
  const { status } = useSession();
  const [jobs, setJobs] = useState<HistoryJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  async function loadHistory() {
    setLoading(true);
    const res = await fetch("/api/history");
    if (res.ok) setJobs((await res.json()).jobs ?? []);
    setLoading(false);
  }

  useEffect(() => {
    if (status === "authenticated") loadHistory();
    else if (status === "unauthenticated") setLoading(false);
  }, [status]);

  async function handleBatchExport() {
    if (!selectedIds.length) return;
    const res = await fetch("/api/export/batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jobIds: selectedIds, format: "docx" }),
    });
    if (!res.ok) return;
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `batch_${Date.now()}.zip`; a.click();
    URL.revokeObjectURL(url);
  }

  if (status === "unauthenticated") {
    return <div className="p-16 text-center"><Link href="/login" className="rounded-lg bg-blue-600 px-5 py-2 text-sm text-white">Đăng nhập để xem lịch sử</Link></div>;
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Lịch sử & Thư viện</h1>
        {selectedIds.length > 0 && (
          <button type="button" onClick={handleBatchExport} className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-medium text-white"><Archive className="h-4 w-4" /> Xuất ZIP ({selectedIds.length})</button>
        )}
      </div>
      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-5 w-5 animate-spin" /></div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500 dark:border-slate-800 dark:bg-slate-950/50">
              <tr><th className="p-3 w-10"></th><th className="p-3">Tiêu đề</th><th className="p-3">Ngôn ngữ</th><th className="p-3">Ký tự</th><th className="p-3 text-right">Thao tác</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {jobs.map((job) => (
                <tr key={job.id}>
                  <td className="p-3"><input type="checkbox" checked={selectedIds.includes(job.id)} onChange={(e) => setSelectedIds((p) => e.target.checked ? [...p, job.id] : p.filter((x) => x !== job.id))} /></td>
                  <td className="p-3 font-medium">{job.title}</td>
                  <td className="p-3 text-xs">{job.sourceLang} → {job.targetLang}</td>
                  <td className="p-3 text-xs">{job.charCount.toLocaleString()}</td>
                  <td className="p-3 text-right">
                    <div className="inline-flex gap-1.5">
                      <button type="button" onClick={async () => { await fetch(`/api/history/${job.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ isSaved: !job.isSaved }) }); loadHistory(); }} className={job.isSaved ? "text-amber-500" : "text-slate-400"}><Bookmark className="h-4 w-4" /></button>
                      <a href={`/api/export/${job.id}?format=docx`} className="text-blue-600"><Download className="h-4 w-4" /></a>
                      <button type="button" onClick={async () => { await fetch(`/api/history/${job.id}`, { method: "DELETE" }); loadHistory(); }} className="text-red-500"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
