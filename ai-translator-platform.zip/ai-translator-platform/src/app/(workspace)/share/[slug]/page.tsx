import { notFound } from "next/navigation";
import Link from "next/link";
import { db } from "@/lib/db";
import { Download, Languages } from "lucide-react";

export default async function PublicSharePage({ params }: { params: { slug: string } }) {
  const job = await db.translationJob.findUnique({ where: { shareSlug: params.slug } });
  if (!job || !job.isPublic || !job.translatedText) notFound();

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div>
          <Link href="/" className="mb-2 inline-flex items-center gap-1.5 text-xs font-medium text-blue-600 hover:underline"><Languages className="h-4 w-4" /> AI Translator Platform</Link>
          <h1 className="text-2xl font-bold">{job.title}</h1>
        </div>
        <div className="flex items-center gap-2">
          <a href={`/api/export/${job.id}?format=docx`} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium dark:border-slate-700"><Download className="h-3.5 w-3.5" /> Tải DOCX</a>
          <a href={`/api/export/${job.id}?format=txt`} className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-2 text-xs font-medium text-white"><Download className="h-3.5 w-3.5" /> Tải TXT</a>
        </div>
      </div>
      <article className="whitespace-pre-wrap rounded-2xl border border-slate-200 bg-white p-6 font-serif text-base leading-relaxed shadow-sm dark:border-slate-800 dark:bg-slate-900">
        {job.translatedText}
      </article>
    </div>
  );
}
