"use client";
import { useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";

interface Glossary {
  id: string; name: string; isPublic: boolean;
  terms: Array<{ id: string; sourceTerm: string; targetTerm: string; note: string | null }>;
}

export default function GlossaryPage() {
  const [glossaries, setGlossaries] = useState<Glossary[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [newName, setNewName] = useState("");
  const [sourceTerm, setSourceTerm] = useState("");
  const [targetTerm, setTargetTerm] = useState("");

  async function load() {
    const res = await fetch("/api/glossary");
    if (res.ok) {
      const data = await res.json();
      setGlossaries(data.glossaries ?? []);
      if (!selectedId && data.glossaries?.length) setSelectedId(data.glossaries[0].id);
    }
  }

  useEffect(() => { load(); }, []);
  const active = glossaries.find((g) => g.id === selectedId);

  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <h1 className="mb-6 text-2xl font-bold">Bảng thuật ngữ (Glossary)</h1>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-12">
        <div className="space-y-3 md:col-span-4">
          <form onSubmit={async (e) => { e.preventDefault(); await fetch("/api/glossary", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: newName }) }); setNewName(""); load(); }} className="flex gap-2">
            <input required value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Tên bộ từ điển mới..." className="flex-1 rounded-lg border border-slate-300 bg-transparent px-3 py-2 text-xs dark:border-slate-700" />
            <button type="submit" className="rounded-lg bg-blue-600 px-3 py-2 text-xs text-white"><Plus className="h-4 w-4" /></button>
          </form>
          {glossaries.map((g) => (
            <div key={g.id} onClick={() => setSelectedId(g.id)} className={`cursor-pointer rounded-xl border p-3 ${g.id === selectedId ? "border-blue-600 bg-blue-50/50 dark:bg-blue-950/30" : "border-slate-200 dark:border-slate-800"}`}>
              <div className="flex justify-between font-medium text-sm">
                <span>{g.name}</span>
                {!g.isPublic && <button type="button" onClick={async (e) => { e.stopPropagation(); await fetch(`/api/glossary/${g.id}`, { method: "DELETE" }); load(); }}><Trash2 className="h-3.5 w-3.5 text-red-500" /></button>}
              </div>
              <p className="text-xs text-slate-500">{g.terms.length} thuật ngữ</p>
            </div>
          ))}
        </div>
        <div className="md:col-span-8">
          {active && (
            <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <h2 className="mb-4 text-lg font-bold">{active.name}</h2>
              {!active.isPublic && (
                <form onSubmit={async (e) => { e.preventDefault(); await fetch(`/api/glossary/${active.id}/terms`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sourceTerm, targetTerm }) }); setSourceTerm(""); setTargetTerm(""); load(); }} className="mb-4 flex gap-2">
                  <input required value={sourceTerm} onChange={(e) => setSourceTerm(e.target.value)} placeholder="Từ gốc (VD: 萧炎)" className="flex-1 rounded-lg border border-slate-300 bg-transparent px-3 py-2 text-xs dark:border-slate-700" />
                  <input required value={targetTerm} onChange={(e) => setTargetTerm(e.target.value)} placeholder="Từ đích (VD: Tiêu Viêm)" className="flex-1 rounded-lg border border-slate-300 bg-transparent px-3 py-2 text-xs dark:border-slate-700" />
                  <button type="submit" className="rounded-lg bg-blue-600 px-3 py-2 text-xs text-white">Thêm</button>
                </form>
              )}
              <table className="w-full text-left text-xs">
                <thead><tr className="border-b dark:border-slate-800"><th className="py-2">Từ gốc</th><th className="py-2">Từ đích</th></tr></thead>
                <tbody className="divide-y dark:divide-slate-800">
                  {active.terms.map((t) => <tr key={t.id}><td className="py-2">{t.sourceTerm}</td><td className="py-2 text-blue-600">{t.targetTerm}</td></tr>)}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
