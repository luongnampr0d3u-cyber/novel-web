"use client";
import { useState, useEffect, useRef } from "react";
import { InputPanel, InputTab } from "@/components/workspace/InputPanel";
import { OptionsPanel, WorkspaceOptionsState } from "@/components/workspace/OptionsPanel";
import { OutputPanel } from "@/components/workspace/OutputPanel";

export default function WorkspacePage() {
  const [inputType, setInputType] = useState<InputTab>("TEXT");
  const [title, setTitle] = useState("");
  const [sourceText, setSourceText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [jobId, setJobId] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [isTranslating, setIsTranslating] = useState(false);
  const [providerInfo, setProviderInfo] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [glossaries, setGlossaries] = useState<Array<{ id: string; name: string; isPublic: boolean }>>([]);
  const pollTimerRef = useRef<NodeJS.Timeout | null>(null);

  const [options, setOptions] = useState<WorkspaceOptionsState>({
    sourceLang: "auto", targetLang: "vi", style: "NOVEL", pronounPreset: "auto",
    customPronouns: {}, glossaryId: "", provider: "openai", model: "gpt-4o",
    temperature: 0.3, keepProperNouns: false, keepNumbers: true,
    ignoreBraces: true, preserveFormat: true, grammarCheck: false,
  });

  useEffect(() => {
    fetch("/api/glossary").then((r) => (r.ok ? r.json() : { glossaries: [] })).then((d) => setGlossaries(d.glossaries ?? [])).catch(() => {});
    return () => { if (pollTimerRef.current) clearInterval(pollTimerRef.current); };
  }, []);

  function startPollingJob(id: string) {
    if (pollTimerRef.current) clearInterval(pollTimerRef.current);
    pollTimerRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/jobs/${id}`);
        if (!res.ok) return;
        const { job } = await res.json();
        setProgress(job.progress ?? 0);
        if (Array.isArray(job.chunks)) {
          const partial = job.chunks.map((c: { targetContent?: string | null }) => c.targetContent).filter(Boolean).join("\n\n");
          if (partial) setTranslatedText(partial);
        }
        if (job.status === "COMPLETED") {
          setTranslatedText(job.translatedText ?? "");
          setProviderInfo(`${job.providerUsed} • ${job.tokenUsed} tokens`);
          setIsTranslating(false);
          if (pollTimerRef.current) clearInterval(pollTimerRef.current);
        } else if (job.status === "FAILED") {
          setError(job.errorMessage || "Dịch thất bại.");
          setIsTranslating(false);
          if (pollTimerRef.current) clearInterval(pollTimerRef.current);
        }
      } catch {}
    }, 2500);
  }

  async function handleTranslate() {
    if (!sourceText.trim()) return;
    setError(null); setIsTranslating(true); setProgress(5); setTranslatedText(""); setJobId(null);
    try {
      const res = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title || undefined, text: sourceText, inputType,
          sourceLang: options.sourceLang, targetLang: options.targetLang, style: options.style,
          pronounPreset: options.pronounPreset,
          customPronouns: options.pronounPreset === "custom" ? options.customPronouns : null,
          glossaryId: options.glossaryId || null, provider: options.provider,
          options: {
            keepProperNouns: options.keepProperNouns, keepNumbers: options.keepNumbers,
            ignoreBraces: options.ignoreBraces, preserveFormat: options.preserveFormat,
            grammarCheck: options.grammarCheck, temperature: options.temperature, model: options.model,
          },
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Không thể dịch.");
      setJobId(data.jobId);
      if (data.mode === "sync") {
        setTranslatedText(data.translatedText); setProgress(100);
        setProviderInfo(`${data.provider} (${data.model})`); setIsTranslating(false);
      } else {
        setProviderInfo(`Đang xử lý nền (${data.totalChunks} đoạn)...`);
        startPollingJob(data.jobId);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Lỗi máy chủ.");
      setIsTranslating(false);
    }
  }

  return (
    <div className="mx-auto max-w-[1600px] p-4">
      {error && <div className="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:bg-red-950/40 dark:text-red-300">{error}</div>}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        <div className="lg:col-span-5"><InputPanel inputType={inputType} setInputType={setInputType} title={title} setTitle={setTitle} sourceText={sourceText} setSourceText={setSourceText} sourceLang={options.sourceLang} /></div>
        <div className="lg:col-span-2"><OptionsPanel options={options} setOptions={setOptions} glossaries={glossaries} isTranslating={isTranslating} disabled={!sourceText.trim()} onTranslate={handleTranslate} /></div>
        <div className="lg:col-span-5"><OutputPanel jobId={jobId} sourceText={sourceText} translatedText={translatedText} progress={progress} isTranslating={isTranslating} providerInfo={providerInfo} /></div>
      </div>
    </div>
  );
}
