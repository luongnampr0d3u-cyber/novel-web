# AI Translator Platform — Website Máy Dịch Thuật Đa Nguồn

Nền tảng dịch thuật AI chuyên nghiệp cho truyện, tiểu thuyết và tài liệu (Trung / Anh ⇄ Việt), tối ưu deploy trực tiếp trên **Vercel + Neon/Supabase + Upstash Redis + Inngest**.

## Hướng dẫn cài đặt & Deploy nhanh lên Vercel

1. Giải nén file zip và đẩy mã nguồn lên GitHub Repository.
2. Tạo Database PostgreSQL miễn phí trên [Neon.tech](https://neon.tech) hoặc [Supabase](https://supabase.com) và lấy `DATABASE_URL`.
3. (Tùy chọn) Tạo Redis miễn phí trên [Upstash](https://console.upstash.com) để bật Cache & Rate Limit.
4. Import Repository vào [Vercel](https://vercel.com), cấu hình các biến môi trường theo file `.env.example`.
5. Kết nối **Inngest** từ Vercel Marketplace để xử lý dịch truyện/file dài chạy nền.
6. Chạy đồng bộ database và tạo tài khoản Admin mặc định:
   ```bash
   npx prisma db push
   npx tsx prisma/seed.ts
   ```
7. Đăng nhập Admin mặc định: `admin@translator.local` / `Admin@123456` (hãy đổi mật khẩu ngay tại `/account`).

> **Font PDF tiếng Việt:** Đặt file `NotoSans-Regular.ttf` vào thư mục `public/fonts/NotoSans-Regular.ttf` để xuất PDF hiển thị đầy đủ dấu tiếng Việt và chữ Hán.
