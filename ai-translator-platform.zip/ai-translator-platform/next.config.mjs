/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverComponentsExternalPackages: [
      "pdf-parse",
      "epub2",
      "tesseract.js",
      "epub-gen-memory",
    ],
  },
};

export default nextConfig;
