import { PrismaClient, Role, PlanType } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminEmail = "admin@translator.local";
  const passwordHash = await bcrypt.hash("Admin@123456", 12);

  await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      name: "System Admin",
      passwordHash,
      role: Role.ADMIN,
      plan: PlanType.PRO,
    },
  });

  await prisma.systemConfig.upsert({
    where: { id: "default" },
    update: {},
    create: {
      id: "default",
      defaultProvider: "openai",
      fallbackOrder: ["openai", "claude", "deepl", "google"],
      providerKeys: {},
      maxFileSizeMb: 20,
      freeDailyChars: 5000,
      proMonthlyChars: 500000,
      allowRegister: true,
      maintenanceMode: false,
    },
  });

  const existingGlossary = await prisma.glossary.findFirst({
    where: { name: "Tiên Hiệp / Huyền Huyễn Cơ Bản", isPublic: true },
  });

  if (!existingGlossary) {
    await prisma.glossary.create({
      data: {
        name: "Tiên Hiệp / Huyền Huyễn Cơ Bản",
        description: "Bộ thuật ngữ mẫu dùng chung cho truyện tu tiên tiếng Trung",
        sourceLang: "zh",
        targetLang: "vi",
        isPublic: true,
        terms: {
          create: [
            { sourceTerm: "斗气", targetTerm: "đấu khí", note: "Năng lượng tu luyện" },
            { sourceTerm: "灵气", targetTerm: "linh khí", note: "Khí thiên địa" },
            { sourceTerm: "丹田", targetTerm: "đan điền", note: "Nơi tụ khí" },
            { sourceTerm: "师兄", targetTerm: "sư huynh", note: "Xưng hô đồng môn" },
            { sourceTerm: "师妹", targetTerm: "sư muội", note: "Xưng hô đồng môn" },
            { sourceTerm: "宗门", targetTerm: "tông môn", note: "Môn phái" },
          ],
        },
      },
    });
  }

  console.log("Seed completed successfully.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
