# Novel Web (Next.js + MongoDB + TailwindCSS + JWT + Cloudinary)

Website đọc truyện chữ hoàn chỉnh với hệ thống phân quyền 3 cấp (`admin`, `moderator`, `user`).

## Cài đặt nhanh
1. Cài đặt dependencies:
   ```bash
   npm install
   ```
2. Tạo file `.env` từ `.env.example` và điền `MONGODB_URI`, `JWT_SECRET`, `CLOUDINARY_*`.
3. Tạo dữ liệu mẫu (admin@novel.vn / mod@novel.vn / user@novel.vn - mật khẩu: `123456`):
   ```bash
   npm run seed
   ```
4. Chạy môi trường dev:
   ```bash
   npm run dev
   ```

## Deploy lên Netlify
1. Đẩy thư mục này lên GitHub.
2. Vào `app.netlify.com` -> **Add new site** -> **Import an existing project** -> chọn repo GitHub.
3. Trong **Site configuration -> Environment variables**, thêm các biến từ `.env.example`.
4. Bấm **Deploy site**.
