'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard,
  BookOpen,
  FileText,
  Tags,
  Users,
  MessageSquare,
  Settings,
  ArrowLeft,
} from 'lucide-react';
import { UserRole } from '@/lib/jwt';

interface AdminSidebarProps {
  role: UserRole;
}

const MENU_ITEMS = [
  { href: '/admin', label: 'Dashboard', icon: LayoutDashboard, roles: ['admin', 'moderator'] },
  { href: '/admin/truyen', label: 'Quản lý Truyện', icon: BookOpen, roles: ['admin', 'moderator'] },
  { href: '/admin/chuong', label: 'Quản lý Chương', icon: FileText, roles: ['admin', 'moderator'] },
  { href: '/admin/the-loai', label: 'Thể loại', icon: Tags, roles: ['admin', 'moderator'] },
  { href: '/admin/binh-luan', label: 'Kiểm duyệt Bình luận', icon: MessageSquare, roles: ['admin', 'moderator'] },
  { href: '/admin/nguoi-dung', label: 'Người dùng', icon: Users, roles: ['admin'] },
  { href: '/admin/cai-dat', label: 'Cài đặt Giao diện', icon: Settings, roles: ['admin'] },
];

export default function AdminSidebar({ role }: AdminSidebarProps) {
  const pathname = usePathname();

  return (
    <aside className="w-full shrink-0 border-b border-gray-200 bg-white lg:w-64 lg:border-b-0 lg:border-r">
      <div className="p-4">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <p className="text-sm font-bold text-gray-900">Bảng Quản Trị</p>
            <span className="mt-0.5 inline-block rounded bg-amber-100 px-2 py-0.5 text-[11px] font-semibold uppercase text-amber-800">
              {role}
            </span>
          </div>
          <Link
            href="/"
            className="inline-flex items-center gap-1 text-xs text-gray-500 hover:text-primary"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Về web
          </Link>
        </div>

        <nav className="flex flex-wrap gap-1 lg:flex-col">
          {MENU_ITEMS.filter((item) => item.roles.includes(role)).map((item) => {
            const Icon = item.icon;
            const active =
              item.href === '/admin' ? pathname === '/admin' : pathname.startsWith(item.href);

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition ${
                  active
                    ? 'bg-primary text-white'
                    : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </aside>
  );
}
