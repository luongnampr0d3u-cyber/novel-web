interface FooterProps {
  footerText: string;
  siteName: string;
}

export default function Footer({ footerText, siteName }: FooterProps) {
  return (
    <footer className="mt-16 border-t border-gray-200 bg-white py-8 text-center text-sm text-gray-600">
      <div className="mx-auto max-w-7xl px-4">
        <p className="font-semibold text-gray-800">{siteName}</p>
        <p className="mt-1">{footerText}</p>
      </div>
    </footer>
  );
}
