'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { BookOpen, Search, User, LogOut, Shield, Bookmark, Menu, X } from 'lucide-react';

interface NavbarProps {
  siteName: string;
  logoUrl?: string;
}

interface CurrentUser {
  _id: string;
  username: string;
  email: string;
  role: 'admin' | 'moderator' | 'user';
}

export default function Navbar({ siteName, logoUrl }: NavbarProps) {
  const router = useRouter();
  const [user, setUser] = useState<CurrentUser | null>(null);
  const [keyword, setKeyword] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => setUser(data.user || null))
      .catch(() => setUser(null));
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyword.trim()) return;
    router.push(`/tim-kiem?q=${encodeURIComponent(keyword.trim())}`);
    setMobileOpen(false);
  };

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    setUser(null);
    router.push('/');
    router.refresh();
  };

  const isStaff = user?.role === 'admin' || user?.role === 'moderator';

  return (
    <header className="sticky top-0 z-40 border-b border-gray-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3">
        <Link href="/" className="flex items-center gap-2 font-bold text-lg text-gray-900">
          {logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logoUrl} alt={siteName} className="h-8 w-8 rounded object-cover" />
          ) : (
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-white">
              <BookOpen className="h-5 w-5" />
            </span>
          )}
          <span className="truncate">{siteName}</span>
        </Link>

        <form onSubmit={handleSearch} className="hidden flex-1 max-w-md md:flex">
          <div className="relative w-full">
            <input
              type="text"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="Tìm tên truyện, tác giả..."
              className="w-full rounded-full border border-gray-300 bg-gray-50 py-1.5 pl-4 pr-10 text-sm focus:border-primary focus:bg-white focus:outline-none"
            />
            <button
              type="submit"
              aria-label="Tìm kiếm"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-primary"
            >
              <Search className="h-4 w-4" />
            </button>
          </div>
        </form>

        <nav className="hidden items-center gap-4 text-sm font-medium md:flex">
          <Link href="/tim-kiem" className="text-gray-700 hover:text-primary">
            Thể loại & Lọc
          </Link>
          <Link href="/tu-truyen" className="flex items-center gap-1 text-gray-700 hover:text-primary">
            <Bookmark className="h-4 w-4" />
            Tủ truyện
          </Link>

          {user ? (
            <div className="flex items-center gap-3 border-l border-gray-200 pl-3">
              {isStaff && (
                <Link
                  href="/admin"
                  className="flex items-center gap-1 rounded-md bg-amber-100 px-2.5 py-1 text-xs font-semibold text-amber-800 hover:bg-amber-200"
                >
                  <Shield className="h-3.5 w-3.5" />
                  Quản trị
                </Link>
              )}
              <span className="flex items-center gap-1 text-gray-800">
                <User className="h-4 w-4 text-primary" />
                {user.username}
              </span>
              <button
                onClick={handleLogout}
                title="Đăng xuất"
                className="rounded p-1.5 text-gray-500 hover:bg-gray-100 hover:text-red-600"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                href="/dang-nhap"
                className="rounded-lg border border-gray-300 px-3 py-1.5 text-gray-700 hover:bg-gray-50"
              >
                Đăng nhập
              </Link>
              <Link
                href="/dang-ky"
                className="rounded-lg bg-primary px-3 py-1.5 text-white hover:opacity-90"
              >
                Đăng ký
              </Link>
            </div>
          )}
        </nav>

        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="rounded-lg p-2 text-gray-600 hover:bg-gray-100 md:hidden"
          aria-label="Mở menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="border-t border-gray-200 bg-white px-4 py-4 md:hidden">
          <form onSubmit={handleSearch} className="mb-4 flex gap-2">
            <input
              type="text"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="Tìm tên truyện, tác giả..."
              className="flex-1 rounded-lg border border-gray-300 px-3 py-2 text-sm"
            />
            <button type="submit" className="rounded-lg bg-primary px-3 py-2 text-white">
              <Search className="h-4 w-4" />
            </button>
          </form>
          <div className="flex flex-col gap-3 text-sm font-medium">
            <Link href="/tim-kiem" onClick={() => setMobileOpen(false)}>
              Thể loại & Lọc
            </Link>
            <Link href="/tu-truyen" onClick={() => setMobileOpen(false)}>
              Tủ truyện
            </Link>
            {isStaff && (
              <Link href="/admin" onClick={() => setMobileOpen(false)} className="text-amber-700">
                Trang Quản trị
              </Link>
            )}
            {user ? (
              <button onClick={handleLogout} className="text-left text-red-600">
                Đăng xuất ({user.username})
              </button>
            ) : (
              <div className="flex gap-2 pt-2">
                <Link
                  href="/dang-nhap"
                  onClick={() => setMobileOpen(false)}
                  className="flex-1 rounded-lg border border-gray-300 py-2 text-center"
                >
                  Đăng nhập
                </Link>
                <Link
                  href="/dang-ky"
                  onClick={() => setMobileOpen(false)}
                  className="flex-1 rounded-lg bg-primary py-2 text-center text-white"
                >
                  Đăng ký
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
