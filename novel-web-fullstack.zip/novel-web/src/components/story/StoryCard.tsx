import Link from 'next/link';
import { Eye, Star, BookText } from 'lucide-react';
import { formatNumber } from '@/lib/utils';

export interface StoryCardItem {
  _id: string;
  title: string;
  slug: string;
  author: string;
  coverImage: string;
  status: 'ongoing' | 'completed' | 'paused';
  views: number;
  ratingAvg: number;
  totalChapters: number;
  categories?: { _id: string; name: string; slug: string }[];
}

const STATUS_LABEL: Record<string, { text: string; color: string }> = {
  ongoing: { text: 'Đang ra', color: 'bg-blue-600' },
  completed: { text: 'Hoàn thành', color: 'bg-emerald-600' },
  paused: { text: 'Tạm ngưng', color: 'bg-amber-600' },
};

export default function StoryCard({ story }: { story: StoryCardItem }) {
  const badge = STATUS_LABEL[story.status] || STATUS_LABEL.ongoing;

  return (
    <Link
      href={`/truyen/${story.slug}`}
      className="group flex flex-col overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <div className="relative aspect-[2/3] w-full overflow-hidden bg-gray-100">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={story.coverImage}
          alt={story.title}
          className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
        />
        <span
          className={`absolute left-2 top-2 rounded px-2 py-0.5 text-[11px] font-semibold text-white ${badge.color}`}
        >
          {badge.text}
        </span>
        <span className="absolute bottom-2 right-2 flex items-center gap-1 rounded bg-black/70 px-1.5 py-0.5 text-xs font-medium text-amber-400">
          <Star className="h-3 w-3 fill-amber-400" />
          {story.ratingAvg.toFixed(1)}
        </span>
      </div>

      <div className="flex flex-1 flex-col p-3">
        <h3 className="line-clamp-2 text-sm font-bold text-gray-900 group-hover:text-primary">
          {story.title}
        </h3>
        <p className="mt-1 truncate text-xs text-gray-500">{story.author}</p>

        <div className="mt-auto flex items-center justify-between pt-3 text-xs text-gray-500">
          <span className="flex items-center gap-1">
            <BookText className="h-3.5 w-3.5" />
            {story.totalChapters} ch.
          </span>
          <span className="flex items-center gap-1">
            <Eye className="h-3.5 w-3.5" />
            {formatNumber(story.views)}
          </span>
        </div>
      </div>
    </Link>
  );
}
