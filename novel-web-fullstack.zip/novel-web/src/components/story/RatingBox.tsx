'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Star } from 'lucide-react';

interface RatingBoxProps {
  storyId: string;
  initialAvg: number;
  initialCount: number;
  initialUserScore?: number;
}

export default function RatingBox({
  storyId,
  initialAvg,
  initialCount,
  initialUserScore = 0,
}: RatingBoxProps) {
  const router = useRouter();
  const [avg, setAvg] = useState(initialAvg);
  const [count, setCount] = useState(initialCount);
  const [userScore, setUserScore] = useState(initialUserScore);
  const [hoverScore, setHoverScore] = useState(0);
  const [message, setMessage] = useState('');

  const handleRate = async (score: number) => {
    const res = await fetch('/api/ratings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ storyId, score }),
    });

    if (res.status === 401) {
      router.push('/dang-nhap');
      return;
    }

    const data = await res.json();
    if (res.ok) {
      setAvg(data.ratingAvg);
      setCount(data.ratingCount);
      setUserScore(data.userScore);
      setMessage(`Bạn đã đánh giá ${score} sao!`);
    }
  };

  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-sm font-semibold text-gray-800">Đánh giá truyện</p>
          <p className="text-xs text-gray-500">
            Trung bình <strong className="text-amber-600">{avg.toFixed(1)}/5</strong> ({count} lượt đánh giá)
          </p>
        </div>

        <div className="flex items-center gap-1">
          {[1, 2, 3, 4, 5].map((star) => {
            const active = star <= (hoverScore || userScore);
            return (
              <button
                key={star}
                type="button"
                onMouseEnter={() => setHoverScore(star)}
                onMouseLeave={() => setHoverScore(0)}
                onClick={() => handleRate(star)}
                className="p-1 transition hover:scale-110"
                aria-label={`Đánh giá ${star} sao`}
              >
                <Star
                  className={`h-6 w-6 ${
                    active ? 'fill-amber-400 text-amber-400' : 'text-gray-300'
                  }`}
                />
              </button>
            );
          })}
        </div>
      </div>
      {message && <p className="mt-2 text-xs font-medium text-emerald-600">{message}</p>}
    </div>
  );
}
