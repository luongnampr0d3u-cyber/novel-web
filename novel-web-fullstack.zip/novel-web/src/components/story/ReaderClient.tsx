'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Settings, Sun, Moon, BookOpen } from 'lucide-react';

interface ChapterNav {
  _id: string;
  chapterNumber: number;
  title: string;
  slug: string;
}

interface ReaderClientProps {
  story: { _id: string; title: string; slug: string };
  chapter: {
    _id: string;
    chapterNumber: number;
    title: string;
    slug: string;
    content: string;
  };
  prevChapter: ChapterNav | null;
  nextChapter: ChapterNav | null;
  allChapters: ChapterNav[];
  initialScrollPosition?: number;
}

type ReaderTheme = 'light' | 'sepia' | 'dark';
type ReaderFont = 'sans' | 'serif' | 'mono';

const THEME_STYLES: Record<ReaderTheme, string> = {
  light: 'bg-white text-gray-900',
  sepia: 'bg-[#f4ecd8] text-[#433422]',
  dark: 'bg-[#121212] text-gray-200',
};

const FONT_CLASSES: Record<ReaderFont, string> = {
  sans: 'font-sans',
  serif: 'font-serif',
  mono: 'font-mono',
};

export default function ReaderClient({
  story,
  chapter,
  prevChapter,
  nextChapter,
  allChapters,
  initialScrollPosition = 0,
}: ReaderClientProps) {
  const router = useRouter();
  const [theme, setTheme] = useState<ReaderTheme>('light');
  const [fontSize, setFontSize] = useState<number>(19);
  const [fontFamily, setFontFamily] = useState<ReaderFont>('serif');
  const [lineHeight, setLineHeight] = useState<number>(1.8);
  const [showSettings, setShowSettings] = useState(false);
  const saveTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('novel_reader_prefs');
    if (saved) {
      try {
        const prefs = JSON.parse(saved);
        if (prefs.theme) setTheme(prefs.theme);
        if (prefs.fontSize) setFontSize(prefs.fontSize);
        if (prefs.fontFamily) setFontFamily(prefs.fontFamily);
        if (prefs.lineHeight) setLineHeight(prefs.lineHeight);
      } catch {
        // ignore
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(
      'novel_reader_prefs',
      JSON.stringify({ theme, fontSize, fontFamily, lineHeight })
    );
  }, [theme, fontSize, fontFamily, lineHeight]);

  useEffect(() => {
    const localKey = `scroll_${story._id}_${chapter._id}`;
    const localScroll = Number(localStorage.getItem(localKey) || '0');
    const targetY = initialScrollPosition || localScroll;
    if (targetY > 100) {
      setTimeout(() => {
        window.scrollTo({ top: targetY, behavior: 'smooth' });
      }, 250);
    }
  }, [story._id, chapter._id, initialScrollPosition]);

  useEffect(() => {
    const saveProgress = () => {
      const y = Math.round(window.scrollY);
      localStorage.setItem(`scroll_${story._id}_${chapter._id}`, String(y));

      fetch('/api/bookshelf', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storyId: story._id,
          chapterId: chapter._id,
          chapterNumber: chapter.chapterNumber,
          chapterSlug: chapter.slug,
          scrollPosition: y,
        }),
      }).catch(() => {});
    };

    saveProgress();

    const handleScroll = () => {
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
      saveTimerRef.current = setTimeout(saveProgress, 1200);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    };
  }, [story._id, chapter._id, chapter.chapterNumber, chapter.slug]);

  const paragraphs = chapter.content
    .split(/\n+/)
    .map((p) => p.trim())
    .filter(Boolean);

  return (
    <div className={`min-h-screen transition-colors duration-200 ${THEME_STYLES[theme]}`}>
      <div className="sticky top-[57px] z-30 border-b border-black/10 bg-inherit/95 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-2 px-4 py-2.5">
          <Link
            href={`/truyen/${story.slug}`}
            className="flex items-center gap-1.5 truncate text-sm font-semibold hover:text-primary"
          >
            <BookOpen className="h-4 w-4 shrink-0" />
            <span className="truncate">{story.title}</span>
          </Link>

          <div className="flex items-center gap-2">
            <select
              value={chapter.slug}
              onChange={(e) => router.push(`/truyen/${story.slug}/${e.target.value}`)}
              className="max-w-[160px] rounded-md border border-black/20 bg-transparent px-2 py-1 text-xs focus:outline-none"
            >
              {allChapters.map((c) => (
                <option key={c._id} value={c.slug} className="text-gray-900">
                  Chương {c.chapterNumber}: {c.title}
                </option>
              ))}
            </select>

            <button
              onClick={() => setShowSettings(!showSettings)}
              className="inline-flex items-center gap-1 rounded-md border border-black/20 px-2.5 py-1 text-xs font-medium hover:bg-black/5"
            >
              <Settings className="h-3.5 w-3.5" />
              Giao diện
            </button>
          </div>
        </div>

        {showSettings && (
          <div className="border-t border-black/10 bg-black/5 px-4 py-4">
            <div className="mx-auto grid max-w-4xl gap-4 sm:grid-cols-3">
              <div>
                <p className="mb-1.5 text-xs font-semibold uppercase opacity-75">Màu nền</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setTheme('light')}
                    className={`flex items-center gap-1 rounded border px-2.5 py-1 text-xs ${
                      theme === 'light' ? 'border-primary bg-primary text-white' : 'bg-white text-gray-900'
                    }`}
                  >
                    <Sun className="h-3.5 w-3.5" /> Sáng
                  </button>
                  <button
                    onClick={() => setTheme('sepia')}
                    className={`rounded border px-2.5 py-1 text-xs ${
                      theme === 'sepia'
                        ? 'border-primary bg-primary text-white'
                        : 'bg-[#f4ecd8] text-[#433422]'
                    }`}
                  >
                    Giấy cũ
                  </button>
                  <button
                    onClick={() => setTheme('dark')}
                    className={`flex items-center gap-1 rounded border px-2.5 py-1 text-xs ${
                      theme === 'dark' ? 'border-primary bg-primary text-white' : 'bg-gray-900 text-white'
                    }`}
                  >
                    <Moon className="h-3.5 w-3.5" /> Tối
                  </button>
                </div>
              </div>

              <div>
                <p className="mb-1.5 text-xs font-semibold uppercase opacity-75">Phông chữ</p>
                <div className="flex gap-2">
                  {(['serif', 'sans', 'mono'] as ReaderFont[]).map((f) => (
                    <button
                      key={f}
                      onClick={() => setFontFamily(f)}
                      className={`rounded border px-2.5 py-1 text-xs capitalize ${
                        fontFamily === f ? 'border-primary bg-primary text-white' : 'border-black/20'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="mb-1.5 text-xs font-semibold uppercase opacity-75">
                  Cỡ chữ: {fontSize}px
                </p>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setFontSize((s) => Math.max(14, s - 1))}
                    className="rounded border border-black/20 px-2.5 py-1 text-xs"
                  >
                    A-
                  </button>
                  <button
                    onClick={() => setFontSize((s) => Math.min(30, s + 1))}
                    className="rounded border border-black/20 px-2.5 py-1 text-xs"
                  >
                    A+
                  </button>
                  <button
                    onClick={() => setLineHeight((l) => (l >= 2.2 ? 1.5 : Number((l + 0.15).toFixed(2))))}
                    className="rounded border border-black/20 px-2.5 py-1 text-xs"
                  >
                    Giãn dòng: {lineHeight}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <article className="mx-auto max-w-3xl px-4 py-10">
        <header className="mb-8 text-center">
          <p className="text-sm font-medium opacity-70">Chương {chapter.chapterNumber}</p>
          <h1 className="mt-1 text-2xl font-bold sm:text-3xl">{chapter.title}</h1>
        </header>

        <div
          className={`space-y-5 ${FONT_CLASSES[fontFamily]}`}
          style={{ fontSize: `${fontSize}px`, lineHeight }}
        >
          {paragraphs.map((para, idx) => (
            <p key={idx} className="text-justify">
              {para}
            </p>
          ))}
        </div>

        <div className="mt-12 flex items-center justify-between gap-4 border-t border-black/10 pt-6">
          {prevChapter ? (
            <Link
              href={`/truyen/${story.slug}/${prevChapter.slug}`}
              className="inline-flex items-center gap-1 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-white hover:opacity-90"
            >
              <ChevronLeft className="h-4 w-4" />
              Chương trước
            </Link>
          ) : (
            <span className="rounded-lg border border-black/10 px-4 py-2.5 text-sm opacity-40">
              Chương đầu
            </span>
          )}

          {nextChapter ? (
            <Link
              href={`/truyen/${story.slug}/${nextChapter.slug}`}
              className="inline-flex items-center gap-1 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-white hover:opacity-90"
            >
              Chương sau
              <ChevronRight className="h-4 w-4" />
            </Link>
          ) : (
            <span className="rounded-lg border border-black/10 px-4 py-2.5 text-sm opacity-40">
              Chương mới nhất
            </span>
          )}
        </div>
      </article>
    </div>
  );
}
