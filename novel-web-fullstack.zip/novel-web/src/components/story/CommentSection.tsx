'use client';

import { useEffect, useState } from 'react';
import { MessageSquare, Trash2, Send } from 'lucide-react';
import { timeAgo } from '@/lib/utils';

interface CommentItem {
  _id: string;
  content: string;
  createdAt: string;
  userId: {
    _id: string;
    username: string;
    role: string;
  };
}

interface CommentSectionProps {
  storyId: string;
  chapterId?: string;
}

export default function CommentSection({ storyId, chapterId }: CommentSectionProps) {
  const [comments, setComments] = useState<CommentItem[]>([]);
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [currentUser, setCurrentUser] = useState<{ _id: string; role: string } | null>(null);

  const loadComments = async () => {
    const query = new URLSearchParams({ storyId });
    if (chapterId) query.set('chapterId', chapterId);
    const res = await fetch(`/api/comments?${query.toString()}`);
    const data = await res.json();
    if (res.ok) setComments(data.comments || []);
  };

  useEffect(() => {
    loadComments();
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => setCurrentUser(data.user || null))
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storyId, chapterId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ storyId, chapterId, content }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Không thể gửi bình luận.');
        return;
      }
      setComments((prev) => [data.comment, ...prev]);
      setContent('');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (commentId: string) => {
    if (!confirm('Bạn chắc chắn muốn xóa bình luận này?')) return;
    const res = await fetch(`/api/comments/${commentId}`, { method: 'DELETE' });
    if (res.ok) {
      setComments((prev) => prev.filter((c) => c._id !== commentId));
    }
  };

  return (
    <section className="mt-8 rounded-xl border border-gray-200 bg-white p-5">
      <h2 className="flex items-center gap-2 text-lg font-bold text-gray-900">
        <MessageSquare className="h-5 w-5 text-primary" />
        Bình luận ({comments.length})
      </h2>

      <form onSubmit={handleSubmit} className="mt-4">
        <textarea
          rows={3}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder={
            currentUser
              ? 'Viết cảm nhận của bạn về truyện...'
              : 'Vui lòng đăng nhập để tham gia bình luận...'
          }
          className="w-full rounded-lg border border-gray-300 p-3 text-sm focus:border-primary focus:outline-none"
        />
        {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
        <div className="mt-2 flex justify-end">
          <button
            type="submit"
            disabled={loading || !content.trim()}
            className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
          >
            <Send className="h-4 w-4" />
            Gửi bình luận
          </button>
        </div>
      </form>

      <div className="mt-6 space-y-4">
        {comments.length === 0 ? (
          <p className="text-center text-sm text-gray-500">Chưa có bình luận nào.</p>
        ) : (
          comments.map((comment) => {
            const canDelete =
              currentUser &&
              (currentUser._id === comment.userId?._id ||
                currentUser.role === 'admin' ||
                currentUser.role === 'moderator');

            return (
              <div key={comment._id} className="rounded-lg border border-gray-100 bg-gray-50 p-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-gray-900">
                      {comment.userId?.username || 'Ẩn danh'}
                    </span>
                    {comment.userId?.role === 'admin' && (
                      <span className="rounded bg-red-100 px-1.5 py-0.5 text-[10px] font-bold text-red-700">
                        ADMIN
                      </span>
                    )}
                    {comment.userId?.role === 'moderator' && (
                      <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-700">
                        MOD
                      </span>
                    )}
                    <span className="text-xs text-gray-400">{timeAgo(comment.createdAt)}</span>
                  </div>

                  {canDelete && (
                    <button
                      onClick={() => handleDelete(comment._id)}
                      className="text-gray-400 hover:text-red-600"
                      title="Xóa bình luận"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
                <p className="mt-2 whitespace-pre-line text-sm text-gray-700">{comment.content}</p>
              </div>
            );
          })
        )}
      </div>
    </section>
  );
}
