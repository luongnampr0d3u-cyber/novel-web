'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Bookmark } from 'lucide-react';

interface BookmarkButtonProps {
  storyId: string;
  initialBookmarked: boolean;
}

export default function BookmarkButton({ storyId, initialBookmarked }: BookmarkButtonProps) {
  const router = useRouter();
  const [bookmarked, setBookmarked] = useState(initialBookmarked);
  const [loading, setLoading] = useState(false);

  const handleToggle = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/bookshelf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ storyId }),
      });

      if (res.status === 401) {
        router.push('/dang-nhap');
        return;
      }

      const data = await res.json();
      if (res.ok) {
        setBookmarked(data.bookmarked);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      onClick={handleToggle}
      disabled={loading}
      className={`inline-flex items-center gap-2 rounded-lg border px-4 py-2.5 text-sm font-semibold transition ${
        bookmarked
          ? 'border-primary bg-primary/10 text-primary'
          : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
      }`}
    >
      <Bookmark className={`h-4 w-4 ${bookmarked ? 'fill-primary' : ''}`} />
      {bookmarked ? 'Đã lưu tủ truyện' : 'Lưu vào tủ truyện'}
    </button>
  );
}
