import mongoose, { Schema, Document, Model, Types } from 'mongoose';

export type StoryStatus = 'ongoing' | 'completed' | 'paused';

export interface IStory extends Document {
  title: string;
  slug: string;
  author: string;
  coverImage: string;
  description: string;
  categories: Types.ObjectId[];
  status: StoryStatus;
  views: number;
  ratingAvg: number;
  ratingCount: number;
  totalChapters: number;
  latestChapterAt: Date;
  createdBy?: Types.ObjectId;
  createdAt: Date;
  updatedAt: Date;
}

const StorySchema = new Schema<IStory>(
  {
    title: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, trim: true },
    author: { type: String, required: true, trim: true },
    coverImage: { type: String, required: true },
    description: { type: String, required: true },
    categories: [{ type: Schema.Types.ObjectId, ref: 'Category' }],
    status: { type: String, enum: ['ongoing', 'completed', 'paused'], default: 'ongoing' },
    views: { type: Number, default: 0 },
    ratingAvg: { type: Number, default: 0 },
    ratingCount: { type: Number, default: 0 },
    totalChapters: { type: Number, default: 0 },
    latestChapterAt: { type: Date, default: Date.now },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

StorySchema.index({ title: 'text', author: 'text' });
StorySchema.index({ latestChapterAt: -1 });
StorySchema.index({ views: -1 });

const Story: Model<IStory> = mongoose.models.Story || mongoose.model<IStory>('Story', StorySchema);
export default Story;
