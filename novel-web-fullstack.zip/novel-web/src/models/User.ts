import mongoose, { Schema, Document, Model, Types } from 'mongoose';
import { UserRole } from '@/lib/jwt';

export interface IBookmark {
  storyId: Types.ObjectId;
  addedAt: Date;
}

export interface IReadingHistory {
  storyId: Types.ObjectId;
  chapterId: Types.ObjectId;
  chapterNumber: number;
  chapterSlug: string;
  scrollPosition: number;
  updatedAt: Date;
}

export interface IUser extends Document {
  username: string;
  email: string;
  passwordHash: string;
  avatar: string;
  role: UserRole;
  isBanned: boolean;
  bookmarks: IBookmark[];
  readingHistory: IReadingHistory[];
  createdAt: Date;
  updatedAt: Date;
}

const BookmarkSchema = new Schema<IBookmark>(
  {
    storyId: { type: Schema.Types.ObjectId, ref: 'Story', required: true },
    addedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

const ReadingHistorySchema = new Schema<IReadingHistory>(
  {
    storyId: { type: Schema.Types.ObjectId, ref: 'Story', required: true },
    chapterId: { type: Schema.Types.ObjectId, ref: 'Chapter', required: true },
    chapterNumber: { type: Number, required: true },
    chapterSlug: { type: String, required: true },
    scrollPosition: { type: Number, default: 0 },
    updatedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

const UserSchema = new Schema<IUser>(
  {
    username: { type: String, required: true, unique: true, trim: true, minlength: 3, maxlength: 30 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    avatar: { type: String, default: '' },
    role: { type: String, enum: ['admin', 'moderator', 'user'], default: 'user' },
    isBanned: { type: Boolean, default: false },
    bookmarks: { type: [BookmarkSchema], default: [] },
    readingHistory: { type: [ReadingHistorySchema], default: [] },
  },
  { timestamps: true }
);

const User: Model<IUser> = mongoose.models.User || mongoose.model<IUser>('User', UserSchema);
export default User;
