import mongoose, { Schema, Document, Model, Types } from 'mongoose';

export interface IChapter extends Document {
  storyId: Types.ObjectId;
  chapterNumber: number;
  title: string;
  slug: string;
  content: string;
  views: number;
  createdAt: Date;
  updatedAt: Date;
}

const ChapterSchema = new Schema<IChapter>(
  {
    storyId: { type: Schema.Types.ObjectId, ref: 'Story', required: true, index: true },
    chapterNumber: { type: Number, required: true },
    title: { type: String, required: true, trim: true },
    slug: { type: String, required: true, trim: true },
    content: { type: String, required: true },
    views: { type: Number, default: 0 },
  },
  { timestamps: true }
);

ChapterSchema.index({ storyId: 1, chapterNumber: 1 }, { unique: true });
ChapterSchema.index({ storyId: 1, slug: 1 }, { unique: true });

const Chapter: Model<IChapter> =
  mongoose.models.Chapter || mongoose.model<IChapter>('Chapter', ChapterSchema);
export default Chapter;
