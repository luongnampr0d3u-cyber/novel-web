import mongoose, { Schema, Document, Model } from 'mongoose';

export interface ISiteSetting extends Document {
  siteName: string;
  logoUrl: string;
  primaryColor: string;
  announcement: string;
  bannerTitle: string;
  bannerSubtitle: string;
  footerText: string;
  maintenanceMode: boolean;
  updatedAt: Date;
}

const SiteSettingSchema = new Schema<ISiteSetting>(
  {
    siteName: { type: String, default: 'Tàng Kinh Các' },
    logoUrl: { type: String, default: '' },
    primaryColor: { type: String, default: '#2563eb' },
    announcement: { type: String, default: 'Chào mừng bạn đến với website đọc truyện chữ online!' },
    bannerTitle: { type: String, default: 'Khám phá kho truyện chữ đặc sắc' },
    bannerSubtitle: { type: String, default: 'Cập nhật chương mới mỗi ngày, giao diện đọc mượt mà.' },
    footerText: { type: String, default: '© 2026 Tàng Kinh Các. Mọi quyền được bảo lưu.' },
    maintenanceMode: { type: Boolean, default: false },
  },
  { timestamps: true }
);

const SiteSetting: Model<ISiteSetting> =
  mongoose.models.SiteSetting || mongoose.model<ISiteSetting>('SiteSetting', SiteSettingSchema);
export default SiteSetting;
