import mongoose, { Schema, Document, Model, Types } from 'mongoose';

export interface IComment extends Document {
  storyId: Types.ObjectId;
  chapterId?: Types.ObjectId | null;
  userId: Types.ObjectId;
  parentId?: Types.ObjectId | null;
  content: string;
  isHidden: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const CommentSchema = new Schema<IComment>(
  {
    storyId: { type: Schema.Types.ObjectId, ref: 'Story', required: true, index: true },
    chapterId: { type: Schema.Types.ObjectId, ref: 'Chapter', default: null },
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    parentId: { type: Schema.Types.ObjectId, ref: 'Comment', default: null },
    content: { type: String, required: true, trim: true, maxlength: 1500 },
    isHidden: { type: Boolean, default: false },
  },
  { timestamps: true }
);

CommentSchema.index({ storyId: 1, createdAt: -1 });

const Comment: Model<IComment> =
  mongoose.models.Comment || mongoose.model<IComment>('Comment', CommentSchema);
export default Comment;
