import mongoose, { Schema, Document, Model, Types } from 'mongoose';

export interface IRating extends Document {
  storyId: Types.ObjectId;
  userId: Types.ObjectId;
  score: number;
  createdAt: Date;
  updatedAt: Date;
}

const RatingSchema = new Schema<IRating>(
  {
    storyId: { type: Schema.Types.ObjectId, ref: 'Story', required: true },
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    score: { type: Number, required: true, min: 1, max: 5 },
  },
  { timestamps: true }
);

RatingSchema.index({ storyId: 1, userId: 1 }, { unique: true });

const Rating: Model<IRating> =
  mongoose.models.Rating || mongoose.model<IRating>('Rating', RatingSchema);
export default Rating;
