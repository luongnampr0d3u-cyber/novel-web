import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { AUTH_COOKIE_NAME, verifyToken } from '@/lib/jwt';

const ADMIN_ONLY_PATHS = ['/admin/nguoi-dung', '/admin/cai-dat'];

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (pathname.startsWith('/admin')) {
    const token = request.cookies.get(AUTH_COOKIE_NAME)?.value;

    if (!token) {
      const loginUrl = new URL('/dang-nhap', request.url);
      loginUrl.searchParams.set('redirect', pathname);
      return NextResponse.redirect(loginUrl);
    }

    const payload = await verifyToken(token);
    if (!payload) {
      const loginUrl = new URL('/dang-nhap', request.url);
      return NextResponse.redirect(loginUrl);
    }

    if (payload.role !== 'admin' && payload.role !== 'moderator') {
      return NextResponse.redirect(new URL('/', request.url));
    }

    const isAdminOnly = ADMIN_ONLY_PATHS.some((path) => pathname.startsWith(path));
    if (isAdminOnly && payload.role !== 'admin') {
      return NextResponse.redirect(new URL('/admin', request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/:path*'],
};
