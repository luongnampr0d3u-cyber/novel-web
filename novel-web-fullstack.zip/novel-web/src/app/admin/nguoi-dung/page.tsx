'use client';

import { useEffect, useState } from 'react';
import { Ban, CheckCircle, Trash2 } from 'lucide-react';
import { formatDate } from '@/lib/utils';

interface AdminUser {
  _id: string;
  username: string;
  email: string;
  role: 'admin' | 'moderator' | 'user';
  isBanned: boolean;
  createdAt: string;
}

export default function AdminUsersPage() {
  const [users, setUsers] = useState<AdminUser[]>([]);

  const loadUsers = async () => {
    const res = await fetch('/api/admin/users');
    const data = await res.json();
    setUsers(data.users || []);
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const updateUser = async (id: string, payload: Partial<AdminUser>) => {
    const res = await fetch(`/api/admin/users/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) {
      alert(data.error || 'Không thể cập nhật.');
      return;
    }
    loadUsers();
  };

  const deleteUser = async (id: string) => {
    if (!confirm('Xóa tài khoản này vĩnh viễn?')) return;
    const res = await fetch(`/api/admin/users/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) {
      alert(data.error || 'Không thể xóa.');
      return;
    }
    loadUsers();
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Quản lý Người dùng</h1>

      <div className="overflow-x-auto rounded-xl border border-gray-200 bg-white">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-gray-200 bg-gray-50 text-xs uppercase text-gray-600">
            <tr>
              <th className="px-4 py-3">Tài khoản</th>
              <th className="px-4 py-3">Email</th>
              <th className="px-4 py-3">Vai trò</th>
              <th className="px-4 py-3">Ngày tạo</th>
              <th className="px-4 py-3 text-right">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {users.map((u) => (
              <tr key={u._id} className={u.isBanned ? 'bg-red-50/40' : ''}>
                <td className="px-4 py-3 font-semibold text-gray-900">
                  {u.username}
                  {u.isBanned && (
                    <span className="ml-2 rounded bg-red-100 px-1.5 py-0.5 text-[10px] text-red-700">
                      BỊ KHÓA
                    </span>
                  )}
                </td>
                <td className="px-4 py-3 text-gray-600">{u.email}</td>
                <td className="px-4 py-3">
                  <select
                    value={u.role}
                    onChange={(e) =>
                      updateUser(u._id, { role: e.target.value as AdminUser['role'] })
                    }
                    className="rounded border border-gray-300 px-2 py-1 text-xs font-medium"
                  >
                    <option value="user">User</option>
                    <option value="moderator">Moderator</option>
                    <option value="admin">Admin</option>
                  </select>
                </td>
                <td className="px-4 py-3 text-xs text-gray-500">{formatDate(u.createdAt)}</td>
                <td className="px-4 py-3 text-right">
                  <button
                    onClick={() => updateUser(u._id, { isBanned: !u.isBanned })}
                    className="mr-2 rounded p-1.5 text-amber-600 hover:bg-amber-50"
                    title={u.isBanned ? 'Mở khóa' : 'Khóa tài khoản'}
                  >
                    {u.isBanned ? <CheckCircle className="h-4 w-4" /> : <Ban className="h-4 w-4" />}
                  </button>
                  <button
                    onClick={() => deleteUser(u._id)}
                    className="rounded p-1.5 text-red-600 hover:bg-red-50"
                    title="Xóa"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
