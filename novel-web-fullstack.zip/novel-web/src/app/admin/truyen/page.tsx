'use client';

import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Upload } from 'lucide-react';

interface CategoryItem {
  _id: string;
  name: string;
}

interface StoryItem {
  _id: string;
  title: string;
  slug: string;
  author: string;
  coverImage: string;
  description: string;
  status: 'ongoing' | 'completed' | 'paused';
  totalChapters: number;
  categories: CategoryItem[];
}

export default function AdminStoriesPage() {
  const [stories, setStories] = useState<StoryItem[]>([]);
  const [categories, setCategories] = useState<CategoryItem[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<'ongoing' | 'completed' | 'paused'>('ongoing');
  const [selectedCats, setSelectedCats] = useState<string[]>([]);

  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  const loadData = async () => {
    const [sRes, cRes] = await Promise.all([
      fetch('/api/stories?limit=50'),
      fetch('/api/categories'),
    ]);
    const sData = await sRes.json();
    const cData = await cRes.json();
    setStories(sData.stories || []);
    setCategories(cData.categories || []);
  };

  useEffect(() => {
    loadData();
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setTitle('');
    setAuthor('');
    setCoverImage('');
    setDescription('');
    setStatus('ongoing');
    setSelectedCats([]);
  };

  const handleUploadCover = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setMessage('');
    try {
      const formData = new FormData();
      formData.append('file', file);
      const res = await fetch('/api/upload', { method: 'POST', body: formData });
      const data = await res.json();
      if (!res.ok) {
        setMessage(data.error || 'Upload ảnh thất bại.');
        return;
      }
      setCoverImage(data.url);
      setMessage('Đã upload ảnh bìa thành công!');
    } finally {
      setUploading(false);
    }
  };

  const toggleCategory = (id: string) => {
    setSelectedCats((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage('');

    const payload = {
      title,
      author,
      coverImage,
      description,
      status,
      categories: selectedCats,
    };

    try {
      const url = editingId ? `/api/stories/${editingId}` : '/api/stories';
      const method = editingId ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage(data.error || 'Lưu truyện thất bại.');
        return;
      }
      setMessage(editingId ? 'Đã cập nhật truyện!' : 'Đã thêm truyện mới!');
      resetForm();
      loadData();
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (story: StoryItem) => {
    setEditingId(story._id);
    setTitle(story.title);
    setAuthor(story.author);
    setCoverImage(story.coverImage);
    setDescription(story.description);
    setStatus(story.status);
    setSelectedCats((story.categories || []).map((c) => c._id));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Xóa truyện sẽ xóa toàn bộ chương và bình luận liên quan. Tiếp tục?')) return;
    const res = await fetch(`/api/stories/${id}`, { method: 'DELETE' });
    if (res.ok) loadData();
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Quản lý Truyện</h1>

      <form onSubmit={handleSubmit} className="rounded-xl border border-gray-200 bg-white p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-gray-800">
            {editingId ? 'Chỉnh sửa truyện' : 'Thêm truyện mới'}
          </h2>
          {editingId && (
            <button type="button" onClick={resetForm} className="text-xs text-gray-500 underline">
              Hủy chỉnh sửa
            </button>
          )}
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs font-semibold text-gray-700">Tên truyện</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-semibold text-gray-700">Tác giả</label>
            <input
              type="text"
              required
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
            />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs font-semibold text-gray-700">
              Upload ảnh bìa trực tiếp (JPG/PNG/WEBP)
            </label>
            <div className="flex items-center gap-3">
              <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-xs font-medium hover:bg-gray-100">
                <Upload className="h-4 w-4" />
                {uploading ? 'Đang tải lên...' : 'Chọn file ảnh'}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleUploadCover}
                  className="hidden"
                />
              </label>
              <input
                type="url"
                required
                value={coverImage}
                onChange={(e) => setCoverImage(e.target.value)}
                placeholder="URL ảnh bìa sau khi upload..."
                className="flex-1 rounded-lg border border-gray-300 px-3 py-2 text-xs"
              />
            </div>
            {coverImage && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={coverImage} alt="Preview" className="mt-2 h-24 w-16 rounded object-cover" />
            )}
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold text-gray-700">Trạng thái</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as 'ongoing' | 'completed' | 'paused')}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
            >
              <option value="ongoing">Đang ra</option>
              <option value="completed">Hoàn thành</option>
              <option value="paused">Tạm ngưng</option>
            </select>
          </div>
        </div>

        <div>
          <label className="mb-1.5 block text-xs font-semibold text-gray-700">Thể loại</label>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => {
              const checked = selectedCats.includes(cat._id);
              return (
                <button
                  type="button"
                  key={cat._id}
                  onClick={() => toggleCategory(cat._id)}
                  className={`rounded-full border px-3 py-1 text-xs font-medium transition ${
                    checked
                      ? 'border-primary bg-primary text-white'
                      : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {cat.name}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <label className="mb-1 block text-xs font-semibold text-gray-700">Giới thiệu truyện</label>
          <textarea
            rows={4}
            required
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full rounded-lg border border-gray-300 p-3 text-sm"
          />
        </div>

        {message && <p className="text-sm font-medium text-primary">{message}</p>}

        <button
          type="submit"
          disabled={saving || uploading}
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white hover:opacity-90 disabled:opacity-50"
        >
          <Plus className="h-4 w-4" />
          {saving ? 'Đang lưu...' : editingId ? 'Cập nhật truyện' : 'Thêm truyện'}
        </button>
      </form>

      <div className="overflow-x-auto rounded-xl border border-gray-200 bg-white">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-gray-200 bg-gray-50 text-xs uppercase text-gray-600">
            <tr>
              <th className="px-4 py-3">Truyện</th>
              <th className="px-4 py-3">Tác giả</th>
              <th className="px-4 py-3">Chương</th>
              <th className="px-4 py-3">Trạng thái</th>
              <th className="px-4 py-3 text-right">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {stories.map((story) => (
              <tr key={story._id}>
                <td className="flex items-center gap-3 px-4 py-3 font-medium text-gray-900">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={story.coverImage} alt={story.title} className="h-12 w-8 rounded object-cover" />
                  <span className="line-clamp-1">{story.title}</span>
                </td>
                <td className="px-4 py-3 text-gray-600">{story.author}</td>
                <td className="px-4 py-3">{story.totalChapters}</td>
                <td className="px-4 py-3 capitalize">{story.status}</td>
                <td className="px-4 py-3 text-right">
                  <button
                    onClick={() => handleEdit(story)}
                    className="mr-2 rounded p-1.5 text-blue-600 hover:bg-blue-50"
                    title="Sửa"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(story._id)}
                    className="rounded p-1.5 text-red-600 hover:bg-red-50"
                    title="Xóa"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
