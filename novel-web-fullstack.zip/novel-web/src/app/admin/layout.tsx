import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth';
import AdminSidebar from '@/components/admin/AdminSidebar';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();

  if (!session || (session.role !== 'admin' && session.role !== 'moderator')) {
    redirect('/dang-nhap');
  }

  return (
    <div className="mx-auto flex min-h-[calc(100vh-120px)] max-w-7xl flex-col lg:flex-row">
      <AdminSidebar role={session.role} />
      <div className="flex-1 bg-gray-50 p-4 sm:p-6">{children}</div>
    </div>
  );
}
