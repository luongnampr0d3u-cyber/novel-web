'use client';

import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';

interface StoryOption {
  _id: string;
  title: string;
}

interface ChapterItem {
  _id: string;
  chapterNumber: number;
  title: string;
  slug: string;
  views: number;
}

export default function AdminChaptersPage() {
  const [stories, setStories] = useState<StoryOption[]>([]);
  const [selectedStoryId, setSelectedStoryId] = useState('');
  const [chapters, setChapters] = useState<ChapterItem[]>([]);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [chapterNumber, setChapterNumber] = useState('1');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [message, setMessage] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch('/api/stories?limit=50')
      .then((res) => res.json())
      .then((data) => {
        const list = data.stories || [];
        setStories(list);
        if (list.length > 0) setSelectedStoryId(list[0]._id);
      });
  }, []);

  const loadChapters = async (storyId: string) => {
    if (!storyId) return;
    const res = await fetch(`/api/chapters?storyId=${storyId}`);
    const data = await res.json();
    const list = data.chapters || [];
    setChapters(list);
    if (!editingId) {
      const nextNum = list.length > 0 ? list[list.length - 1].chapterNumber + 1 : 1;
      setChapterNumber(String(nextNum));
    }
  };

  useEffect(() => {
    loadChapters(selectedStoryId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedStoryId]);

  const resetForm = () => {
    setEditingId(null);
    setTitle('');
    setContent('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStoryId) return;

    setSaving(true);
    setMessage('');
    try {
      const url = editingId ? `/api/chapters/${editingId}` : '/api/chapters';
      const method = editingId ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storyId: selectedStoryId,
          chapterNumber: Number(chapterNumber),
          title,
          content,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage(data.error || 'Lỗi khi lưu chương.');
        return;
      }
      setMessage(editingId ? 'Đã cập nhật chương!' : 'Đã thêm chương mới!');
      resetForm();
      loadChapters(selectedStoryId);
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = async (id: string) => {
    const res = await fetch(`/api/chapters/${id}`);
    const data = await res.json();
    if (res.ok && data.chapter) {
      setEditingId(data.chapter._id);
      setChapterNumber(String(data.chapter.chapterNumber));
      setTitle(data.chapter.title);
      setContent(data.chapter.content);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Bạn chắc chắn muốn xóa chương này?')) return;
    const res = await fetch(`/api/chapters/${id}`, { method: 'DELETE' });
    if (res.ok) loadChapters(selectedStoryId);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-gray-900">Quản lý Chương</h1>
        <select
          value={selectedStoryId}
          onChange={(e) => {
            resetForm();
            setSelectedStoryId(e.target.value);
          }}
          className="min-w-[260px] rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium"
        >
          {stories.map((s) => (
            <option key={s._id} value={s._id}>
              {s.title}
            </option>
          ))}
        </select>
      </div>

      <form onSubmit={handleSubmit} className="rounded-xl border border-gray-200 bg-white p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-gray-800">
            {editingId ? 'Chỉnh sửa chương' : 'Đăng chương mới'}
          </h2>
          {editingId && (
            <button type="button" onClick={resetForm} className="text-xs text-gray-500 underline">
              Hủy chỉnh sửa
            </button>
          )}
        </div>

        <div className="grid gap-4 sm:grid-cols-4">
          <div>
            <label className="mb-1 block text-xs font-semibold text-gray-700">Số chương</label>
            <input
              type="number"
              required
              min={1}
              value={chapterNumber}
              onChange={(e) => setChapterNumber(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
            />
          </div>
          <div className="sm:col-span-3">
            <label className="mb-1 block text-xs font-semibold text-gray-700">Tiêu đề chương</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
            />
          </div>
        </div>

        <div>
          <label className="mb-1 block text-xs font-semibold text-gray-700">
            Nội dung chương (mỗi đoạn cách nhau bằng phím Enter)
          </label>
          <textarea
            rows={10}
            required
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full rounded-lg border border-gray-300 p-3 text-sm leading-relaxed"
          />
        </div>

        {message && <p className="text-sm font-medium text-primary">{message}</p>}

        <button
          type="submit"
          disabled={saving}
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white hover:opacity-90 disabled:opacity-50"
        >
          <Plus className="h-4 w-4" />
          {saving ? 'Đang lưu...' : editingId ? 'Cập nhật chương' : 'Đăng chương'}
        </button>
      </form>

      <div className="overflow-x-auto rounded-xl border border-gray-200 bg-white">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-gray-200 bg-gray-50 text-xs uppercase text-gray-600">
            <tr>
              <th className="px-4 py-3">Chương</th>
              <th className="px-4 py-3">Tiêu đề</th>
              <th className="px-4 py-3">Lượt xem</th>
              <th className="px-4 py-3 text-right">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {chapters.map((ch) => (
              <tr key={ch._id}>
                <td className="px-4 py-3 font-semibold">Chương {ch.chapterNumber}</td>
                <td className="px-4 py-3 text-gray-700">{ch.title}</td>
                <td className="px-4 py-3 text-gray-500">{ch.views}</td>
                <td className="px-4 py-3 text-right">
                  <button
                    onClick={() => handleEdit(ch._id)}
                    className="mr-2 rounded p-1.5 text-blue-600 hover:bg-blue-50"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(ch._id)}
                    className="rounded p-1.5 text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
