'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { BookOpen, FileText, Users, MessageSquare, Eye } from 'lucide-react';
import { formatDate, formatNumber } from '@/lib/utils';

interface StatsResponse {
  overview: {
    totalStories: number;
    totalChapters: number;
    totalUsers: number;
    totalComments: number;
    totalViews: number;
  };
  topStories: {
    _id: string;
    title: string;
    slug: string;
    views: number;
    totalChapters: number;
    ratingAvg: number;
  }[];
  recentUsers: {
    _id: string;
    username: string;
    email: string;
    role: string;
    createdAt: string;
  }[];
}

export default function AdminDashboardPage() {
  const [data, setData] = useState<StatsResponse | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/stats')
      .then((res) => res.json())
      .then((json) => setData(json))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="py-12 text-center text-gray-500">Đang tải thống kê...</div>;
  if (!data?.overview) return <div className="py-12 text-center text-red-600">Không tải được dữ liệu.</div>;

  const cards = [
    { label: 'Tổng truyện', value: data.overview.totalStories, icon: BookOpen, color: 'text-blue-600' },
    { label: 'Tổng chương', value: data.overview.totalChapters, icon: FileText, color: 'text-indigo-600' },
    { label: 'Tổng lượt xem', value: formatNumber(data.overview.totalViews), icon: Eye, color: 'text-emerald-600' },
    { label: 'Người dùng', value: data.overview.totalUsers, icon: Users, color: 'text-amber-600' },
    { label: 'Bình luận', value: data.overview.totalComments, icon: MessageSquare, color: 'text-rose-600' },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Dashboard Thống kê</h1>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-gray-500">{card.label}</span>
                <Icon className={`h-4 w-4 ${card.color}`} />
              </div>
              <p className="mt-2 text-2xl font-extrabold text-gray-900">{card.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <h2 className="mb-4 text-base font-bold text-gray-900">Top 5 truyện đọc nhiều nhất</h2>
          <div className="space-y-3">
            {data.topStories.map((s, idx) => (
              <div key={s._id} className="flex items-center justify-between border-b border-gray-100 pb-2 text-sm last:border-0">
                <div className="flex items-center gap-2 truncate">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gray-100 text-xs font-bold">
                    {idx + 1}
                  </span>
                  <Link href={`/truyen/${s.slug}`} className="truncate font-medium hover:text-primary">
                    {s.title}
                  </Link>
                </div>
                <span className="ml-2 shrink-0 text-xs font-semibold text-gray-600">
                  {formatNumber(s.views)} views
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <h2 className="mb-4 text-base font-bold text-gray-900">Thành viên mới đăng ký</h2>
          <div className="space-y-3">
            {data.recentUsers.map((u) => (
              <div key={u._id} className="flex items-center justify-between border-b border-gray-100 pb-2 text-sm last:border-0">
                <div>
                  <p className="font-medium text-gray-900">{u.username}</p>
                  <p className="text-xs text-gray-500">{u.email}</p>
                </div>
                <span className="text-xs text-gray-400">{formatDate(u.createdAt)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
