'use client';

import { useEffect, useState } from 'react';
import { Eye, EyeOff, Trash2 } from 'lucide-react';
import { timeAgo } from '@/lib/utils';

interface AdminComment {
  _id: string;
  content: string;
  isHidden: boolean;
  createdAt: string;
  userId?: { username: string; role: string };
  storyId?: { title: string; slug: string };
}

export default function AdminCommentsPage() {
  const [comments, setComments] = useState<AdminComment[]>([]);

  const loadComments = async () => {
    const res = await fetch('/api/comments?all=true');
    const data = await res.json();
    setComments(data.comments || []);
  };

  useEffect(() => {
    loadComments();
  }, []);

  const toggleHide = async (id: string, currentHidden: boolean) => {
    const res = await fetch(`/api/comments/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isHidden: !currentHidden }),
    });
    if (res.ok) loadComments();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Xóa vĩnh viễn bình luận này?')) return;
    const res = await fetch(`/api/comments/${id}`, { method: 'DELETE' });
    if (res.ok) loadComments();
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Kiểm duyệt Bình luận</h1>

      <div className="overflow-x-auto rounded-xl border border-gray-200 bg-white">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-gray-200 bg-gray-50 text-xs uppercase text-gray-600">
            <tr>
              <th className="px-4 py-3">Người gửi</th>
              <th className="px-4 py-3">Truyện</th>
              <th className="px-4 py-3">Nội dung</th>
              <th className="px-4 py-3">Trạng thái</th>
              <th className="px-4 py-3 text-right">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {comments.map((c) => (
              <tr key={c._id}>
                <td className="px-4 py-3">
                  <p className="font-semibold">{c.userId?.username || 'Ẩn danh'}</p>
                  <p className="text-xs text-gray-400">{timeAgo(c.createdAt)}</p>
                </td>
                <td className="px-4 py-3 text-gray-700">{c.storyId?.title || '-'}</td>
                <td className="max-w-md px-4 py-3 text-gray-700">{c.content}</td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded px-2 py-0.5 text-xs font-semibold ${
                      c.isHidden ? 'bg-gray-200 text-gray-600' : 'bg-emerald-100 text-emerald-700'
                    }`}
                  >
                    {c.isHidden ? 'Đang ẩn' : 'Hiển thị'}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <button
                    onClick={() => toggleHide(c._id, c.isHidden)}
                    className="mr-2 rounded p-1.5 text-amber-600 hover:bg-amber-50"
                    title={c.isHidden ? 'Hiện lại' : 'Ẩn bình luận'}
                  >
                    {c.isHidden ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                  </button>
                  <button
                    onClick={() => handleDelete(c._id)}
                    className="rounded p-1.5 text-red-600 hover:bg-red-50"
                    title="Xóa"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
