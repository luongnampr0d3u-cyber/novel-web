'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Bookmark, History, BookOpen } from 'lucide-react';
import { timeAgo } from '@/lib/utils';

interface BookmarkRecord {
  storyId: {
    _id: string;
    title: string;
    slug: string;
    author: string;
    coverImage: string;
    totalChapters: number;
  };
  addedAt: string;
}

interface HistoryRecord {
  storyId: {
    _id: string;
    title: string;
    slug: string;
    coverImage: string;
  };
  chapterNumber: number;
  chapterSlug: string;
  updatedAt: string;
}

export default function BookshelfPage() {
  const [tab, setTab] = useState<'bookmarks' | 'history'>('bookmarks');
  const [bookmarks, setBookmarks] = useState<BookmarkRecord[]>([]);
  const [history, setHistory] = useState<HistoryRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [unauth, setUnauth] = useState(false);

  useEffect(() => {
    fetch('/api/bookshelf')
      .then(async (res) => {
        if (res.status === 401) {
          setUnauth(true);
          return;
        }
        const data = await res.json();
        setBookmarks((data.bookmarks || []).filter((b: BookmarkRecord) => b.storyId));
        setHistory((data.readingHistory || []).filter((h: HistoryRecord) => h.storyId));
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="py-16 text-center text-gray-500">Đang tải tủ truyện...</div>;

  if (unauth) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <h1 className="text-xl font-bold text-gray-900">Vui lòng đăng nhập</h1>
        <p className="mt-2 text-sm text-gray-600">
          Đăng nhập để đồng bộ tủ truyện yêu thích và lịch sử đọc trên mọi thiết bị.
        </p>
        <Link
          href="/dang-nhap"
          className="mt-5 inline-block rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-white"
        >
          Đăng nhập ngay
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-bold text-gray-900">Tủ truyện của tôi</h1>

      <div className="mb-6 flex gap-2 border-b border-gray-200">
        <button
          onClick={() => setTab('bookmarks')}
          className={`flex items-center gap-1.5 border-b-2 px-4 py-2.5 text-sm font-semibold ${
            tab === 'bookmarks'
              ? 'border-primary text-primary'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          <Bookmark className="h-4 w-4" />
          Đang theo dõi ({bookmarks.length})
        </button>
        <button
          onClick={() => setTab('history')}
          className={`flex items-center gap-1.5 border-b-2 px-4 py-2.5 text-sm font-semibold ${
            tab === 'history'
              ? 'border-primary text-primary'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          <History className="h-4 w-4" />
          Lịch sử đọc ({history.length})
        </button>
      </div>

      {tab === 'bookmarks' ? (
        bookmarks.length === 0 ? (
          <p className="py-12 text-center text-sm text-gray-500">Bạn chưa lưu truyện nào.</p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {bookmarks.map((item) => (
              <Link
                key={item.storyId._id}
                href={`/truyen/${item.storyId.slug}`}
                className="flex gap-3 rounded-xl border border-gray-200 bg-white p-3 hover:shadow-sm"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={item.storyId.coverImage}
                  alt={item.storyId.title}
                  className="h-24 w-16 rounded object-cover"
                />
                <div className="flex flex-1 flex-col justify-between">
                  <div>
                    <h3 className="line-clamp-2 text-sm font-bold text-gray-900">
                      {item.storyId.title}
                    </h3>
                    <p className="mt-0.5 text-xs text-gray-500">{item.storyId.author}</p>
                  </div>
                  <p className="text-xs text-primary">{item.storyId.totalChapters} chương</p>
                </div>
              </Link>
            ))}
          </div>
        )
      ) : history.length === 0 ? (
        <p className="py-12 text-center text-sm text-gray-500">Chưa có lịch sử đọc truyện.</p>
      ) : (
        <div className="space-y-3">
          {history.map((item) => (
            <div
              key={item.storyId._id}
              className="flex items-center justify-between gap-4 rounded-xl border border-gray-200 bg-white p-3"
            >
              <div className="flex items-center gap-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={item.storyId.coverImage}
                  alt={item.storyId.title}
                  className="h-16 w-12 rounded object-cover"
                />
                <div>
                  <Link
                    href={`/truyen/${item.storyId.slug}`}
                    className="font-bold text-gray-900 hover:text-primary"
                  >
                    {item.storyId.title}
                  </Link>
                  <p className="text-xs text-gray-500">
                    Đang đọc: Chương {item.chapterNumber} • {timeAgo(item.updatedAt)}
                  </p>
                </div>
              </div>
              <Link
                href={`/truyen/${item.storyId.slug}/${item.chapterSlug}`}
                className="inline-flex shrink-0 items-center gap-1 rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-white hover:opacity-90"
              >
                <BookOpen className="h-3.5 w-3.5" />
                Đọc tiếp
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
