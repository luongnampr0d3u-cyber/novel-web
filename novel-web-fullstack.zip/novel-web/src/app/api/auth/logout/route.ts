import { NextResponse } from 'next/server';
import { AUTH_COOKIE_NAME } from '@/lib/jwt';

export async function POST() {
  const response = NextResponse.json({ message: 'Đăng xuất thành công.' });
  response.cookies.set(AUTH_COOKIE_NAME, '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 0,
    path: '/',
  });
  return response;
}
