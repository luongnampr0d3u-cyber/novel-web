import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import Story from '@/models/Story';
import Category from '@/models/Category';
import { requireAuth } from '@/lib/auth';
import { slugify } from '@/lib/utils';

export async function GET(request: Request) {
  try {
    await connectDB();

    const { searchParams } = new URL(request.url);
    const q = searchParams.get('q')?.trim() || '';
    const categorySlug = searchParams.get('category') || '';
    const status = searchParams.get('status') || '';
    const sort = searchParams.get('sort') || 'latest';
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '12', 10)));

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const filter: Record<string, any> = {};

    if (q) {
      filter.$or = [
        { title: { $regex: q, $options: 'i' } },
        { author: { $regex: q, $options: 'i' } },
      ];
    }

    if (status && ['ongoing', 'completed', 'paused'].includes(status)) {
      filter.status = status;
    }

    if (categorySlug) {
      const cat = await Category.findOne({ slug: categorySlug }).select('_id');
      if (cat) {
        filter.categories = cat._id;
      } else {
        return NextResponse.json({ stories: [], total: 0, page, totalPages: 0 });
      }
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let sortOption: Record<string, any> = { latestChapterAt: -1 };
    if (sort === 'views') sortOption = { views: -1 };
    else if (sort === 'rating') sortOption = { ratingAvg: -1, ratingCount: -1 };
    else if (sort === 'newest') sortOption = { createdAt: -1 };

    const [stories, total] = await Promise.all([
      Story.find(filter)
        .populate('categories', 'name slug')
        .sort(sortOption)
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      Story.countDocuments(filter),
    ]);

    return NextResponse.json({
      stories,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('GET stories error:', error);
    return NextResponse.json({ error: 'Không thể tải danh sách truyện.' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireAuth(['admin', 'moderator']);
    if (!session) {
      return NextResponse.json({ error: 'Không có quyền thêm truyện.' }, { status: 403 });
    }

    const { title, author, coverImage, description, categories, status } = await request.json();

    if (!title?.trim() || !author?.trim() || !coverImage?.trim() || !description?.trim()) {
      return NextResponse.json(
        { error: 'Vui lòng nhập đầy đủ tên truyện, tác giả, ảnh bìa và giới thiệu.' },
        { status: 400 }
      );
    }

    await connectDB();

    let slug = slugify(title);
    const existingSlug = await Story.findOne({ slug });
    if (existingSlug) {
      slug = `${slug}-${Date.now().toString().slice(-4)}`;
    }

    const story = await Story.create({
      title: title.trim(),
      slug,
      author: author.trim(),
      coverImage: coverImage.trim(),
      description: description.trim(),
      categories: Array.isArray(categories) ? categories : [],
      status: status || 'ongoing',
      createdBy: session.userId,
    });

    return NextResponse.json({ story }, { status: 201 });
  } catch (error) {
    console.error('POST story error:', error);
    return NextResponse.json({ error: 'Lỗi khi tạo truyện.' }, { status: 500 });
  }
}
