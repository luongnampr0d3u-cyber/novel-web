import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import { connectDB } from '@/lib/db';
import Story from '@/models/Story';
import Chapter from '@/models/Chapter';
import Comment from '@/models/Comment';
import Rating from '@/models/Rating';
import { requireAuth } from '@/lib/auth';
import { slugify } from '@/lib/utils';

export async function GET(_request: Request, { params }: { params: { id: string } }) {
  try {
    await connectDB();

    const query = mongoose.Types.ObjectId.isValid(params.id)
      ? { _id: params.id }
      : { slug: params.id };

    const story = await Story.findOne(query).populate('categories', 'name slug').lean();
    if (!story) {
      return NextResponse.json({ error: 'Không tìm thấy truyện.' }, { status: 404 });
    }

    return NextResponse.json({ story });
  } catch (error) {
    console.error('GET story detail error:', error);
    return NextResponse.json({ error: 'Lỗi khi tải thông tin truyện.' }, { status: 500 });
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await requireAuth(['admin', 'moderator']);
    if (!session) {
      return NextResponse.json({ error: 'Không có quyền sửa truyện.' }, { status: 403 });
    }

    const { title, author, coverImage, description, categories, status } = await request.json();

    await connectDB();

    const updateData: Record<string, unknown> = {};
    if (title?.trim()) {
      updateData.title = title.trim();
      updateData.slug = slugify(title);
    }
    if (author?.trim()) updateData.author = author.trim();
    if (coverImage?.trim()) updateData.coverImage = coverImage.trim();
    if (description?.trim()) updateData.description = description.trim();
    if (Array.isArray(categories)) updateData.categories = categories;
    if (status && ['ongoing', 'completed', 'paused'].includes(status)) updateData.status = status;

    const updated = await Story.findByIdAndUpdate(params.id, updateData, { new: true }).populate(
      'categories',
      'name slug'
    );

    if (!updated) {
      return NextResponse.json({ error: 'Không tìm thấy truyện.' }, { status: 404 });
    }

    return NextResponse.json({ story: updated });
  } catch (error) {
    console.error('PUT story error:', error);
    return NextResponse.json({ error: 'Lỗi khi cập nhật truyện.' }, { status: 500 });
  }
}

export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await requireAuth(['admin', 'moderator']);
    if (!session) {
      return NextResponse.json({ error: 'Không có quyền xóa truyện.' }, { status: 403 });
    }

    await connectDB();

    const deleted = await Story.findByIdAndDelete(params.id);
    if (!deleted) {
      return NextResponse.json({ error: 'Không tìm thấy truyện.' }, { status: 404 });
    }

    await Promise.all([
      Chapter.deleteMany({ storyId: params.id }),
      Comment.deleteMany({ storyId: params.id }),
      Rating.deleteMany({ storyId: params.id }),
    ]);

    return NextResponse.json({ message: 'Đã xóa truyện và toàn bộ chương liên quan.' });
  } catch (error) {
    console.error('DELETE story error:', error);
    return NextResponse.json({ error: 'Lỗi khi xóa truyện.' }, { status: 500 });
  }
}
