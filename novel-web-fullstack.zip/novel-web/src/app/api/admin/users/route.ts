import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import User from '@/models/User';
import { requireAuth } from '@/lib/auth';

export async function GET() {
  try {
    const session = await requireAuth(['admin']);
    if (!session) {
      return NextResponse.json({ error: 'Chỉ Admin mới có quyền xem người dùng.' }, { status: 403 });
    }

    await connectDB();
    const users = await User.find()
      .select('-passwordHash -bookmarks -readingHistory')
      .sort({ createdAt: -1 })
      .lean();

    return NextResponse.json({ users });
  } catch (error) {
    console.error('GET admin users error:', error);
    return NextResponse.json({ error: 'Không thể tải danh sách người dùng.' }, { status: 500 });
  }
}
