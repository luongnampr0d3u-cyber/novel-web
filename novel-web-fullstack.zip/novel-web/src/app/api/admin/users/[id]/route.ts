import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import User from '@/models/User';
import { requireAuth } from '@/lib/auth';

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await requireAuth(['admin']);
    if (!session) {
      return NextResponse.json({ error: 'Chỉ Admin mới có quyền chỉnh sửa người dùng.' }, { status: 403 });
    }

    if (params.id === session.userId) {
      return NextResponse.json(
        { error: 'Không thể tự thay đổi quyền hoặc tự khóa tài khoản của chính mình.' },
        { status: 400 }
      );
    }

    const { role, isBanned } = await request.json();

    const updateData: Record<string, unknown> = {};
    if (role && ['admin', 'moderator', 'user'].includes(role)) updateData.role = role;
    if (typeof isBanned === 'boolean') updateData.isBanned = isBanned;

    await connectDB();
    const updated = await User.findByIdAndUpdate(params.id, updateData, { new: true }).select(
      '-passwordHash'
    );

    if (!updated) {
      return NextResponse.json({ error: 'Không tìm thấy người dùng.' }, { status: 404 });
    }

    return NextResponse.json({ user: updated });
  } catch (error) {
    console.error('PATCH admin user error:', error);
    return NextResponse.json({ error: 'Lỗi khi cập nhật người dùng.' }, { status: 500 });
  }
}

export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await requireAuth(['admin']);
    if (!session) {
      return NextResponse.json({ error: 'Chỉ Admin mới có quyền xóa người dùng.' }, { status: 403 });
    }

    if (params.id === session.userId) {
      return NextResponse.json({ error: 'Không thể tự xóa tài khoản của chính mình.' }, { status: 400 });
    }

    await connectDB();
    const deleted = await User.findByIdAndDelete(params.id);
    if (!deleted) {
      return NextResponse.json({ error: 'Không tìm thấy người dùng.' }, { status: 404 });
    }

    return NextResponse.json({ message: 'Đã xóa người dùng.' });
  } catch (error) {
    console.error('DELETE admin user error:', error);
    return NextResponse.json({ error: 'Lỗi khi xóa người dùng.' }, { status: 500 });
  }
}
