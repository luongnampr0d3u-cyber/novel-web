import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import Story from '@/models/Story';
import Chapter from '@/models/Chapter';
import User from '@/models/User';
import Comment from '@/models/Comment';
import { requireAuth } from '@/lib/auth';

export async function GET() {
  try {
    const session = await requireAuth(['admin', 'moderator']);
    if (!session) {
      return NextResponse.json({ error: 'Không có quyền truy cập.' }, { status: 403 });
    }

    await connectDB();

    const [
      totalStories,
      totalChapters,
      totalUsers,
      totalComments,
      viewsAgg,
      topStories,
      recentUsers,
    ] = await Promise.all([
      Story.countDocuments(),
      Chapter.countDocuments(),
      User.countDocuments(),
      Comment.countDocuments(),
      Story.aggregate([{ $group: { _id: null, totalViews: { $sum: '$views' } } }]),
      Story.find().sort({ views: -1 }).limit(5).select('title slug views totalChapters ratingAvg').lean(),
      User.find().sort({ createdAt: -1 }).limit(5).select('username email role createdAt').lean(),
    ]);

    return NextResponse.json({
      overview: {
        totalStories,
        totalChapters,
        totalUsers,
        totalComments,
        totalViews: viewsAgg[0]?.totalViews || 0,
      },
      topStories,
      recentUsers,
    });
  } catch (error) {
    console.error('GET admin stats error:', error);
    return NextResponse.json({ error: 'Không thể tải thống kê.' }, { status: 500 });
  }
}
