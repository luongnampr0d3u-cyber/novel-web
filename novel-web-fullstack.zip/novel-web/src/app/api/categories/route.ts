import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import Category from '@/models/Category';
import { requireAuth } from '@/lib/auth';
import { slugify } from '@/lib/utils';

export async function GET() {
  try {
    await connectDB();
    const categories = await Category.find().sort({ name: 1 }).lean();
    return NextResponse.json({ categories });
  } catch (error) {
    console.error('GET categories error:', error);
    return NextResponse.json({ error: 'Không thể tải danh sách thể loại.' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireAuth(['admin', 'moderator']);
    if (!session) {
      return NextResponse.json({ error: 'Không có quyền thực hiện.' }, { status: 403 });
    }

    const { name, description } = await request.json();
    if (!name || !name.trim()) {
      return NextResponse.json({ error: 'Tên thể loại không được để trống.' }, { status: 400 });
    }

    await connectDB();
    const slug = slugify(name);

    const existing = await Category.findOne({ slug });
    if (existing) {
      return NextResponse.json({ error: 'Thể loại này đã tồn tại.' }, { status: 409 });
    }

    const category = await Category.create({
      name: name.trim(),
      slug,
      description: description?.trim() || '',
    });

    return NextResponse.json({ category }, { status: 201 });
  } catch (error) {
    console.error('POST category error:', error);
    return NextResponse.json({ error: 'Lỗi khi tạo thể loại.' }, { status: 500 });
  }
}
