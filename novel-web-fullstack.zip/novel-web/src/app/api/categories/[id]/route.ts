import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import Category from '@/models/Category';
import Story from '@/models/Story';
import { requireAuth } from '@/lib/auth';
import { slugify } from '@/lib/utils';

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await requireAuth(['admin', 'moderator']);
    if (!session) {
      return NextResponse.json({ error: 'Không có quyền thực hiện.' }, { status: 403 });
    }

    const { name, description } = await request.json();
    if (!name || !name.trim()) {
      return NextResponse.json({ error: 'Tên thể loại không được để trống.' }, { status: 400 });
    }

    await connectDB();
    const slug = slugify(name);

    const updated = await Category.findByIdAndUpdate(
      params.id,
      { name: name.trim(), slug, description: description?.trim() || '' },
      { new: true }
    );

    if (!updated) {
      return NextResponse.json({ error: 'Không tìm thấy thể loại.' }, { status: 404 });
    }

    return NextResponse.json({ category: updated });
  } catch (error) {
    console.error('PUT category error:', error);
    return NextResponse.json({ error: 'Lỗi khi cập nhật thể loại.' }, { status: 500 });
  }
}

export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await requireAuth(['admin']);
    if (!session) {
      return NextResponse.json({ error: 'Chỉ Admin mới có quyền xóa thể loại.' }, { status: 403 });
    }

    await connectDB();
    const deleted = await Category.findByIdAndDelete(params.id);
    if (!deleted) {
      return NextResponse.json({ error: 'Không tìm thấy thể loại.' }, { status: 404 });
    }

    await Story.updateMany({ categories: params.id }, { $pull: { categories: params.id } });

    return NextResponse.json({ message: 'Đã xóa thể loại.' });
  } catch (error) {
    console.error('DELETE category error:', error);
    return NextResponse.json({ error: 'Lỗi khi xóa thể loại.' }, { status: 500 });
  }
}
