import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import SiteSetting from '@/models/SiteSetting';
import { requireAuth } from '@/lib/auth';

export async function GET() {
  try {
    await connectDB();
    let settings = await SiteSetting.findOne().lean();
    if (!settings) {
      const created = await SiteSetting.create({});
      settings = created.toObject();
    }
    return NextResponse.json({ settings });
  } catch (error) {
    console.error('GET settings error:', error);
    return NextResponse.json({ error: 'Không thể tải cài đặt website.' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const session = await requireAuth(['admin']);
    if (!session) {
      return NextResponse.json({ error: 'Chỉ Admin mới có quyền cài đặt giao diện.' }, { status: 403 });
    }

    const body = await request.json();

    await connectDB();
    let settings = await SiteSetting.findOne();
    if (!settings) {
      settings = new SiteSetting();
    }

    const allowedFields = [
      'siteName',
      'logoUrl',
      'primaryColor',
      'announcement',
      'bannerTitle',
      'bannerSubtitle',
      'footerText',
      'maintenanceMode',
    ] as const;

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (settings as any)[field] = body[field];
      }
    }

    await settings.save();
    return NextResponse.json({ settings });
  } catch (error) {
    console.error('PUT settings error:', error);
    return NextResponse.json({ error: 'Lỗi khi lưu cài đặt website.' }, { status: 500 });
  }
}
