import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import User from '@/models/User';
import { requireAuth } from '@/lib/auth';

export async function GET() {
  try {
    const session = await requireAuth(['admin', 'moderator', 'user']);
    if (!session) {
      return NextResponse.json({ error: 'Vui lòng đăng nhập.' }, { status: 401 });
    }

    await connectDB();
    const user = await User.findById(session.userId)
      .select('bookmarks readingHistory')
      .populate('bookmarks.storyId', 'title slug author coverImage status totalChapters ratingAvg')
      .populate('readingHistory.storyId', 'title slug author coverImage totalChapters')
      .lean();

    if (!user) {
      return NextResponse.json({ error: 'Không tìm thấy người dùng.' }, { status: 404 });
    }

    const sortedHistory = [...(user.readingHistory || [])].sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );

    return NextResponse.json({
      bookmarks: user.bookmarks || [],
      readingHistory: sortedHistory,
    });
  } catch (error) {
    console.error('GET bookshelf error:', error);
    return NextResponse.json({ error: 'Không thể tải tủ truyện.' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireAuth(['admin', 'moderator', 'user']);
    if (!session) {
      return NextResponse.json({ error: 'Vui lòng đăng nhập để lưu truyện.' }, { status: 401 });
    }

    const { storyId } = await request.json();
    if (!storyId) {
      return NextResponse.json({ error: 'Thiếu storyId.' }, { status: 400 });
    }

    await connectDB();
    const user = await User.findById(session.userId);
    if (!user) {
      return NextResponse.json({ error: 'Người dùng không tồn tại.' }, { status: 404 });
    }

    const idx = user.bookmarks.findIndex((b) => b.storyId.toString() === storyId);
    let bookmarked = false;

    if (idx > -1) {
      user.bookmarks.splice(idx, 1);
      bookmarked = false;
    } else {
      user.bookmarks.unshift({ storyId, addedAt: new Date() });
      bookmarked = true;
    }

    await user.save();
    return NextResponse.json({ bookmarked });
  } catch (error) {
    console.error('POST bookshelf error:', error);
    return NextResponse.json({ error: 'Lỗi khi cập nhật tủ truyện.' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const session = await requireAuth(['admin', 'moderator', 'user']);
    if (!session) {
      return NextResponse.json({ saved: false }, { status: 200 });
    }

    const { storyId, chapterId, chapterNumber, chapterSlug, scrollPosition } = await request.json();
    if (!storyId || !chapterId) {
      return NextResponse.json({ error: 'Thiếu thông tin chương.' }, { status: 400 });
    }

    await connectDB();
    const user = await User.findById(session.userId);
    if (!user) return NextResponse.json({ saved: false }, { status: 404 });

    const existingIdx = user.readingHistory.findIndex((h) => h.storyId.toString() === storyId);

    const record = {
      storyId,
      chapterId,
      chapterNumber: Number(chapterNumber),
      chapterSlug,
      scrollPosition: Number(scrollPosition) || 0,
      updatedAt: new Date(),
    };

    if (existingIdx > -1) {
      user.readingHistory[existingIdx] = record;
    } else {
      user.readingHistory.unshift(record);
      if (user.readingHistory.length > 50) {
        user.readingHistory = user.readingHistory.slice(0, 50);
      }
    }

    await user.save();
    return NextResponse.json({ saved: true });
  } catch (error) {
    console.error('PUT reading history error:', error);
    return NextResponse.json({ error: 'Lỗi khi lưu vị trí đọc.' }, { status: 500 });
  }
}
