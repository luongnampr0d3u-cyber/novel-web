import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import Chapter from '@/models/Chapter';
import Story from '@/models/Story';
import { requireAuth } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    await connectDB();
    const { searchParams } = new URL(request.url);
    const storyId = searchParams.get('storyId');

    if (!storyId) {
      return NextResponse.json({ error: 'Thiếu storyId.' }, { status: 400 });
    }

    const chapters = await Chapter.find({ storyId })
      .select('storyId chapterNumber title slug views createdAt')
      .sort({ chapterNumber: 1 })
      .lean();

    return NextResponse.json({ chapters });
  } catch (error) {
    console.error('GET chapters error:', error);
    return NextResponse.json({ error: 'Không thể tải danh sách chương.' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireAuth(['admin', 'moderator']);
    if (!session) {
      return NextResponse.json({ error: 'Không có quyền thêm chương.' }, { status: 403 });
    }

    const { storyId, chapterNumber, title, content } = await request.json();

    if (!storyId || !chapterNumber || !title?.trim() || !content?.trim()) {
      return NextResponse.json(
        { error: 'Vui lòng nhập đầy đủ truyện, số chương, tiêu đề và nội dung.' },
        { status: 400 }
      );
    }

    await connectDB();

    const story = await Story.findById(storyId);
    if (!story) {
      return NextResponse.json({ error: 'Truyện không tồn tại.' }, { status: 404 });
    }

    const num = Number(chapterNumber);
    const slug = `chuong-${num}`;

    const duplicate = await Chapter.findOne({
      storyId,
      $or: [{ chapterNumber: num }, { slug }],
    });

    if (duplicate) {
      return NextResponse.json({ error: `Chương ${num} đã tồn tại.` }, { status: 409 });
    }

    const chapter = await Chapter.create({
      storyId,
      chapterNumber: num,
      title: title.trim(),
      slug,
      content: content.trim(),
    });

    const totalChapters = await Chapter.countDocuments({ storyId });
    await Story.findByIdAndUpdate(storyId, {
      totalChapters,
      latestChapterAt: new Date(),
    });

    return NextResponse.json({ chapter }, { status: 201 });
  } catch (error) {
    console.error('POST chapter error:', error);
    return NextResponse.json({ error: 'Lỗi khi tạo chương.' }, { status: 500 });
  }
}
