import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import Chapter from '@/models/Chapter';
import Story from '@/models/Story';
import { requireAuth } from '@/lib/auth';

export async function GET(_request: Request, { params }: { params: { id: string } }) {
  try {
    await connectDB();
    const chapter = await Chapter.findById(params.id).lean();
    if (!chapter) {
      return NextResponse.json({ error: 'Không tìm thấy chương.' }, { status: 404 });
    }
    return NextResponse.json({ chapter });
  } catch (error) {
    console.error('GET chapter error:', error);
    return NextResponse.json({ error: 'Lỗi khi tải chương.' }, { status: 500 });
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await requireAuth(['admin', 'moderator']);
    if (!session) {
      return NextResponse.json({ error: 'Không có quyền sửa chương.' }, { status: 403 });
    }

    const { chapterNumber, title, content } = await request.json();

    await connectDB();

    const updateData: Record<string, unknown> = {};
    if (chapterNumber !== undefined) {
      const num = Number(chapterNumber);
      updateData.chapterNumber = num;
      updateData.slug = `chuong-${num}`;
    }
    if (title?.trim()) updateData.title = title.trim();
    if (content?.trim()) updateData.content = content.trim();

    const updated = await Chapter.findByIdAndUpdate(params.id, updateData, { new: true });
    if (!updated) {
      return NextResponse.json({ error: 'Không tìm thấy chương.' }, { status: 404 });
    }

    return NextResponse.json({ chapter: updated });
  } catch (error) {
    console.error('PUT chapter error:', error);
    return NextResponse.json({ error: 'Lỗi khi cập nhật chương.' }, { status: 500 });
  }
}

export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await requireAuth(['admin', 'moderator']);
    if (!session) {
      return NextResponse.json({ error: 'Không có quyền xóa chương.' }, { status: 403 });
    }

    await connectDB();
    const deleted = await Chapter.findByIdAndDelete(params.id);
    if (!deleted) {
      return NextResponse.json({ error: 'Không tìm thấy chương.' }, { status: 404 });
    }

    const totalChapters = await Chapter.countDocuments({ storyId: deleted.storyId });
    await Story.findByIdAndUpdate(deleted.storyId, { totalChapters });

    return NextResponse.json({ message: 'Đã xóa chương.' });
  } catch (error) {
    console.error('DELETE chapter error:', error);
    return NextResponse.json({ error: 'Lỗi khi xóa chương.' }, { status: 500 });
  }
}
