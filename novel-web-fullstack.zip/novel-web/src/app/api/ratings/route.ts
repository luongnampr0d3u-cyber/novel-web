import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import { connectDB } from '@/lib/db';
import Rating from '@/models/Rating';
import Story from '@/models/Story';
import { requireAuth } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const session = await requireAuth(['admin', 'moderator', 'user']);
    if (!session) {
      return NextResponse.json({ error: 'Vui lòng đăng nhập để đánh giá.' }, { status: 401 });
    }

    const { storyId, score } = await request.json();
    const numericScore = Number(score);

    if (!storyId || numericScore < 1 || numericScore > 5) {
      return NextResponse.json({ error: 'Điểm đánh giá phải từ 1 đến 5 sao.' }, { status: 400 });
    }

    await connectDB();

    await Rating.findOneAndUpdate(
      { storyId, userId: session.userId },
      { score: numericScore },
      { upsert: true, new: true }
    );

    const stats = await Rating.aggregate([
      { $match: { storyId: new mongoose.Types.ObjectId(storyId) } },
      {
        $group: {
          _id: '$storyId',
          avg: { $avg: '$score' },
          count: { $sum: 1 },
        },
      },
    ]);

    const ratingAvg = stats[0] ? Number(stats[0].avg.toFixed(1)) : numericScore;
    const ratingCount = stats[0] ? stats[0].count : 1;

    await Story.findByIdAndUpdate(storyId, { ratingAvg, ratingCount });

    return NextResponse.json({ ratingAvg, ratingCount, userScore: numericScore });
  } catch (error) {
    console.error('POST rating error:', error);
    return NextResponse.json({ error: 'Lỗi khi gửi đánh giá.' }, { status: 500 });
  }
}
