import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import Comment from '@/models/Comment';
import { requireAuth } from '@/lib/auth';

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await requireAuth(['admin', 'moderator']);
    if (!session) {
      return NextResponse.json({ error: 'Không có quyền kiểm duyệt.' }, { status: 403 });
    }

    const { isHidden } = await request.json();

    await connectDB();
    const updated = await Comment.findByIdAndUpdate(
      params.id,
      { isHidden: Boolean(isHidden) },
      { new: true }
    );

    if (!updated) {
      return NextResponse.json({ error: 'Không tìm thấy bình luận.' }, { status: 404 });
    }

    return NextResponse.json({ comment: updated });
  } catch (error) {
    console.error('PATCH comment error:', error);
    return NextResponse.json({ error: 'Lỗi khi cập nhật bình luận.' }, { status: 500 });
  }
}

export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await requireAuth(['admin', 'moderator', 'user']);
    if (!session) {
      return NextResponse.json({ error: 'Vui lòng đăng nhập.' }, { status: 401 });
    }

    await connectDB();
    const comment = await Comment.findById(params.id);
    if (!comment) {
      return NextResponse.json({ error: 'Không tìm thấy bình luận.' }, { status: 404 });
    }

    const isOwner = comment.userId.toString() === session.userId;
    const isStaff = session.role === 'admin' || session.role === 'moderator';

    if (!isOwner && !isStaff) {
      return NextResponse.json({ error: 'Bạn không có quyền xóa bình luận này.' }, { status: 403 });
    }

    await Comment.deleteMany({ $or: [{ _id: params.id }, { parentId: params.id }] });

    return NextResponse.json({ message: 'Đã xóa bình luận.' });
  } catch (error) {
    console.error('DELETE comment error:', error);
    return NextResponse.json({ error: 'Lỗi khi xóa bình luận.' }, { status: 500 });
  }
}
