import { NextResponse } from 'next/server';
import { connectDB } from '@/lib/db';
import Comment from '@/models/Comment';
import { requireAuth } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    await connectDB();
    const { searchParams } = new URL(request.url);
    const storyId = searchParams.get('storyId');
    const chapterId = searchParams.get('chapterId');
    const all = searchParams.get('all') === 'true';

    if (all) {
      const session = await requireAuth(['admin', 'moderator']);
      if (!session) {
        return NextResponse.json({ error: 'Không có quyền truy cập.' }, { status: 403 });
      }
      const comments = await Comment.find()
        .populate('userId', 'username role')
        .populate('storyId', 'title slug')
        .sort({ createdAt: -1 })
        .limit(100)
        .lean();
      return NextResponse.json({ comments });
    }

    if (!storyId) {
      return NextResponse.json({ error: 'Thiếu storyId.' }, { status: 400 });
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const filter: Record<string, any> = { storyId, isHidden: false };
    if (chapterId) filter.chapterId = chapterId;

    const comments = await Comment.find(filter)
      .populate('userId', 'username role avatar')
      .sort({ createdAt: -1 })
      .limit(100)
      .lean();

    return NextResponse.json({ comments });
  } catch (error) {
    console.error('GET comments error:', error);
    return NextResponse.json({ error: 'Không thể tải bình luận.' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireAuth(['admin', 'moderator', 'user']);
    if (!session) {
      return NextResponse.json({ error: 'Vui lòng đăng nhập để bình luận.' }, { status: 401 });
    }

    const { storyId, chapterId, parentId, content } = await request.json();

    if (!storyId || !content?.trim()) {
      return NextResponse.json({ error: 'Nội dung bình luận không được trống.' }, { status: 400 });
    }

    await connectDB();

    const comment = await Comment.create({
      storyId,
      chapterId: chapterId || null,
      parentId: parentId || null,
      userId: session.userId,
      content: content.trim(),
    });

    const populated = await Comment.findById(comment._id)
      .populate('userId', 'username role avatar')
      .lean();

    return NextResponse.json({ comment: populated }, { status: 201 });
  } catch (error) {
    console.error('POST comment error:', error);
    return NextResponse.json({ error: 'Lỗi khi gửi bình luận.' }, { status: 500 });
  }
}
