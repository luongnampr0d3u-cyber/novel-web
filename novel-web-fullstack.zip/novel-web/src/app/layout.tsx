import type { Metadata } from 'next';
import './globals.css';
import { connectDB } from '@/lib/db';
import SiteSetting from '@/models/SiteSetting';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';

export const dynamic = 'force-dynamic';

async function getSettings() {
  try {
    await connectDB();
    let settings = await SiteSetting.findOne().lean();
    if (!settings) {
      const created = await SiteSetting.create({});
      settings = created.toObject();
    }
    return settings;
  } catch {
    return {
      siteName: 'Tàng Kinh Các',
      logoUrl: '',
      primaryColor: '#2563eb',
      announcement: '',
      bannerTitle: 'Khám phá kho truyện chữ đặc sắc',
      bannerSubtitle: 'Cập nhật chương mới mỗi ngày.',
      footerText: '© 2026 Tàng Kinh Các.',
      maintenanceMode: false,
    };
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSettings();
  return {
    title: `${settings.siteName} - Đọc Truyện Chữ Online`,
    description: settings.bannerSubtitle || 'Website đọc truyện chữ online miễn phí',
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const settings = await getSettings();

  return (
    <html lang="vi" style={{ ['--color-primary' as string]: settings.primaryColor || '#2563eb' }}>
      <body className="flex min-h-screen flex-col">
        {settings.announcement && (
          <div className="bg-primary px-4 py-1.5 text-center text-xs font-medium text-white">
            {settings.announcement}
          </div>
        )}
        <Navbar siteName={settings.siteName} logoUrl={settings.logoUrl} />
        <main className="flex-1">{children}</main>
        <Footer siteName={settings.siteName} footerText={settings.footerText} />
      </body>
    </html>
  );
}
