import { notFound } from 'next/navigation';
import { connectDB } from '@/lib/db';
import Story from '@/models/Story';
import Chapter from '@/models/Chapter';
import { getCurrentUser } from '@/lib/auth';
import ReaderClient from '@/components/story/ReaderClient';
import CommentSection from '@/components/story/CommentSection';

export const dynamic = 'force-dynamic';

export default async function ReadChapterPage({
  params,
}: {
  params: { slug: string; chapterSlug: string };
}) {
  await connectDB();

  const story = await Story.findOne({ slug: params.slug }).select('_id title slug').lean();
  if (!story) notFound();

  const chapter = await Chapter.findOne({ storyId: story._id, slug: params.chapterSlug }).lean();
  if (!chapter) notFound();

  await Promise.all([
    Story.findByIdAndUpdate(story._id, { $inc: { views: 1 } }),
    Chapter.findByIdAndUpdate(chapter._id, { $inc: { views: 1 } }),
  ]);

  const [allChapters, currentUser] = await Promise.all([
    Chapter.find({ storyId: story._id })
      .select('_id chapterNumber title slug')
      .sort({ chapterNumber: 1 })
      .lean(),
    getCurrentUser(),
  ]);

  const currentIndex = allChapters.findIndex((c) => c._id.toString() === chapter._id.toString());
  const prevChapter = currentIndex > 0 ? allChapters[currentIndex - 1] : null;
  const nextChapter =
    currentIndex > -1 && currentIndex < allChapters.length - 1
      ? allChapters[currentIndex + 1]
      : null;

  let initialScrollPosition = 0;
  if (currentUser) {
    const history = (currentUser.readingHistory || []).find(
      (h) =>
        h.storyId.toString() === story._id.toString() &&
        h.chapterId.toString() === chapter._id.toString()
    );
    if (history) initialScrollPosition = history.scrollPosition;
  }

  return (
    <div>
      <ReaderClient
        story={JSON.parse(JSON.stringify(story))}
        chapter={JSON.parse(JSON.stringify(chapter))}
        prevChapter={prevChapter ? JSON.parse(JSON.stringify(prevChapter)) : null}
        nextChapter={nextChapter ? JSON.parse(JSON.stringify(nextChapter)) : null}
        allChapters={JSON.parse(JSON.stringify(allChapters))}
        initialScrollPosition={initialScrollPosition}
      />
      <div className="mx-auto max-w-3xl px-4 pb-12">
        <CommentSection storyId={story._id.toString()} chapterId={chapter._id.toString()} />
      </div>
    </div>
  );
}
