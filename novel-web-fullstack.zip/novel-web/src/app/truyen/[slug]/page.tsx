import Link from 'next/link';
import { notFound } from 'next/navigation';
import { BookOpen, Eye, User, List } from 'lucide-react';
import { connectDB } from '@/lib/db';
import Story from '@/models/Story';
import Chapter from '@/models/Chapter';
import Rating from '@/models/Rating';
import { getCurrentUser } from '@/lib/auth';
import { formatDate, formatNumber } from '@/lib/utils';
import BookmarkButton from '@/components/story/BookmarkButton';
import RatingBox from '@/components/story/RatingBox';
import CommentSection from '@/components/story/CommentSection';

export const dynamic = 'force-dynamic';

export default async function StoryDetailPage({ params }: { params: { slug: string } }) {
  await connectDB();

  const story = await Story.findOne({ slug: params.slug })
    .populate('categories', 'name slug')
    .lean();

  if (!story) notFound();

  const [chapters, currentUser] = await Promise.all([
    Chapter.find({ storyId: story._id })
      .select('chapterNumber title slug createdAt')
      .sort({ chapterNumber: 1 })
      .lean(),
    getCurrentUser(),
  ]);

  let isBookmarked = false;
  let userRatingScore = 0;
  let continueChapterSlug = '';

  if (currentUser) {
    isBookmarked = (currentUser.bookmarks || []).some(
      (b) => b.storyId.toString() === story._id.toString()
    );
    const history = (currentUser.readingHistory || []).find(
      (h) => h.storyId.toString() === story._id.toString()
    );
    if (history) continueChapterSlug = history.chapterSlug;

    const existingRating = await Rating.findOne({
      storyId: story._id,
      userId: currentUser._id,
    }).lean();
    if (existingRating) userRatingScore = existingRating.score;
  }

  const firstChapter = chapters[0];

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="flex flex-col gap-6 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm md:flex-row">
        <div className="mx-auto w-48 shrink-0 overflow-hidden rounded-xl shadow md:mx-0">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={story.coverImage}
            alt={story.title}
            className="aspect-[2/3] w-full object-cover"
          />
        </div>

        <div className="flex flex-1 flex-col">
          <h1 className="text-2xl font-extrabold text-gray-900 sm:text-3xl">{story.title}</h1>

          <div className="mt-2 flex flex-wrap items-center gap-4 text-sm text-gray-600">
            <span className="flex items-center gap-1">
              <User className="h-4 w-4 text-primary" />
              {story.author}
            </span>
            <span className="flex items-center gap-1">
              <Eye className="h-4 w-4 text-primary" />
              {formatNumber(story.views)} lượt xem
            </span>
            <span>{story.totalChapters} chương</span>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            {(story.categories as unknown as { _id: string; name: string; slug: string }[]).map(
              (cat) => (
                <Link
                  key={cat._id.toString()}
                  href={`/tim-kiem?category=${cat.slug}`}
                  className="rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-700 hover:bg-primary hover:text-white"
                >
                  {cat.name}
                </Link>
              )
            )}
          </div>

          <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-gray-700">
            {story.description}
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            {continueChapterSlug ? (
              <Link
                href={`/truyen/${story.slug}/${continueChapterSlug}`}
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-white hover:opacity-90"
              >
                <BookOpen className="h-4 w-4" />
                Đọc tiếp
              </Link>
            ) : firstChapter ? (
              <Link
                href={`/truyen/${story.slug}/${firstChapter.slug}`}
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-white hover:opacity-90"
              >
                <BookOpen className="h-4 w-4" />
                Đọc từ đầu
              </Link>
            ) : null}

            <BookmarkButton storyId={story._id.toString()} initialBookmarked={isBookmarked} />
          </div>
        </div>
      </div>

      <div className="mt-6">
        <RatingBox
          storyId={story._id.toString()}
          initialAvg={story.ratingAvg}
          initialCount={story.ratingCount}
          initialUserScore={userRatingScore}
        />
      </div>

      <section className="mt-8 rounded-xl border border-gray-200 bg-white p-5">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-bold text-gray-900">
          <List className="h-5 w-5 text-primary" />
          Danh sách chương ({chapters.length})
        </h2>

        {chapters.length === 0 ? (
          <p className="text-sm text-gray-500">Truyện chưa có chương nào.</p>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2">
            {chapters.map((ch) => (
              <Link
                key={ch._id.toString()}
                href={`/truyen/${story.slug}/${ch.slug}`}
                className="flex items-center justify-between rounded-lg border border-gray-100 px-3 py-2 text-sm hover:border-primary/40 hover:bg-gray-50"
              >
                <span className="truncate font-medium text-gray-800">
                  Chương {ch.chapterNumber}: {ch.title}
                </span>
                <span className="ml-2 shrink-0 text-xs text-gray-400">
                  {formatDate(ch.createdAt)}
                </span>
              </Link>
            ))}
          </div>
        )}
      </section>

      <CommentSection storyId={story._id.toString()} />
    </div>
  );
}
