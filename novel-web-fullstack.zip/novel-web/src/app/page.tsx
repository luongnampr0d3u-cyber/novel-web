import Link from 'next/link';
import { Flame, Clock, CheckCircle2, ArrowRight } from 'lucide-react';
import { connectDB } from '@/lib/db';
import Story from '@/models/Story';
import SiteSetting from '@/models/SiteSetting';
import StoryCard, { StoryCardItem } from '@/components/story/StoryCard';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  await connectDB();

  const [settings, hotStories, latestStories, completedStories] = await Promise.all([
    SiteSetting.findOne().lean(),
    Story.find().sort({ views: -1 }).limit(6).lean(),
    Story.find().sort({ latestChapterAt: -1 }).limit(12).lean(),
    Story.find({ status: 'completed' }).sort({ ratingAvg: -1 }).limit(6).lean(),
  ]);

  const serialize = (list: unknown[]) => JSON.parse(JSON.stringify(list)) as StoryCardItem[];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <section className="mb-10 rounded-2xl bg-gradient-to-r from-primary to-indigo-600 p-8 text-white shadow-md">
        <h1 className="text-2xl font-extrabold sm:text-4xl">
          {settings?.bannerTitle || 'Khám phá kho truyện chữ đặc sắc'}
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-white/90 sm:text-base">
          {settings?.bannerSubtitle || 'Cập nhật chương mới mỗi ngày, giao diện đọc mượt mà.'}
        </p>
        <div className="mt-5 flex flex-wrap gap-3">
          <Link
            href="/tim-kiem"
            className="inline-flex items-center gap-1.5 rounded-lg bg-white px-4 py-2.5 text-sm font-semibold text-gray-900 hover:bg-gray-100"
          >
            Khám phá ngay <ArrowRight className="h-4 w-4" />
          </Link>
          <Link
            href="/tu-truyen"
            className="inline-flex items-center gap-1.5 rounded-lg border border-white/40 px-4 py-2.5 text-sm font-semibold text-white hover:bg-white/10"
          >
            Tủ truyện của tôi
          </Link>
        </div>
      </section>

      <section className="mb-12">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-xl font-bold text-gray-900">
            <Flame className="h-5 w-5 text-orange-500" />
            Truyện Hot
          </h2>
          <Link href="/tim-kiem?sort=views" className="text-sm font-medium text-primary hover:underline">
            Xem tất cả
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {serialize(hotStories).map((story) => (
            <StoryCard key={story._id} story={story} />
          ))}
        </div>
      </section>

      <section className="mb-12">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-xl font-bold text-gray-900">
            <Clock className="h-5 w-5 text-primary" />
            Mới Cập Nhật
          </h2>
          <Link href="/tim-kiem?sort=latest" className="text-sm font-medium text-primary hover:underline">
            Xem tất cả
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {serialize(latestStories).map((story) => (
            <StoryCard key={story._id} story={story} />
          ))}
        </div>
      </section>

      {completedStories.length > 0 && (
        <section>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-xl font-bold text-gray-900">
              <CheckCircle2 className="h-5 w-5 text-emerald-600" />
              Truyện Đã Hoàn Thành
            </h2>
            <Link
              href="/tim-kiem?status=completed"
              className="text-sm font-medium text-primary hover:underline"
            >
              Xem tất cả
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {serialize(completedStories).map((story) => (
              <StoryCard key={story._id} story={story} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
