import { SignJWT, jwtVerify } from 'jose';

export type UserRole = 'admin' | 'moderator' | 'user';

export interface JWTPayload {
  userId: string;
  username: string;
  email: string;
  role: UserRole;
}

const getSecretKey = () => {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 16) {
    throw new Error('JWT_SECRET chưa được cấu hình hoặc quá ngắn');
  }
  return new TextEncoder().encode(secret);
};

export const AUTH_COOKIE_NAME = 'novel_token';

export async function signToken(payload: JWTPayload): Promise<string> {
  return await new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(getSecretKey());
}

export async function verifyToken(token: string): Promise<JWTPayload | null> {
  try {
    const { payload } = await jwtVerify(token, getSecretKey());
    return {
      userId: payload.userId as string,
      username: payload.username as string,
      email: payload.email as string,
      role: payload.role as UserRole,
    };
  } catch {
    return null;
  }
}
