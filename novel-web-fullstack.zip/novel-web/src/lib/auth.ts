import { cookies } from 'next/headers';
import { AUTH_COOKIE_NAME, JWTPayload, UserRole, verifyToken } from './jwt';
import { connectDB } from './db';
import User from '@/models/User';

export async function getSession(): Promise<JWTPayload | null> {
  const cookieStore = cookies();
  const token = cookieStore.get(AUTH_COOKIE_NAME)?.value;
  if (!token) return null;
  return await verifyToken(token);
}

export async function getCurrentUser() {
  const session = await getSession();
  if (!session) return null;

  await connectDB();
  const user = await User.findById(session.userId).select('-passwordHash').lean();
  if (!user || user.isBanned) return null;

  return user;
}

export async function requireAuth(allowedRoles?: UserRole[]): Promise<JWTPayload | null> {
  const session = await getSession();
  if (!session) return null;

  if (allowedRoles && !allowedRoles.includes(session.role)) {
    return null;
  }

  return session;
}
