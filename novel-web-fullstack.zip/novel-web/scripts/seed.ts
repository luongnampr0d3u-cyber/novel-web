import 'dotenv/config';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import User from '../src/models/User';
import Category from '../src/models/Category';
import Story from '../src/models/Story';
import Chapter from '../src/models/Chapter';
import SiteSetting from '../src/models/SiteSetting';

async function seed() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.error('Thiếu MONGODB_URI trong .env');
    process.exit(1);
  }

  await mongoose.connect(uri);
  console.log('Đã kết nối MongoDB...');

  const existingSetting = await SiteSetting.findOne();
  if (!existingSetting) {
    await SiteSetting.create({});
    console.log('Đã tạo SiteSetting mặc định.');
  }

  const passwordHash = await bcrypt.hash('123456', 10);
  const sampleUsers = [
    { username: 'admin', email: 'admin@novel.vn', passwordHash, role: 'admin' },
    { username: 'moderator', email: 'mod@novel.vn', passwordHash, role: 'moderator' },
    { username: 'docgia', email: 'user@novel.vn', passwordHash, role: 'user' },
  ];

  for (const u of sampleUsers) {
    await User.updateOne({ email: u.email }, { $setOnInsert: u }, { upsert: true });
  }
  const adminUser = await User.findOne({ email: 'admin@novel.vn' });
  console.log('Đã tạo tài khoản mẫu (mật khẩu chung: 123456).');

  const sampleCategories = [
    { name: 'Tiên Hiệp', slug: 'tien-hiep', description: 'Truyện tu tiên, cầu trường sinh' },
    { name: 'Huyền Huyễn', slug: 'huyen-huyen', description: 'Thế giới kỳ ảo, phép thuật' },
    { name: 'Kiếm Hiệp', slug: 'kiem-hiep', description: 'Giang hồ võ lâm, ân oán tình thù' },
    { name: 'Đô Thị', slug: 'do-thi', description: 'Cuộc sống hiện đại, thương trường' },
    { name: 'Ngôn Tình', slug: 'ngon-tinh', description: 'Tình cảm lãng mạn' },
  ];

  const categoryIds = [];
  for (const cat of sampleCategories) {
    const doc = await Category.findOneAndUpdate(
      { slug: cat.slug },
      { $setOnInsert: cat },
      { upsert: true, new: true }
    );
    categoryIds.push(doc._id);
  }

  const storySlug = 'pham-nhan-tu-tien-mau';
  let story = await Story.findOne({ slug: storySlug });
  if (!story) {
    story = await Story.create({
      title: 'Phàm Nhân Tu Tiên (Bản Mẫu)',
      slug: storySlug,
      author: 'Vong Ngữ',
      coverImage: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&h=900&fit=crop',
      description:
        'Một thiếu niên bình thường xuất thân từ sơn thôn nhỏ, tình cờ bước chân vào giang hồ môn phái và mở ra con đường tu tiên đầy chông gai.',
      categories: [categoryIds[0], categoryIds[1]],
      status: 'ongoing',
      views: 1250,
      ratingAvg: 4.8,
      ratingCount: 10,
      totalChapters: 2,
      createdBy: adminUser?._id,
    });

    await Chapter.insertMany([
      {
        storyId: story._id,
        chapterNumber: 1,
        title: 'Sơn biên tiểu thôn',
        slug: 'chuong-1',
        content:
          'Ngũ Lý Câu là một sơn thôn nhỏ nằm sâu trong vùng núi Thanh Ngưu Trấn.\n\nHàn Lập năm nay mới mười tuổi, làn da hơi ngăm đen, dáng vẻ hết sức bình thường. Giống như bao đứa trẻ khác trong làng, ngày ngày cậu lên núi đốn củi, phụ giúp cha mẹ việc đồng áng.\n\nCho đến một buổi chiều mùa thu, Tam Thúc từ trong thành trở về mang theo một cơ hội thay đổi hoàn toàn vận mệnh của cậu.',
      },
      {
        storyId: story._id,
        chapterNumber: 2,
        title: 'Thất Huyền Môn khảo hạch',
        slug: 'chuong-2',
        content:
          'Đường lên Thái Nam Sơn quanh co hiểm trở, sương mù bao phủ quanh năm.\n\nTrước cổng đá đồ sộ của Thất Huyền Môn, hàng trăm thiếu niên đến từ khắp nơi đang xếp hàng chờ đợi bài kiểm tra nhập môn. Ánh mắt Hàn Lập bình tĩnh nhìn về phía đỉnh núi cao vút trong mây.',
      },
    ]);
    console.log('Đã tạo truyện và chương mẫu.');
  }

  await mongoose.disconnect();
  console.log('Hoàn tất Seed Data!');
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
